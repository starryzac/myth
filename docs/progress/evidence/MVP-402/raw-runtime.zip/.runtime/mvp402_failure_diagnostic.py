import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome=yield
    report=outcome.get_result()
    if report.when == "call" and report.failed and call.excinfo:
        for entry in call.excinfo.traceback:
            result=entry.frame.f_locals.get("result")
            if hasattr(result,"source_issues"):
                print("ACTUAL_DIAGNOSTIC_SOURCE",[i.model_dump(mode="json") for i in result.source_issues],flush=True)
                if hasattr(result,"boundary"):
                    print("ACTUAL_DIAGNOSTIC_BLOCKERS",[i.model_dump(mode="json") for i in result.boundary.blocking_constraints],flush=True)
