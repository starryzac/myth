# Legacy Goal 夹具候选与 root 实际验收交接

实际失败证据来自 root 的 `MVP-402-month-parser-diagnostic.txt`：`test_goal_import_partitions_cash_and_uses_proved_monthly_contributions` 为 1 failed / 3.54s，唯一来源问题是 `BANK_RECONCILIATION_REQUIRED`，提示完整 recovery exposure 与当前事实不同。没有 `INVALID_GOAL_MONTH_SOURCE`；不能将该 RED 归因于月度 parser。

源码定位：`test_boundary_service.py:295` 的 `goal_fixture` 建立真实 Goal，并在 `with_proofs=True` 时新增 OWNERSHIP（cash 160000 / principal 0）与 MONTH（40000）原凭证；`imported_proof:277` 写入 BANK_CONFIRMED 内容及真实 configuration_hash。`asset_exposure_snapshot` 的 evidence manifest 包含这两类证据；`simulated_bank.validate_recovery_exposure:263` 重算完整 manifest 后比较 hash。因此新增证据使 seed 原 exposure 不再覆盖当前事实。当前文件与 `afc32e6` 原件字节完全相同（SHA `edf2471c0c75aa6fba21696277f6f62607f2f6a74cd36e3004c219c9cae3e8ce`）：缺口在旧源码已存在，未重新运行旧提交。

候选仅新增 existing `refresh_execution_exposure` import，及 `goal_fixture` 两个可信导入凭证完成后的一次调用。`with_proofs=False` 不调用。由现有 replace_proof 保留旧 exposure 的 content/content_hash，合法标记 SUPERSEDED 并创建继承新 manifest 的证明；不修改任何现金、本金、目标金额、原 BANK_CONFIRM 内容、银行分录或 income ledger。这里只是 test trusted-import 初始化，不给生产 validator 添加豁免。

协议以真实源码为准：当前 seed 即使 legacy helper 省 income/clearing，也给 snapshot 传 external_bank_facts 集合，初始 exposure 因此按 v4 编码。刷新函数根据实际 external fact/CLEARING 是否存在选择 v3/v4；此夹具没有 external 原件时可生成完整 v3 继承证明。未另开数据库查询确认协议，不宣称协议版本保持不变。

静态实际 Ruff / format --check / mypy 均 exit0，原始日志为同前缀 `-ruff.txt`、`-format.txt`、`-mypy.txt`。AST 证据 `-ast.txt`：26 个其他函数完全相同、65 条 assert 全部相同；移除新增刷新调用后 Goal 函数 AST 完全等于原稿，全部原 import/top-level 项保留。候选 SHA `db0e6dc03971f99ed85e85ba5714bcbd7eab5dccf503d5e2cb766b46313f5760`。

root 后续已审核并部署 exact 候选，真实串行运行 label `MVP-402-goal-month-fixture-green`：`test_goal_import_partitions_cash_and_uses_proved_monthly_contributions` 与 `test_goal_allocated_total_cannot_substitute_for_monthly_contribution_evidence`，2 passed / pytest 5.08s / exit0（进程 elapsed 6.312s），source changed_during_run=[]。原始 `.txt` 与 `.json` 保留于 `.runtime`。UTC 2026-10-04T16:53:03.263713+00:00 至 16:53:09.573655+00:00；代码基线 afc32e6，部署后 test SHA 同候选。此前 AST 比对是部署前的真实原文件与 afc32e6 字节比较；不能把该旧 SHA 称为部署后的当前 SHA。我未运行 PG/pytest，也未编辑生产或正式测试文件。

调用者列表保存在 `-consumers.txt` / `-review.json`：boundary、income ledger、goal allocation、asset allocation、recovery income/audit/goal ownership 均可能受到此共享 helper 的初始化影响。`test_future_goal_does_not_require_a_month_with_no_commitment` 在 helper 返回后删除 MONTH，完整 exposure 会再次 stale；后续手改 positions/ownership 的正例也需明确完成各自可信导入后再评估。此次不改这些调用者，不在有意坏源测试后刷新，不宣称整个 helper 消费者已通过。root 实际验收仅覆盖上述正月度及 `with_proofs=False` 两节点；production 强验保持原样。当前所有 production/test 冻结，不再扩大执行。
