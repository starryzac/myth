# MVP-402 生命周期执行接缝计划

2026-10-05。源码只读结论；下列 PG 节点未执行、金融结果未验证。401 已关闭，402 已获 owner 授权；先由 root 串行运行真实 RED，再实现最小修复。此文不授权正式库资金动作。

## 当前具体接缝

- `services/policy_lifecycle.py:347` `_invalidation` 按直接 version、原 DecisionRun 的 versions 和 constraints 选取同用户动作，排序并锁定。当前只写 `ActionPlan.status=INVALIDATED` 和审计；没有独立银行无效果核验、实际资源/收入释放或 exposure 刷新。
- `services/execution.py:43` 真实 prepare 会写完整 command、原 trace 与 `PLANNED_UNRESERVED` exposure；confirm 只确认，仍不预留。`execution.py:326` phase 1 才提交 claims/income reservation 和 SUBMITTED，phase 2 银行独立提交，phase 3 投影。
- `services/execution_exposure.py:105` 既有声明严格检查：PLANNED_UNRESERVED 要求 PLANNED/AUTHORIZED 且无银行/claims/receipt；NO_EFFECT 要求 CANCELLED/INVALIDATED，银行不存在或 REJECTED，无回执，claims 全 RELEASED。仅改 ActionPlan 状态会令原 exposure 与实际动作冲突，不能削弱此核验。
- `services/income_ledger.py:356` 释放要求原 command、确认无效果、无银行或同 request/hash 的 REJECTED，并要求确有匹配的原 reservation。`effect.income_uses` 仅是准备时的来源计划，不等于已有 reservation；正常 prepare/confirm 不能无条件调用 release。
- `services/execution_reservations.py:112` 释放要求无银行且动作取消/失效，或原银行 REJECTED。该函数本身不证明无 posting/receipt，调用方必须完整核验。
- `services/execution.py:580` `_record_bank_refusal` 已存在原子处理模式：锁用户、原请求一致、银行 ABSENT/REJECTED 且无实际腿，再释放真实占用、推进源时点、刷新 exposure；任意不确定结果保持 UNKNOWN。不能把它的“确定本地拒绝”前提泛化为“查询未见银行即无效果”。

## 输入与分类

保持现有 policy API、版本去重及 user lock 顺序：transaction reset gate → user → sorted actions。策略参数变更、暂停、撤销、到期共用 `_invalidation`，不另建取消银行协议。

| 输入事实 | 生命周期结果 | 资金/原身份处理 |
|---|---|---|
| 103 人工动作，request 无 execution | 原103 status/receipt 分类 | 保留兼容性，不要求不存在的银行、income 或 exposure 来源 |
| 真实 PLANNED/AUTHORIZED；完整同用户 command；无银行、旧 redemption、实际 posting、回执 | INVALIDATED / NO_EFFECT | 只有真实 RESERVED rows 才释放；准备阶段无 reservation 时不制造或释放收入。原 cash/principal/Goal ownership/txn/command 不变，刷新完整 exposure |
| 同原 command 的确定 REJECTED；完整 identity/key/hash 一致；无效果腿/回执 | 可确认无效果 | 使用已有 guarded release；没有真实 rejection 生产路径证据前，不为测试手造银行成功/失败事实 |
| SUBMITTED/UNKNOWN，甚至当前查不到银行 | inflight，原状态不重写 | 已尝试的原请求可能在途；查询 absence 不等于取消确认，claims/income/reservation 与原键保持 |
| 银行 ACCEPTED/SETTLED/UNKNOWN，或任何 receipt/经济腿 | inflight 或历史结果 | 不能释放或重新发钱；即使动作标签不一致也不据此判无效果。原 operation/首 key/legs 原件保持，原键查询/补投影 |
| command/hash/所属/clock 不一致，无法证明无效果 | 不作释放 | 留存原占用并返回可追踪错误/待对账；不得伪造 NO_EFFECT 或把坏源修成合法权限 |

最小实现边界：只对新确认失效且已证明无效果的真实 command 处理真实 claims；收入 reservation 需在严格 read_income_state 后查原 action_id，存在 RESERVED 且与 command 精确相符才调用 release_income_for_action。不存在时仍保留其原收入全账。COMMITTED/矛盾占用不得释放。旧103分支维持原语义。

同一原事务内顺序：捕获真实 BEFORE → 核验原 command/银行无效果 → status 失效 → guarded income/resource release → 必要的原源时点继承 → 一次完整 exposure 刷新 → ACTION_STATE_CHANGED 审计（AFTER 真 claims 与 released ids）→ flush。任一失败不得留下部分释放或假审计。多个动作需最后一次批量完整刷新，不按每个 action 重读全库。重放已完成失效不再推进时间/证据/审计；需要修复旧不完整状态必须明确可验证，不当成默认重放写。

策略失效只消除未来授权/未完成承诺，不变更已有 Goal cash/principal、已分配收入、持仓或银行结算。已接受银行原请求的后续投影仍须以原事实验证，不用当前撤销抹掉应收/已付经济效果。

## 最小真实 PG RED / 安全回归

1. `test_policy_execution_lifecycle.py::test_revoke_unsubmitted_real_goal_action_refreshes_complete_exposure_without_moving_money`：独立 bf_test + native seed；真实确认目标策略、创建零归属 Goal；真实 INCOME 600000；prepare ALLOCATE_GOAL 10000 + confirm；同 NOW revoke。预期 INVALIDATED、原 command/request hash 不变、无银行/回执/claims、cash/Goal/原 income origins/fragments/reservations/全部 posting 不变；完整 load_all_asset_exposure 必须有效且原 action 声明 NO_EFFECT；银行默认核验和 audit VALID；重复 revoke 全表零写。首 RED 应来自当前 exposure 未刷新的真正业务断言，不能以 fixture/import/type error 代替。
2. `test_revoke_preserves_actual_settled_unknown_operation_and_reservations`：同原真实准备；包装实际 process_operation，先让银行原事务成功提交再丢响应；动作 UNKNOWN。revoke 后原 operation/首 key/request/legs、真实收入与 claims 占用原样，归属仍未增加；原键补投影只一次，使银行既有结果进入原真实应用与原回执，不重发 cash legs。UNKNOWN 的 dashboard 不声称全部 MATCHED。
3. 初始修复后只扩大到同函数的 change/suspend/expiry 或确有不同分支风险的最小参数；既有103 direct/indirect/receipt 分类和旧回滚节点照原断言相关回归。不要立即重跑完整检查或黄金资金链。

真实预留释放路径不能借“prepare 有 income_uses”假称已覆盖。正常三阶段 phase 1 已提交时状态为 SUBMITTED，policy change 应保留在途。若需要 RESERVED 的安全无效果回归，复用既有确定拒绝入口，不为生命周期测试任意把 SUBMITTED 改成 AUTHORIZED；无生产可达状态的 fixture 只能明确标为服务级边界测试。

## 编译恢复纯读合同

`read_compilation(session, user_id, compilation_id, now) -> CompilationResponse`；`proposal_compilation_id(session, user_id, proposal: PolicyProposal, now) -> UUID | None`。

不调用 `_context`（其会 reset gate/User FOR UPDATE），不调用 `_candidate`/revise/compile，不 begin_nested 或靠 rollback 假充只读。`session.no_autoflush`，所有 SELECT 无行锁；root在 API 首次 User SELECT 前建立 RR + READ ONLY。

原 `_load` 的 source/hash/有效时间、simulation/tenant/USER_DECLARED、source_ref、reference_date/timezone/engine/result 原锚点核验需要原样复用为 lock 可选或纯核心。原 compilation/result 不按今天重编译，不创建候选。当前唯一 PROPOSED/CONFIRMED 修订配置回读；旧 rejected/expired 只能显示其历史状态，不给确认权限；多个当前候选冲突明确409。不猜 evidence_ids[0]：编译来源需真实同用户 source + 原幂等 prefix + evidence引用 + 规范化配置 hash 一致；非编译候选明确 None，错源/未来/篡改拒绝。

编译 RED：真实 compile → revise（保留原编译日期锚点）→ RR/RO reader，修订 configuration 正确且原 result/assumptions/issues 原样；完整全表 before/after 相同，实际 SELECT 不含 FOR UPDATE；跨用户404、未来/坏hash失败。此功能当前未实现，测试可用 getattr 后 callable 断言形成明确缺失功能 RED，不用导入不存在函数造成 collection error。
