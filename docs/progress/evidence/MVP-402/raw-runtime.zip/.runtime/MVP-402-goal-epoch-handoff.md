# MVP-402 zero Goal / income epoch carry — frozen handoff

Actual PostgreSQL targeted validation is complete. No own running session remains: final session **21286 closed, exit 0**. Production changes are restricted to `apps/api/app/services/goals.py`; the new regression file is `apps/api/app/tests/test_goal_creation_income_epoch.py`. No formal database action, API change, contract change, or other source/test edit was performed in this fix.

## Change and strict boundary

`_income_epoch_sources` first calls the existing full `read_income_state`, then `load_boundary_context`. It accepts only the expected `MISSING_GOAL_PROJECTION` for the actual new confirmed policy, and requires the same verified ledger evidence ID/hash. Any other source issue prevents carry. Creating legacy zero ownership without income remains lawful; allocation still requires complete income.

After the original zero Goal and its two zero bank openings, the existing `recovery_projection.replace_proof` carries the verified ledger and existing used VALID ownership/month proofs. **Only `content.as_of` changes**. Raw economic origins, fragments, reservations, amounts, ownership and original month periods are retained. Existing Goal/model balances and all existing financial rows are unchanged. Missing current month evidence prevents carry rather than fabricating a zero month. Existing Goal early return and all original bank/exposure guards remain.

Successor contract: hash is `configuration_hash({**previous.content, "as_of": now.isoformat()})`; ID is `uuid5(new_goal.id, f"evidence:{previous.id}:{digest}")`; source ref is `bank-projection:{id}`; source/user/level remain; created/observed/valid_from are the actual supplied now; supersedes is the original ID. Original evidence changes only VALID→SUPERSEDED. Old income eligibility remains determined by original observation/occurrence clocks, so income preceding new policy confirmation gives eligible=0/suggested=0.

Offline AST proof `.runtime/MVP-402-goal-epoch-frozen-ast.json` compares actual HEAD `afc32e6d956255b5cf9147501865185946a7ef06`: after removing this single new helper and the three precise added statements, the **entire original module AST is identical**. No original public function signature, assertion, guard, financial algorithm or existing early return was removed.

## Actual RED / GREEN

All pytest commands used `.venv/Scripts/python.exe -m pytest`, existing random `bf_test_*` fixtures, `PYTHONUTF8=1`, repository `.uv-cache`, `PYTEST_ADDOPTS=""`, `--no-cov -vv -s -x -p no:cacheprovider`. Actual argv, UTC times, raw log SHA and source SHA before/after are in the corresponding JSON.

| Label / raw `.runtime` files | Actual result | UTC start → finish |
|---|---|---|
| `MVP-402-goal-epoch-red.{json,txt}` | 1 failed / 4.06s, exit 1: normal late zero Goal preview INSUFFICIENT, epoch mismatch | 2026-10-04 17:40:26.632559 → 17:40:31.937021 |
| `MVP-402-goal-epoch-first-green.{json,txt}` | 1 passed / 3.79s, exit 0; actual bank/exposure/audit VALID, pure successor, old money intact, GET/retry zero writes | 17:42:02.469596 → 17:42:07.385534 |
| `MVP-402-goal-epoch-related-first.{json,txt}` | 10 passed / 62.55s, exit 0, changed_during_run=[]; process 63.9195s | 17:51:28.242127 → 17:52:32.163923 |

The 10-node command additionally has `--durations=10`. It covers second late zero Goal (both Goal previews and real audit VALID); legacy missing / native bad declared hash without repair; next month without invented old Goal contribution; the two `test_execution_goal_creation` tests; the two `test_policy_execution_lifecycle` tests (including actual settled UNKNOWN retaining claim); `test_future_goal_change_reads_real_existing_month_without_zero_assumption`; and `test_pure_epoch_successor_keeps_prepared_income_identity[False]`. The latter independently verifies a nonempty prepared income identity under pure carry; it is not a claim that the new multiGoal test itself creates a financial reservation.

Slowest actual calls: existing settled UNKNOWN lifecycle 22.09s; existing unsubmitted revoke 12.53s; existing Goal allocation execution 8.42s. New multiGoal 1.80s and new cross-month 1.61s. First positive phases: seed 0.857s, Goal create 0.206s, complete preview/verifiers 0.195s. No full suite or golden chain rerun.

Ruff check, Ruff format --check and `mypy --follow-imports=silent` for the two owned files all exited 0. Actual output: `.runtime/MVP-402-goal-epoch-expanded-{ruff,format,mypy}.txt`.

## Frozen hashes / next owner

- goals.py SHA256: `a7179f401ab5d9a9649f6c9bc8a75ec1029e11f6ab409c6715c142cc450efe8e`
- new test SHA256: `2f04c0d42564a0ba0ae66a492d5ddbdbd524e06bc3d22e647ad5a46de328b580`
- final raw test log SHA256: `6391bb7736424472152c5b4c5d524a4842b92686724fe48f729b75da368c7f57`

Source/tests are FROZEN. Root can now run trace_audit's ignored post-fix native Goal Edge fragment with its strict all-24-table carry oracle. This targeted service evidence does not claim the complete MVP-402 browser acceptance or future modules are finished.
