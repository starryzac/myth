"""Prepare-only helper; root runs with --archive after final closure documents are saved.

Future repo command: .venv/Scripts/python.exe .runtime/archive_mvp402_closure.py --archive
No tests, database, browser, formal migration, source changes, or deletion. Preserves historical
RED and intermediate artifacts as raw evidence; archive success does not turn them into GREEN.
Fresh output only: docs/progress/evidence/MVP-402. ZIP members use exact repo-relative paths.
"""

import argparse
import hashlib
import json
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".runtime"
OUTPUT = ROOT / "docs/progress/evidence/MVP-402"
BROWSER = RUNTIME / "MVP-402-browser-cli"
HELPERS = (
    "run_mvp402_targeted.py",
    "capture_mvp402.py",
    "checkpoint_mvp402.py",
    "browser_cli_mvp402.py",
    "drive_mvp402_browser.py",
    "drive_mvp402_goal_epoch.py",
    "checkpoint_mvp402_folder.py",
    "mvp402_e2e_server.py",
    "mvp402_failure_diagnostic.py",
    "archive_mvp402_closure.py",
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked_paths(paths):
    result = []
    for path in sorted(set(paths)):
        require(path.resolve().is_relative_to(ROOT.resolve()), "Archive member escapes repository")
        if any("MVP-403" in part.upper() for part in path.relative_to(ROOT).parts):
            continue
        if any(
            part in {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules"}
            for part in path.relative_to(ROOT).parts
        ):
            continue
        require(
            not any(
                suffix.lower() in {".part", ".pending", ".tmp", ".partial", ".lock"}
                for suffix in path.suffixes
            ),
            "Active/partial artifact must reach a terminal state before archive: " + str(path),
        )
        require(path.is_file(), "Missing exact archive member: " + str(path))
        result.append(path)
    return result


def runtime_paths():
    paths = []
    for path in RUNTIME.glob("MVP-402-*"):
        # capture_mvp402 owns these while this helper runs. Root copies their actual
        # terminal bytes separately and adds archive_execution to index after exit.
        if path.name in {"MVP-402-archive-launch.txt", "MVP-402-archive-launch.json"}:
            continue
        if path.is_file():
            paths.append(path)
        elif path.is_dir() and path != BROWSER:
            paths.extend(member for member in path.rglob("*") if member.is_file())
    paths.extend(RUNTIME / name for name in HELPERS)
    return checked_paths(paths)


def native_paths():
    require(BROWSER.is_dir(), "Exact native Edge evidence folder is missing")
    # Includes the actual screenshots with names such as change-preview.png, not only prefix files.
    paths = [path for path in BROWSER.rglob("*") if path.is_file()]
    paths += [path for path in (ROOT / "output/playwright").glob("MVP-402-*.png") if path.is_file()]
    require(
        any(path.suffix.lower() == ".png" for path in paths), "Native screenshot originals missing"
    )
    return checked_paths(paths)


def source_paths():
    paths = list((ROOT / "apps/api/app").rglob("*.py"))
    paths += list((ROOT / "apps/api/alembic").rglob("*.py"))
    paths += [path for path in (ROOT / "apps/web/src").rglob("*") if path.is_file()]
    paths += list((ROOT / "apps/api/app/tests/fixtures").glob("*.json"))
    paths += [
        ROOT / name
        for name in (
            "packages/contracts/openapi.json",
            "packages/contracts/schema.d.ts",
            "apps/web/vite.config.ts",
        )
    ]
    return checked_paths(paths)


def fingerprint(paths):
    return {path.relative_to(ROOT).as_posix(): sha(path.read_bytes()) for path in paths}


def terminal_browser_run(folder, checkpoint_min, checkpoint_max, bind_current_source):
    driver = json.loads((RUNTIME / folder / "manifest.json").read_text(encoding="utf-8"))
    launch_path = RUNTIME / (folder + "-launch.json")
    launch = json.loads(launch_path.read_text(encoding="utf-8"))
    require(
        launch["exit_code"] == 0 and launch.get("finished_at"),
        "Browser runner is not terminal exit0",
    )
    require(
        launch["log_sha256"] == sha(launch_path.with_suffix(".txt").read_bytes()),
        "Launch log hash mismatch",
    )
    require(
        driver["status"] == "DB_CHECKPOINTS_COMPLETE" and driver.get("finished_at"),
        "Driver not complete",
    )
    require(
        driver["temporary_database_exited"] is True and driver["generated_database_absent"] is True,
        "Generated database cleanup lacks actual terminal proof",
    )
    require(
        driver["changed_during_run"] == [] and launch["changed_during_run"] == [],
        "Browser source changed",
    )
    require(
        all(
            row.get("exit_code") is not None and row.get("closed_at") for row in driver["processes"]
        ),
        "Owned server process is not closed",
    )
    checkpoints = driver["checkpoints"]
    require(
        checkpoint_min <= len(checkpoints) <= checkpoint_max
        and [row["sequence"] for row in checkpoints] == list(range(1, len(checkpoints) + 1))
        and all(row["status"] == "PASSED" for row in checkpoints)
        and checkpoints[-1]["instruction"]["operation"] == "FINISH",
        "Required actual sequential checkpoints not passed: " + folder,
    )
    if bind_current_source:
        # The post-fix fragment owns closure binding; the first12 remain historical originals.
        for name, digest in driver["source_after"].items():
            path = ROOT / name.replace("\\", "/")
            require(
                path.is_file() and sha(path.read_bytes()) == digest,
                "Post-fix browser-tested source changed: " + name,
            )
    return {
        "folder": folder,
        "driver_status": driver["status"],
        "runner_exit_code": launch["exit_code"],
        "checkpoints": len(checkpoints),
        "temporary_database_exited": True,
        "generated_database_absent": True,
        "source_subset_matches_at_closure": True if bind_current_source else None,
        "historical_source_at_run": driver["source_after"] if not bind_current_source else None,
        "boundary": "DB checkpoint proof; root separately reviews native UI business acceptance",
    }


def terminal_browser_gate():
    historical = terminal_browser_run("MVP-402-browser-first", 12, 12, False)
    post_fix = terminal_browser_run("MVP-402-browser-goal-epoch", 3, 4, True)
    driver = json.loads(
        (RUNTIME / "MVP-402-browser-goal-epoch/manifest.json").read_text(encoding="utf-8")
    )
    carries = [
        row["oracle"]["income_epoch_carry"]
        for row in driver["checkpoints"]
        if row.get("oracle", {}).get("income_epoch_carry")
    ]
    require(carries, "Post-fix fragment lacks an actual strict income epoch carry checkpoint")
    return {
        "historical_first12": historical,
        "post_fix_closure_source": post_fix,
        "post_fix_income_epoch_carry": carries,
        "boundary": "Root separately reviews new actual reliable0/shortfall UI; no archive verdict",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    if not args.archive:
        parser.error("Prepared helper only; explicit root --archive is required")
    require(not OUTPUT.exists(), "Never replace evidence from a prior closure")
    gate = terminal_browser_gate()
    groups = {
        "raw-runtime.zip": runtime_paths(),
        "native-edge-command-logs.zip": native_paths(),
        "source-at-closure-snapshot.zip": source_paths(),
    }
    before = {name: fingerprint(paths) for name, paths in groups.items()}
    require(
        not (set(before["raw-runtime.zip"]) & set(before["native-edge-command-logs.zip"])),
        "Raw/native member groups overlap",
    )
    OUTPUT.mkdir()
    records, bundles = [], []
    for name, paths in groups.items():
        target = OUTPUT / name
        with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for source in paths:
                member = source.relative_to(ROOT).as_posix()
                data = source.read_bytes()
                require(
                    sha(data) == before[name][member], "Input changed before ZIP write: " + member
                )
                archive.writestr(member, data)
                records.append(
                    {
                        "original": member,
                        "zip": target.relative_to(ROOT).as_posix(),
                        "member": member,
                        "sha256": sha(data),
                        "bytes": len(data),
                    }
                )
        with zipfile.ZipFile(target) as archive:
            require(set(archive.namelist()) == set(before[name]), "ZIP member set mismatch")
            for source in paths:
                member = source.relative_to(ROOT).as_posix()
                require(
                    archive.read(member) == source.read_bytes(),
                    "Raw byte comparison failed: " + member,
                )
        bundles.append(
            {
                "path": target.relative_to(ROOT).as_posix(),
                "sha256": sha(target.read_bytes()),
                "bytes": target.stat().st_size,
                "members": len(paths),
            }
        )
    after = {
        "raw-runtime.zip": fingerprint(runtime_paths()),
        "native-edge-command-logs.zip": fingerprint(native_paths()),
        "source-at-closure-snapshot.zip": fingerprint(source_paths()),
    }
    require(before == after, "Input membership or bytes changed during closure archive")
    index = {
        "archived_at": datetime.now(UTC).isoformat(),
        "classification": "RAW_CLOSURE_ARCHIVE_INCLUDES_RED_AND_DESIGN_NOT_AGGREGATE_TEST_PASS",
        "code_commit_before_closure": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "browser_terminal_gate": gate,
        "source_at_closure": before["source-at-closure-snapshot.zip"],
        "bundles": bundles,
        "records": records,
        "exact_source_and_log_bytes_verified": True,
        "source_and_member_set_unchanged_during_archive": True,
        "excluded_scope": "MVP-403 and caches excluded; partial/pending/tmp/lock abort archival",
    }
    with (OUTPUT / "index.json").open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(index, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                "zip_members": len(records),
                "source_files": len(before["source-at-closure-snapshot.zip"]),
                "bytes_preserved": sum(row["bytes"] for row in records),
                "bundles": bundles,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
