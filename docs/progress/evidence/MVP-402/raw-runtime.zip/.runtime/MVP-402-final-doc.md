# MVP-402 策略中心与目标页

**COMPLETE（定向验收）**，2026-10-05，**19/92**；目标ACTIVE，下一项MVP-403。初版、完整版均未完成。完整关闭记录见[index.json](evidence/MVP-402/index.json)，本次没有全量验收。

## 完成内容与文件

Web `App` / `PolicyCenterPage` / `PolicyConfigForm` / `policy-form` / `api/policies`：导航、真实离线编译与候选修订、原编译只读恢复、明确确认、修改前后边界、版本历史、暂停、撤销及到期。409保留草稿并废弃旧预览；网络中断在当前编辑器重试同一冻结命令。`GoalsPage` / `api/goals`：金额、期限、月度范围、核验归属现金/本金与其中自主配置本金、当前资产策略、默认禁止跨目标，明确选择本人账户后建立零归属及只读规划。

API `policy_preview` / `policy_preview_types` / `financial_read` / `domain/policy_change_types`：复用真实资金上下文的明示假设比较。`dependencies` 在首次DemoUser SELECT前设置RR/READ ONLY。`policy_compilation` 强验原件后只读恢复；`policy_lifecycle` 仅释放确定无经济效果的资源，保留SUBMITTED/UNKNOWN原身份和预留。实际OpenAPI/TS已生成同步。

`goals.py`：完整验证原收入、银行位置、余额和旧归属/月来源后，用现有`replace_proof`仅继承`as_of`。旧来源、金额、收入时钟、位置、预留、归属与月份不变；缺失/坏源不补造，跨月不伪造本月零贡献，重复建立仍提前返回且零写。旧收入不取得新策略资格。新回归`test_goal_creation_income_epoch.py`，另有预览/纯域/编译reader/生命周期及Web页面测试。旧`goal_fixture`只修可信setup的完整敞口refresh，65原assert保留。没有模型或迁移变更，使用现有隔离模拟种子与真实候选示例。

## 设计选择

假设预览验证原版本/事实，复制财务输入并传明确假设，不制造确认版本或银行证据，不在ORM写入后rollback假充只读。暂停/撤销保留原义务、归属、持仓和在途记录。确认前无新增权限，未来收入不扩大执行边界。

## 实际命令与结果

每批原命令、退出码、日志和源指纹见raw-runtime ZIP；真实Edge命令与页面截图见native-edge-command-logs ZIP；关闭源码见source-at-closure-snapshot ZIP。全部业务验证在隔离模拟库，未对正式库seed/reset或资金写入。

- `.venv/Scripts/python.exe -m pytest ... --no-cov -vv -x`：纯域**157PASS/10.89s**（35新增+122原），Ruff/format/mypy0。
- Web原相关**26PASS**与lint/tsc/build0；两处文案改变后相关**9PASS**与lint/tsc0，其他17行为未变复用。旧build属于文案修订前源码，不称新bundle。实际生成OpenAPI/TS通过。
- 原定向PG **23GREEN**：预览7、dashboard11、reader1、生命周期2、月度2。epoch修后两个生命周期与未来目标节点已重跑，其余按实际依赖复用。
- epoch实际**RED 1FAIL/4.06s**：ledger/Goal epoch失配。修后首正例**1PASS/3.79s**；扩展及直接相关**10PASS/62.55s**，覆盖多Goal、legacy缺证、native坏hash、跨月不补贡献、真实分配/重试、UNKNOWN原claim与非空prepared income身份。源码运行中不变，句柄终态。
- `.runtime/drive_mvp402_browser.py --run`：修前真实**12 checkpoint PASS**，5只读全24表不变、7策略/零Goal变化保全原金融银行记录；原编译、边界预览、确认、修改、版本、暂停、撤销、月范围补齐、390px页面有实际证据。该组绑定修前源码。
- `.runtime/drive_mvp402_goal_epoch.py --run`：修后真实**4 checkpoint PASS**，2只读全24表不变；仅新增两个准确零opening及合法纯时点继承，原经济内容与银行流水不变。实际GET为MINIMUM_SHORTFALL、eligible/suggested=0、shortfall=180000、source_issues=[]。root已查看实际`goals-epoch-green.png`，页面显示建议¥0.00/最低缺口¥1,800.00。此组绑定关闭源码。

两个driver实际exit0，自有API/Vite关闭，两个生成库均不存在。截图为原生浏览器页面捕获，不代表Windows全屏。历史RED、错误oracle、旧夹具不足及selector/同步错误原样保留，不改写失败为成功。

## 耗时、限制与下一项

epoch正例seed0.857s/建立0.206s/预览核验0.195s。扩展最慢为已有UNKNOWN22.09s、未提交撤销12.53s、实际归属执行8.42s；新多Goal1.80s、跨月1.61s。修后driver220.47s含人工和同步等待，不是产品延迟。原401黄金802.35s及末GET82/89s瓶颈仍存在。

默认单模拟用户，无真实银行/登录/RBAC；重试不跨刷新保存。旧fixture其他消费者未全跑，不以两个月度节点宣称全绿。全量只在初版25项、完整版92项完成时用最终源码验收，节点失败修复后可重跑。

MVP-403前置满足：实际决策详情/回执/审计状态可读。下一项实现八层轨迹页；专用历史JSON解析隔离坏声明原文与计算金额，不放宽402默认金额校验。
