# Future goal preview oracle correction

First affected batch: 5 passed / 1 failed / exit1, source unchanged, raw retained. Failure was expected 20000 in before protected_cents_by_reason.goal_minimum, actual0. This field reports the constraining date, not the future policy's standalone horizon minimum. October's issued bill constrains the actual seed, while the original future version starts November.

Independent current/constraining cash calculation: 3462400 cash - 160000 unassigned goal cash -145000 issued card bill -100000 real emergency buffer =3057400 before. Hypothetical current-month goal min is 3 months *10000 minus actual current contribution0 =30000, after3027400. Before November/December commitment20000 is on less restrictive later days; it cannot be substituted into October's limiting protection.

Only this new test oracle corrected to assert actual current protection0/30000, safe3057400/3027400, delta-30000; production/domain unchanged. Missing real monthly proof still must remain unknown, no zero assumption. Reuse the prior5 GREEN behavior; remaining17 nodes and failed node still require actual execution.

## Corrected analysis after second real RED

The preceding draft wrongly treated protected_cents_by_reason as the constraining-day record; actual legacy core returns trace[0], today's protection. The second RED accurately showed before safe3037400, not3057400. Reading the retained core return and payment loop confirms today's goal layer0 but the later worst cash has already paid the145000 bill and also protects the20000 future goal commitment. All old core behavior is frozen/equivalent; no production change.

Correct independent horizon calculation: 3462400 -145000 actual projected bill payment -160000 goal cash -100000 emergency -20000 future goal minimum =3037400 before. After goal minimum is30000 with the same paid bill/actual monthly source, safe3027400 and delta-10000. Today's layers remain0/30000. Final assertions bind both temporal meanings; missing actual monthly proof must still produce null. Both real RED originals retained, prior5 GREEN reused.
