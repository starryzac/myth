"""Offline AST proof for the authorized zero-goal income epoch carry change."""

import ast
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
relative = "apps/api/app/services/goals.py"
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
original = subprocess.check_output(["git", "show", f"HEAD:{relative}"], cwd=repo)
current = (repo / relative).read_bytes()
before = ast.parse(original.decode("utf-8"))
after = ast.parse(current.decode("utf-8"))
added_helpers = [
    node for node in after.body
    if isinstance(node, ast.FunctionDef) and node.name == "_income_epoch_sources"
]
assert len(added_helpers) == 1
after.body.remove(added_helpers[0])
function = next(
    node for node in after.body
    if isinstance(node, ast.FunctionDef) and node.name == "create_goal_projection"
)
additions = [
    ast.parse("income_epoch_sources = _income_epoch_sources(session, user_id, policy_id, now)").body[0],
    ast.parse("from app.services.recovery_projection import replace_proof").body[0],
    ast.parse(
        'for previous in income_epoch_sources:\n'
        '    replace_proof(session, previous, {**previous.content, "as_of": now.isoformat()}, now, goal.id)'
    ).body[0],
]
for added in additions:
    matches = [node for node in function.body if ast.dump(node) == ast.dump(added)]
    assert len(matches) == 1
    function.body.remove(matches[0])
assert ast.dump(before) == ast.dump(after)
result = {
    "observed_at": datetime.now(UTC).isoformat(),
    "baseline_commit": commit,
    "baseline_sha256": hashlib.sha256(original).hexdigest(),
    "source_sha256": hashlib.sha256(current).hexdigest(),
    "preserved_original_module_ast": True,
    "only_added_helper": "_income_epoch_sources",
    "only_added_create_statements": [ast.unparse(node) for node in additions],
    "scope": "Offline AST/source only; no imports of application modules or database actions.",
}
output = repo / ".runtime/MVP-402-goal-epoch-frozen-ast.json"
with output.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
