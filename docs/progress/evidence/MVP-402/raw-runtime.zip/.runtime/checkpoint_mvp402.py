import json,sys,time
from pathlib import Path
root=Path.cwd();dest=root/'.runtime/MVP-402-browser-first'
sequence=int(sys.argv[1]);mode=sys.argv[2];label=sys.argv[3];artifacts=sys.argv[4:]
ready=json.loads((dest/'ready.json').read_text(encoding='utf-8'))
assert ready['sequence']==sequence
command={key:ready[key] for key in ['run_id','sequence','nonce']}
command.update(operation='FINISH' if label=='finish' else 'CHECKPOINT',mode=mode,label=label,artifacts=artifacts)
target=root/ready['command_file'];assert not target.exists()
pending=target.with_suffix('.pending');pending.write_text(json.dumps(command,ensure_ascii=False,indent=2),encoding='utf-8');pending.replace(target)
deadline=time.monotonic()+15
while time.monotonic()<deadline:
    try:manifest=json.loads((dest/'manifest.json').read_text(encoding='utf-8'))
    except json.JSONDecodeError:time.sleep(.05);continue
    if manifest['status'].startswith('FAILED') or manifest['status']=='ABORTED':raise RuntimeError(manifest.get('error'))
    if label=='finish' and manifest['status']=='DB_CHECKPOINTS_COMPLETE':break
    next_ready=json.loads((dest/'ready.json').read_text(encoding='utf-8'))
    if label!='finish' and next_ready['sequence']==sequence+1:break
    time.sleep(.1)
else:raise TimeoutError('No acknowledged checkpoint')
print(json.dumps({'checkpoint':sequence,'mode':mode,'status':manifest['checkpoints'][-1]['status'],'next_sequence':None if label=='finish' else next_ready['sequence']}))
