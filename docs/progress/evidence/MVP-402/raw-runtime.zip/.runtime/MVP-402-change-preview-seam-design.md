# MVP-402 change-preview：实际事实与反事实参数接缝

`DESIGN_ONLY` / `NOT_IMPLEMENTED` / `NOT_TESTED`。读取 `.runtime/MVP-402-design.md` 和当前源码；未启动 PostgreSQL、pytest、API/CLI/浏览器或资金动作。仅写 ignored 文档，401 当前 11 金融节点仍由 root 运行；这不表示402已开始或完成。

## 最小结论

同一个 RR/READ ONLY Session、同一 trusted now 可以支持 before/after 比较，但现 `clone_boundary_context` 本身不提供可信策略替换。必须显式区分 **真实 current-version 及确认证据** 与 **假设本次修改在此时确认后的金融参数**。

不能生成假 `PolicyVersion`/`EvidenceItem`/accepted confirmation，也不能将候选配置塞进旧 `BoundaryPolicyVersion` 再附旧 confirmation evidence IDs。建议最小增加 `PolicyChangeAssumption` 和纯金融计算的内部参数 overlay；原 before/执行接口保持只读实际授权，不向执行/银行/303录制输出假版本。

## 实际源码接缝

| 当前接缝 | 实际行为 | 402 使用方式 |
| --- | --- | --- |
| api/dependencies.py:get_session | GET统一RR；audit POST RR；READ ONLY仅audit/dashboard，在User SELECT之前 | 新preview POST必须在依赖首连接处同时RR+RO，不能 service 开始查询后补隔离级别 |
| boundary.py:load_boundary_context | BANK_CONFIRMED现金/账单/持仓/目标/证明、真实保护策略与生活估计、恢复exposure，返回strict snapshot | 使用同一session加载 actual basis，不接受客户端现金/来源金额/预留/归属/时间 |
| boundary.py:clone_boundary_context | 浅copy Sources并独立used/issues/evidence字典；snapshot/versions/configuration/positions/products仍共享 | 只分离bookkeeping；禁止在clone上原地改配置、snapshot列表/嵌套dict或ORM对象 |
| dashboard.py:get_dashboard（360起） | capacity→context→独立bank projection→完整asset exposure→已有income ledger→当前epoch audit→整合source issues/digest→金融计算 | 提取这一段请求局部只读basis，供dashboard/preview复用；不调用整个dashboard两次，不重复核验历史或分页动作 |
| policy_lifecycle.py:effective_status | 校验真实确认/绑定/hash、exclusive结束、暂停/撤销、未来开始；纯读 | 读取实际状态，不能把候选配置提交给它并伪造确认来得到ACTIVE |
| policy_lifecycle.py:_window | 用户时区，start默认now，valid_until日期的下一日零点排他；检查区间 | 候选canonical经验证后可复用，完全真实User+trusted now，无假User/客户端时钟 |
| policy_lifecycle.py:_evidence | 默认锁；lock=False完整读/hash/validity/tenant/发现及编译链校验 | 预览只用lock=False，复用完整来源校验；不能拿源ID存在代替有效原件 |
| policy_lifecycle.py:_goal_asset_reference | 同用户资产策略、goal scope、信用卡账户存在与type；无FOR UPDATE | 候选参数引用沿真实PATCH规则核验，不能因存在就声称有执行权 |
| policy_lifecycle.py:_user/_policy/_refresh_one/_invalidation/_append_version/_project_goal | sharedgate/锁、状态/动作/版本/证明/审计写入 | 全部禁止调用；不write-then-rollback、不savepoint preview |
| domain/boundary.py:_compute_boundary_core | strict DTO复验、配置hash/window/事实守恒、91日三边界金融公式；BoundaryPolicyVersion含真实confirmed_at/evidence | 原入口不放宽；新增明确反事实参数路径，共用公式但不构造假确认证据 |

共享 basis 仍按401实际规则展示audit状态：INTEGRITY_ERROR进入source issues；LEGACY_UNAUDITED/INCOMPLETE等独立展示，不将历史缺口变VALID，也不在402偷偷改金融判定政策。银行/收入/归属/持仓真实性问题在两边保留。

## 请求、实际验证与假设元数据

只接 `{expected_version_id, configuration}`，extra forbid。允许用户编辑严格配置中本来存在的策略金额参数，它们是待确认假设；当前余额、现金归属、本金、已有贡献、真实账单/支付/未来本金时间和输出delta均从服务端实际事实产生。不得接受客户端总资产、安全闲置或计算后金额作事实。

按tenant过滤读Policy和按version_number读全历史，不锁；最新ID必须等于expected，否则STALE_POLICY_VERSION。candidate由 `validate_configuration` 规范化，保持旧policy_type，沿 `_goal_asset_reference` 校验。原来源依旧 `_evidence(...lock=False)` 完整检查，包括旧 confirmation 原件；坏事实/审计不能凭候选配置抹除。

为了与真正 `change_policy` 的状态校验相同：先纯读 `effective_status`，模拟 `_refresh_one` **仅当返回ACTIVE/CONFIRMED/EXPIRED时**会更新列的结果，再按ACTIVE/CONFIRMED/SUSPENDED检查可修改。不能只查raw ACTIVE：旧结束时点已过会在真正PATCH中变EXPIRED并拒绝修改。不要把 PROPOSED 显示状态自动当成新合法确认，原源错误仍保留。

`PolicyChangeAssumption` 只由service建立：actual user/policy/source_version IDs、canonical配置及其digest、server `assumed_confirmation_at=now`、`_window` 算出的assumed_start/end、假设修改后的column/effective状态、标记 `HYPOTHETICAL_CONFIRMED_CHANGE`。**不含新version_id、新evidence_id、accepted confirmation记录。** 旧IDs只是actual source引用，不是“新版本已获确认”的身份。preview_only/financial_only固定true；不输出 execution_eligible=true、不保存303/304决策/事件。

## 推荐最小纯域扩展

不要直接把 `replace(current_version, configuration=new, content_hash=newhash, confirmed_at=now)` 投喂现actual入口。虽然Pydantic构造可成功，这会令旧version/evidence看似证明了新配置。

可给金融core增加一个私有可选、strict的assumption参数；原 `compute_boundary/compute_boundary_with_details` 只走None路径，原v1产物/hash保持不变。新增显式 `compute_policy_change_boundary(actual_snapshot, actual_versions, actual_positions, actual_products, assumption)`：

1. 实际完整输入仍按原strict DTO、tenant/identity/version/config hash与事实守恒验证；公开actual输入不接受跳过标志。
2. 在内部建立独立金融参数表（真实参数来源或显式假设来源），只在目标policy的参数槽替换canonical配置、假设起止和known-from。actual版本/证明列表原封不动；实际现金/账单/归属/本金/贡献/settlement对象不变。
3. 假设参数的known-from=server now；候选提供过去valid_from也不能生成回溯授权。future start按其真实UTC窗，日粒度活动仍复用原重叠公式；不以旧版本填补新版本生效前空窗。
4. 假设living计算结果单列为parameter估计，不能假装它是绑定旧version的实际估计证明。金融参数层提供本次估计值，原actual snapshot living事实仍保全。
5. 复用原金融算式及三阶段时间序列。after digest额外绑定actual fact digest + source version + canonical假设/窗/状态/preview算法版本；不可沿用before金融hash，也不可声称其为真实确认/审计hash。

after预测义务/明细不能把实际source_version_id标成“假设新版本”的确认身份。对目标假设产生的明细应显式标记HYPOTHETICAL；若既有字段仅接受真实policy_version_id，可留null并在专用预览DTO绑定assumption digest。真实账单、旧付款、目标归属证明仍保留其实际来源。不要为迎合现明细字段生成新UUID或把旧确认ID挪成新证明。

这里“私有可选参数”不是trusted绕过：actual输入和假设配置都强验，不 `model_construct`、不改当前授权边界，不向execution_context返回该假设。若为了共用公式需要内部parameter DTO，可命名 `FinancialPolicyParameters`，字段叫actual-source/assumed-known-from，避免假 `confirmed_at` / evidence_id 的事实标签。

## 五种策略的overlay边界

| kind | 可预览的金融参数 | 必须保留/无法直接重算之处 |
| --- | --- | --- |
| emergency_buffer | 严格buffer_cents、候选有效窗 | 只改应急保护参数；现金/目标归属不动。暂停中修改仍暂停，不因新配置解锁 |
| living_reserve | horizon、lookback、quantile、categories、extra_buffer及有效窗 | 用同RR的真实历史重新 `estimate_living_reserve(session,user,now,canonical)`，保留覆盖/分类/银行证据。不得取客户端reserve金额、沿用旧estimate金额或编造新Proof |
| goal_saving | target/deadline/monthly[min,target,max]/priority及有效窗 | 保留实际GoalOwnership cash+principal、当前month contribution、account绑定、持仓/原合同。最低额继续原max/min剩余额公式，不能和既有归属重复保护；降低目标也不释放既有现金/本金 |
| recurring_obligation | 未产生旧周期的exact/range未来义务参数；bill_balance配置引用 | 已有账单在snapshot中独立保护，不改真实账单due/paid/total。对已生成旧普通周期的替换必须UNKNOWN/INSUFFICIENT并明确历史核对，不能清欠后比较 |
| asset_authorization | 同类型/真实scope/ref严格验证；展示假设未来权限范围/上限 | 当前boundary `_policies`早期跳过该kind；安全闲置可能相等。持仓/exposure须按真实原配置/原银行合同先核，不因假设禁用某资产就抹掉本金或判旧合同非法。financial READY不代表新资产权限已生效 |

### recurring历史不能抹

`_policies`以各旧版本和后继confirmed_at检查 `_generated_before`，停止当前版也检查其到now。假设新增版本即使只改name，若旧current已产生周期，也会进入真实提交后的历史歧义；不能对“配置基本相同”直接返回before=after。

预览在旧历史基础上再检查 `_generated_before(current, now, zone)`。只要为true，after明确 `HISTORICAL_OBLIGATION_RECONCILIATION_REQUIRED`、safe/min-margin/delta为null；不能按候选now确认时间抹旧欠款，不能把已有完整settlement硬套新payee/新金额规则使其“失效后不保护”。现规则是保守生成检测，**即使找到已付款声明也不能自行取消该历史blocker**。bill_balance不生成普通周期，其真实账单事实始终保留。

### 读取被current参数过滤的真实事实

仅clone当前snapshot不够：`_goals`只对当前版本有当前月重叠时读取monthly proof；候选从未来生效改为本月时，before snapshot可能没有贡献fact，但DB中可能存在。after必须从同一Sources.evidence/同RR解析真实当前月Proof，复用其完整导入/ownership同as_of/complete/hash检查；没有就保持缺源，不能设0。宜从 `_goals`提取只读月证明parser，输入实际Goal和实际ownership时点，而不是制造candidate Version让它“变active”。

living现 `_policies`会按当前配置运行估计；旧lookback不足而候选短窗有真实完整覆盖时，可重新估计使**特定参数估计不足**消失。这不是忽略坏原件。需要明确issue provenance：只替换target当前version对应的参数估计issue；bank/exposure/income/goal/audit/实际源错误原样保留，不清空 Sources.issues，不根据code批量删除。反之候选长窗不足应after不足。不能把before完整issues冻结为候选必然失败，也不能把全部旧问题改成假设已修复。

## 有效窗、状态与输出

- 当前可修改的SUSPENDED改后仍SUSPENDED，绝无resume语义；REVOKED/实际已EXPIRED拒绝修改。候选结束已过的合法窗口会使假设effective EXPIRED，不能显示重新ACTIVE。
- valid_until配置日期包含整天，UTC end为本地次日零点排他。start=None默认now；过去start受known-from=now约束，未来start明确无旧版权限/保护过渡填充。
- after窗不覆盖当前91日时，候选新增策略参数不在这些天生效；实际账单/目标现金/本金仍保护。生活估计及source问题仍沿现实际读取规则处理，不在402顺手修未来策略读语义。
- before/after保留READY/LIQUIDITY_RISK/INSUFFICIENT_EVIDENCE；delta仅两边对应量均已核实时算整数分，否则null。UNKNOWN银行/未投影事实不会因参数替换消失。候选不建立退出计划/银行承诺，不改T+1本金可用时点。
- UI只展示当前事实时点的假设。真实PATCH仍要独立明确accepted+reviewed_hash+expected_version+reason/key；确认成功后重取真实策略/总览。现PATCH不验证preview fact digest，不声称资金跨请求被锁住。

## 未来最小验收（本次均未运行）

先纯域/静态：候选strict配置与原window、目标归属/现本金/贡献守恒、future空窗、过去start不回溯、暂停不恢复、bill_balance不重保护、old recurring产生历史即不足、living新旧窗独立issues、所有actual旧v1测试未变。

再root统一真实PG临时库：依赖首User查询前SHOW RR/RO；全部24表前后exact oracle相等且重复预览0写；stale/foreign/非法输入拒绝；真实目标非零cash+principal下修改min/target不搬资金；缺当前月Proof仍不足；真实历史覆盖改变lookback的估计比较；坏银行/收入/ownership/审计在after仍不可掩盖；future_start替换不回旧版；预览与随后真实确认PATCH+GET在同固定事实/时间下金融相等（不比较新version/evidence身份）。不做write-rollback、正式seed/reset或大组无关回归。401真实关闭后才开始这些实现/测试。
