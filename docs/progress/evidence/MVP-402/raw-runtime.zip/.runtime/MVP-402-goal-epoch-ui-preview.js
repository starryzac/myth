async (page) => {
  const goal = page.getByRole('article', { name: '目标 买车', exact: true });
  const previewResponse = page.waitForResponse(r => r.request().method() === 'GET' && r.url().endsWith('/allocation-preview'));
  await goal.getByRole('button', { name: '查看当前收入分配预览', exact: true }).click();
  const response = await previewResponse;
  const body = await response.json();
  const allocation = body.allocation;
  if (response.status() !== 200 || allocation.preview_only !== true || allocation.financial_only !== true || allocation.status !== 'MINIMUM_SHORTFALL' || allocation.eligible_new_funds_cents !== 0 || allocation.suggested_cents !== 0 || allocation.minimum_shortfall_cents !== 180000 || allocation.lot_allocations.length !== 0 || body.source_issues.length !== 0) throw new Error('Verified old income must remain ineligible, with actual minimum shortfall');
  if (await goal.getByRole('button', { name: /执行|划拨|购买|确认/ }).count()) throw new Error('Read-only Goal preview offered a funds action');
  await goal.getByRole('region', { name: '当前配置分配预览', exact: true }).waitFor();
  await page.waitForLoadState('networkidle');
  await page.screenshot({ path: 'F:/学校活动/工行杯/钱途有界/bounded-funds/.runtime/MVP-402-browser-cli/goals-epoch-green.png', fullPage: true });
  return { status: response.status(), request_method: response.request().method(), request_url: response.url(), body, visible_goal: await goal.innerText(), funds_buttons: 0 };
}
