"""Submit one real-UI checkpoint to an explicit prepared driver folder.

Future example (root performs actual Edge actions first):
  python .runtime/checkpoint_mvp402_folder.py .runtime/MVP-402-browser-goal-epoch \
    1 POLICY_GOAL goal-confirm .runtime/MVP-402-browser-cli/<actual-log>.txt
Label finish selects FINISH. No HTTP, database, fixture manipulation, or acceptance automation.
"""

import argparse
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder")
    parser.add_argument("sequence", type=int)
    parser.add_argument("mode", choices=("READ_ONLY", "POLICY_GOAL"))
    parser.add_argument("label")
    parser.add_argument("artifacts", nargs="*")
    args = parser.parse_args()
    destination = (ROOT / args.folder).resolve()
    if not destination.is_relative_to((ROOT / ".runtime").resolve()):
        raise ValueError("Driver folder must be inside current repository .runtime")
    ready = json.loads((destination / "ready.json").read_text(encoding="utf-8"))
    if ready["sequence"] != args.sequence or ready["run_id"] != destination.name:
        raise ValueError("Stale driver ready identity")
    instruction = {key: ready[key] for key in ("run_id", "sequence", "nonce")}
    instruction.update(
        operation="FINISH" if args.label == "finish" else "CHECKPOINT",
        mode=args.mode,
        label=args.label,
        artifacts=args.artifacts,
    )
    target = (ROOT / ready["command_file"]).resolve()
    if not target.is_relative_to(destination / "checkpoints") or target.exists():
        raise ValueError("Checkpoint must be a fresh member of the explicit driver folder")
    pending = target.with_suffix(".pending")
    with pending.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(instruction, ensure_ascii=False, indent=2))
    pending.replace(target)
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        try:
            manifest = json.loads((destination / "manifest.json").read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            time.sleep(0.05)
            continue
        if manifest["status"].startswith("FAILED") or manifest["status"] == "ABORTED":
            raise RuntimeError(manifest.get("error", manifest["status"]))
        items = [row for row in manifest["checkpoints"] if row["sequence"] == args.sequence]
        if items and items[0].get("status") == "PASSED":
            if args.label == "finish":
                if manifest["status"] == "DB_CHECKPOINTS_COMPLETE":
                    break
            else:
                next_ready = json.loads((destination / "ready.json").read_text(encoding="utf-8"))
                if next_ready["sequence"] == args.sequence + 1:
                    break
        time.sleep(0.1)
    else:
        raise TimeoutError("Checkpoint acknowledgement synchronization budget elapsed; not an SLA")
    print(
        json.dumps(
            {
                "folder": args.folder,
                "checkpoint": args.sequence,
                "mode": args.mode,
                "status": items[0]["status"],
                "next_sequence": None if args.label == "finish" else next_ready["sequence"],
            }
        )
    )


if __name__ == "__main__":
    main()
