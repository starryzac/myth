async (page) => {
  const pending = page.getByRole('article', { name: '待建立目标 买车', exact: true });
  const account = pending.getByRole('combobox', { name: '目标归属账户', exact: true });
  await account.selectOption({ label: '工行模拟活期账户 · CASH' });
  await pending.getByRole('checkbox', { name: '我已核对当前版本与账户，建立目标归属记录', exact: true }).check();
  const creationResponse = page.waitForResponse(r => r.request().method() === 'POST' && r.url().endsWith('/api/v1/goals'));
  await pending.getByRole('button', { name: '建立目标归属', exact: true }).click();
  const response = await creationResponse;
  const result = await response.json();
  const request = response.request().postDataJSON();
  if (response.status() !== 200 || result.goal?.allocated_cents !== 0 || Object.keys(request).sort().join(',') !== 'account_id,expected_version_id,policy_id') throw new Error('Zero Goal initialization contract changed');
  const goal = page.getByRole('article', { name: '目标 买车', exact: true });
  await goal.waitFor();
  await page.waitForLoadState('networkidle');
  return { status: response.status(), request, body: result, visible_goal: await goal.innerText() };
}
