"""Capture targeted Web checks only, bound to actual sources and raw output."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
COMMANDS = {
    'form': ['--dir', 'apps/web', 'test', 'src/features/policy-form.test.ts'],
    'unit': ['--dir', 'apps/web', 'test', 'src/App.test.tsx', 'src/features/policy-form.test.ts',
             'src/api/policies.test.ts', 'src/pages/PolicyCenterPage.test.tsx', 'src/pages/GoalsPage.test.tsx'],
    'typecheck': ['--dir', 'apps/web', 'typecheck'],
    'policy-page': ['--dir', 'apps/web', 'test', 'src/features/policy-form.test.ts', 'src/pages/PolicyCenterPage.test.tsx', 'src/pages/GoalsPage.test.tsx'],
    'copy-lint': ['--dir', 'apps/web', 'exec', 'eslint', 'src/pages/PolicyCenterPage.tsx', 'src/features/policy-form.ts', '--max-warnings', '0'],
    'lint': ['--dir', 'apps/web', 'lint'],
    'bundle': ['--dir', 'apps/web', 'build'],
}
def hashes():
    sources = list((ROOT / 'apps/web/src').rglob('*'))
    sources += [ROOT / 'packages/contracts/schema.d.ts']
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sources if path.is_file()}
mode = sys.argv[1]
start = datetime.now(UTC)
name = f'{start:%Y%m%dT%H%M%SZ}-{mode}'
pnpm = shutil.which('pnpm.cmd')
command = [pnpm, *COMMANDS[mode]]
working_directory = ROOT
if mode == 'copy-lint':
    bundled_node = (Path(pnpm).parent / '../../node/bin/node.exe').resolve()
    assert bundled_node.is_file()
    command = [str(bundled_node), str(ROOT / 'apps/web/node_modules/eslint/bin/eslint.js'),
               'src/pages/PolicyCenterPage.tsx', 'src/features/policy-form.ts', '--max-warnings', '0']
    working_directory = ROOT / 'apps/web'
before = hashes()
result = subprocess.run(command, cwd=working_directory, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
end = datetime.now(UTC)
log = OUT / (name + '.txt')
log.write_bytes(result.stdout)
report = {'scope': 'MVP-402 targeted frontend checks, HTTP unit fixtures only; no PG/Edge/full suite',
          'command': command, 'exit_code': result.returncode,
          'cwd': str(working_directory),
          'start': start.isoformat(), 'finish': end.isoformat(), 'seconds': (end-start).total_seconds(),
          'source_before': before, 'source_after': hashes(), 'log': str(log),
          'log_sha256': hashlib.sha256(result.stdout).hexdigest()}
manifest = OUT / (name + '.json')
manifest.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(result.stdout.decode('utf-8', errors='replace'))
print(json.dumps({'manifest':str(manifest),'exit_code':result.returncode,'seconds':report['seconds']},ensure_ascii=False))
sys.exit(result.returncode)
