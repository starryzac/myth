# MVP-402 Web 首轮交付

后续文案修正状态：发现原自然语言示例不匹配真实grammar、日历结束日期标签误写排他；root授权后仅修改 PolicyCenterPage / policy-form 两个源的展示字符串。新 `final-verification.json` 绑定 `20261004T165006Z-typecheck` / `20261004T165010Z-policy-page`（3files9PASS）/ `20261004T165104Z-copy-lint`（仅两个源）。其余17项复用首次结果；首次bundle是文案修正前的原源，未重建。原首轮freeze完整保留在 `first-freeze-verification.json`。

实际走查例和已识别流程边界见 `browser-review.md`。本批 ESLint 首次 `pnpm exec` 找不到二进制失败见 `20261004T165006Z-copy-lint.*`，改用已安装ESLint和相同bundled Node后退出0；失败原输出仍保留。

状态：前端定向验证通过并冻结，待 root 的真实 PG / Edge。不代表 MVP-402 已完整验收，更不代表初版/完整版全量通过。未改后端、packages/contracts、正式 docs；未启动浏览器或数据库；未使用 LibreOffice。

## 实现与接缝

- App 公共 shell 与实际 hash 导航；DashboardPage 保留401金融卡片与唯一 GET dashboard，原13项断言仍通过。
- PolicyCenterPage：真实策略/候选/版本，rules compile、保存修订、原编译 GET恢复原日期/问题/假设、完整配置与显式接受；修改先用 server preview，对比服务端 before/after/null，PATCH hash/规范化配置取服务端。任意配置编辑清旧预览和勾选；网络失败冻结命令保留 key/payload 重试；409不静默覆盖草稿。暂停/撤销只传当前版本并展示真实原项/在途数量；历史命令不用于当前状态；到期/撤销禁改，没有恢复按钮。
- 完整五类 DSL 字段表单，原配置字段复核、公共有效期；资产类别中文勾选而非代码/JSON编辑；金额十进制字符串→BigInt整数分→safe整数，不舍入、不以空值作0。
- GoalsPage：真实本人CASH/GOAL账户建立零归属，payload只有policy/version/account；月度[min,target,max]、日期与参数独立于dashboard verified现金/本金/合计；交叉managed不再加总、待归属仍保护；当前关联资产策略与真实产品/持仓分别展示；allocation-preview只读无执行按钮。
- API adapters类型全部来自root真实生成的schema；统一模拟标记/递归安全金额JSON入口/错误message+request_id，新增列表和预览/编译结构检查。没有手写新预览DTO、前端金融算法或前端授权hash。

## 实际最终检查

每项的 `.json` 保存 command / exit / raw log hash / before-after source；对应 `.txt` 是实际原输出。

- `20261004T163241Z-lint.*`：ESLint exit0。
- `20261004T163244Z-unit.*`：5 files / 26 passed（App14 + policy-form3 + policy API3 + PolicyCenter4 + Goals2），exit0。这些是明确 HTTP 单元夹具，不是金融E2E。
- `20261004T163247Z-bundle.*`：实际 tsc --noEmit + Vite build，exit0，86 modules，`index-Chg1rWQC.js` / `index-CQUhCX4W.css`。
- `freeze.py` 的实际结果与完整sourcehash见 `final-verification.json`。后续源变更必须重新绑定对应受影响检查。

## 原始失败保留

- `20261004T160912Z-form.*`：首次新模块未存在，collection import failure，exit1；不是完成任何金融行为测试。
- `20261004T161955Z-typecheck.*`：2处API可选reasons未guard，exit2；改用默认空数组。
- `20261004T162524Z-typecheck.*`：单元fixture的配置object缺index signature，exit2；改为Record<string,unknown>。

没有删除/覆盖失败输出，没有把它们改写为通过。后续已通过日志含对应修正源。

## 真实 Edge 提示（root执行）

- 导航a：`#overview` / `#policies` / `#goals`；策略H2“策略中心”，目标H2“目标储备”。
- 编译：label“策略描述”→button“编译候选”→按字段补齐→“保存修订候选”→未默认勾选的明确接受→“确认编译策略”。
- 原候选：button“读取原编译并修订”，修订后“保存修订候选”；表单改变禁止旧候选hash确认。
- 当前策略article aria-label“策略 ${name}”；“修改策略”→region“修改策略”→“预览修改影响”→region“修改前后资金边界”→label“修改原因”及接受→“确认修改”。
- 网络重试button“重试原修改请求”；409显示草稿保留，并显式“加载最新版本并保留草稿”后才能重新比较。
- “暂停”/“撤销”独立复核与明确勾选；版本“查看版本历史”；到期/撤销禁改。
- 新目标article“待建立目标 ${name}”→label“目标归属账户”→接受→“建立目标归属”。已建立article“目标 ${name}”。

前端当前可供真实接口验收；后端preview、生命周期占用等真实正确性仍由root检查。全量仅初版25与完整版92两个节点。
