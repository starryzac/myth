"""Bind the authorized copy patch to its targeted checks, preserving first freeze."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
first = OUT / 'first-freeze-verification.json'
if not first.exists():
    first.write_bytes((OUT / 'final-verification.json').read_bytes())
first_report = json.loads(first.read_text(encoding='utf-8'))
checks = ['20261004T165006Z-typecheck.json', '20261004T165010Z-policy-page.json', '20261004T165104Z-copy-lint.json']
reports = [json.loads((OUT / name).read_text(encoding='utf-8')) for name in checks]
reference = reports[-1]['source_after']
current = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in reference}
assert current == reference, 'Current source differs from copy patch targeted checks'
for report in reports:
    assert report['exit_code'] == 0
    assert report['source_before'] == report['source_after'] == current
    assert hashlib.sha256(Path(report['log']).read_bytes()).hexdigest() == report['log_sha256']
changed = [path for path in current if first_report['source_hashes'].get(path) != current[path]]
assert {path.replace('\\', '/') for path in changed} == {'apps/web/src/pages/PolicyCenterPage.tsx', 'apps/web/src/features/policy-form.ts'}
manifest = {'state': 'FRONTEND_COPY_PATCH_TARGETED_VERIFIED_FROZEN_AWAITING_ROOT_PG_EDGE',
            'verified_at': datetime.now(UTC).isoformat(), 'checks': checks, 'source_hashes': current,
            'changed_sources': changed,
            'changes': 'Display copy only: supported compiler example; inclusive calendar end date vs exclusive ISO end instant. No test assertions, APIs or logic changed.',
            'unit_result': 'Affected 3 files / 9 passed, HTTP unit fixtures only; prior other 17 passed reused, not rerun',
            'first_freeze': str(first),
            'reused_tests': {'manifest': '20261004T163244Z-unit.json', 'count': 17, 'scope': 'App14 + policy API3, unaffected copy semantics'},
            'bundle': {'manifest': '20261004T163247Z-bundle.json', 'source': 'original before display-copy patch', 'rebuilt': False,
                       'result': 'tsc + Vite 86 modules, JS index-Chg1rWQC.js, CSS index-CQUhCX4W.css'},
            'not_run': ['PG', 'Edge', 'full suite', 'real bank connection']}
(OUT / 'final-verification.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'state':manifest['state'], 'paths':len(current), 'checks':checks}, ensure_ascii=False))
