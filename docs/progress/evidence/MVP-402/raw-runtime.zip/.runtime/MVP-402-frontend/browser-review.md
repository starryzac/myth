# MVP-402 真实浏览器走查：只读源码核查

核查范围：当前 Web、真实 rules grammar / lifecycle / compilation reader、已生成 OpenAPI。没有运行 DB、HTTP、浏览器或测试来取得金融结果；下面是可执行步骤与源码预期，不是 Edge 通过证据。文案修正的定向检查另见 copy 批次日志。

## 明确发现与已授权最小修正

1. 原 placeholder“应急金保留2000元”不符合 `policy_compiler.consume` 的真实有限语法。合法句是“保留2000元应急金”或“始终保留2000元应急金”。原反序句的 draft 没有 type，当前表单无法补类型；需改写重新编译。现在已授权把 placeholder 改为真实支持的句子。
2. `configuration.valid_until` 是用户本地**包含当天**的日历日期。`policy_lifecycle._window` 将其 +1day 后当地00:00转换UTC，存入 `PolicyVersionView.valid_until`；后者是**不包含**的结束时点，effective_status 在 `now >= valid_until` 时 EXPIRED。共享日期标签已改“结束日期（含当天）”，ISO区间说明改“结束时点不包含”。没有改任何生命周期或输入计算。

示例：时区 Asia/Shanghai，配置开始与结束均为2026-10-05，对应有效区间 `[2026-10-04T16:00:00Z, 2026-10-05T16:00:00Z)`，2026-10-05全天在内。源码已有 `test_future_start_and_exclusive_local_end_boundary` 对应案例，但本只读批次未执行该测试。

## 可执行 P1–P7

以下目标日期示例以服务端可信编译锚点早于2027-06-30为前提，建议真实driver固定2026-10-04 Asia/Shanghai；不要用浏览器当前时间替代服务端时钟。页面导航与选择器见 HANDOFF。

| 节点 | 浏览器实际步骤 / 示例 | 真实 API 与必要字段 | 源码预期与边界 |
| --- | --- | --- | --- |
| P1 导航与总览 | 首开→资金总览→策略中心→目标储备→返回总览 | 默认首页唯一 GET `/api/v1/dashboard`；其他页按需读真实 policies/proposals/goals/accounts/positions/products | 总览卡片同一响应；实际hash链接，无403/404入口；策略当前状态取 effective_status，不取历史命令回执 |
| P2 完整目标编译 | 策略描述填“旅行目标1.2万元，截止2027-06-30，每月固定储备1000元。”→编译候选→查看字段与原假设→勾选接受→确认编译策略 | POST `/policies/compile` `{text,engine:'rules'}`；response.compilation.reference_date/timezone/issues/assumptions、外层 configuration/hash/proposal_id；POST `/policy-proposals/{id}/confirm` `{accepted:true,reviewed_hash}` | type=goal_saving；target_cents=1200000；deadline=2027-06-30；monthly min/target/max均100000；priority默认、cross_goal=false、asset_policy_id=null必须显示供复核 |
| P2 不完整目标补齐 | 填“旅行目标1万元，截止2027-06-30，每月存1000元到2000元。”→编译→每月目标金额填1500→保存修订候选→查看规范化配置→接受→确认 | 初始 configuration=null、proposal_id=null，compilation.draft有type=goal_saving、min100000/max200000，issues缺monthly target；POST `/policy-compilations/{compilation_id}/revise` `{configuration}` | 该incomplete draft已有type，实际可编辑；空白target不会变0。填齐后完整配置送服务端，不重编译原文、不改日期锚点；原 issues 仍作为原编译说明显示，外层最新 configuration/hash 才是当前候选 |
| P2 原编译恢复 | 已生成候选后刷新策略页→该候选“读取原编译并修订”→修改金额→保存修订→重新接受 | GET proposals.compilation_id→GET `/policy-compilations/{id}` 返回原 CompilationResponse；外层最新 configuration、原 compilation 不覆盖 | 表单变化清勾选，保存前禁止用旧hash确认。已确认原编译不能再次修订；无type句需改写，只有公共字段不能救成合法type |
| P3 应急修改比较 | 填“保留2000元应急金”并确认→当前应急金“修改策略”→金额改2500.01→预览修改影响→看before/after/null→填原因并接受→确认修改 | POST change-preview仅 expected_version_id/configuration；响应 PolicyChangePreviewResponse；PATCH取响应configuration/hash + reason + fixed key + expected_version | before/after完全服务端计算，风险/来源不足/null如实显示；financial_only不代表授权。任意再改字段旧预览与接受消失；同一PATCH网络重试保持原key/payload；409保留草稿并须显式加载最新版本重新比较 |
| P4 暂停撤销与版本 | 当前可修改策略→暂停→复核原版本/勾选→确认暂停→状态刷新；之后撤销同理；查看版本历史 | POST `/policies/{id}/suspend` 或 revoke仅 expected_version_id；GET policies与GET versions读取现状/不可变历史 | SUSPENDED没有恢复按钮、修改仍暂停；EXPIRED/REVOKED不能修改。回执invalidated/inflight按真实原项显示，UNKNOWN/已受理不释放或重付；inflight行为仍需root PG证据 |
| P5 有效期与到期 | 给可改策略的开始/结束日期都填2026-10-05→预览/接受修改；可信时钟在本地00:00前/当天/次日比较；刷新策略 | configuration.valid_from/valid_until=calendar dates；当前版本DTO.valid_from/valid_until=UTC instants；GET policies.effective_status | 当日有效，结束次日当地00:00排他；状态取服务端。当前UI没有后台计时轮询；注入时钟后需刷新策略、重新进入或重新加载取新状态，不靠Date.now本地授权 |
| P6 零目标建立与归属 | 上述旅行目标确认后进入目标储备→待建立目标→选真实本人CASH/GOAL账户→接受→建立目标归属→查看月度与已核验现金/本金 | POST `/goals` 仅 policy_id/expected_version_id/account_id；GET goals给参数，GET dashboard.goal_ownership给proof归属；positions/products给实际放置 | 建立初始零归属，不划款、不认领账户已有待归属现金；分账户GOAL余额仍保护。目标金额/合计不是现金；managed本金属于归属交叉，不能重复加总；无asset_policy不自动选一般闲置授权 |
| P7 真实只读规划与错误 | 目标“查看当前收入分配预览”；有真实asset_policy关联才看当前资产规划；断开接口/409看错误提示并安全重读 | GET `/goals/{id}/allocation-preview` / `/asset-policies/{id}/allocation-preview`；allocation.preview_only/financial_only、as_of、nullable amounts、reasons；ErrorEnvelope.error.code/message/request_id | 这些是当前配置规划，不是修改比较，也没有执行按钮；源不足显示待核验，不替代银行确证。不同HTTP查询不宣称一个事务快照 |

## 潜在用户流程限制（源代码发现，不是假实测）

- 没有type的未理解文本无法从现有表单直接选类型，需改写后重新编译；当前真实支持示例已修好，不能把“任意自然语言都可表单修复”作为验收承诺。
- 尚未形成proposal的不完整编译只保存在当前组件state；离开/刷新后候选列表无该编译的入口，因为 POST compile未形成proposal。GET reader能按已知compilation_id读，但没有编译列表/无界入口，页面也不持久存储这个id。完整候选与已修订候选可由 ProposalView.compilation_id恢复。此限制应与“已有候选的原编译恢复”区分。
- 纯发现候选无compilation_id，当前只读配置并确认完整候选，没有通用候选revise API；结构不完整者禁确认。五类已确认策略均可用真实完整表单修改。
- compile页面保留的是原issues/assumptions；完成补齐后原issues不会消失，它们不是最新保存失败。当前规范化配置单独复核；若用户困惑，可在后续明确提示“原编译问题已保留供追溯”，本轮没有改逻辑。
- 当前失联PATCH的key/payload在当前编辑组件内固定；直接导航离开或刷新会丢弃组件state。真实driver本轮应在同一编辑器用“重试原修改请求”核对同key；跨刷新命令恢复不应被宣称已实现。
- P5真实到期需要新的服务端读取。不要把静态截屏上一刻ACTIVE或生命周期结果当成可信时钟变化后的实时现状。

冻结文案修正后实际仅重跑受影响3files9tests（策略4、共享form3、目标2）、tsc与两个改动源的ESLint。其他17项、原bundle复用且绑定旧源，未重建bundle、未运行PG/Edge。新的freeze记录具体区分。
