# MVP-402 策略中心与目标页：只读接缝设计

日期：2026-10-04。状态：DESIGN_ONLY，等待 MVP-401 实际验收关闭。这里只读原计划、现有 API / 服务 / OpenAPI / 测试源码，未运行 PostgreSQL、HTTP、Edge 或测试，未修改任何生产、测试、合同或正式 docs 文件。没有实测效果数字。

## 1. 原计划的明确范围

依据 `钱途有界_初版开发计划_Codex执行版.md:635–651、784–787`：

- 策略中心：活动策略、候选、版本历史、有效期、暂停/修改/撤销、首次确认前结构化预览、变更前自主资金边界影响预览。
- 目标页：目标金额、截止日期、进度、月度 `[min,target,max]`、归属与资产放置分开、当前资产策略、不得默认跨目标挪用。
- MVP-402 直接验收：用户在修改策略前能预览自主边界影响。

本项不提前加入资金事件控制台（404）、决策轨迹页（403）、暂停后恢复接口、365 日引擎、完整策略关系图（FULL-703）或跨目标资金执行。

## 2. 已经存在的接口（核对了当前正式 OpenAPI）

| 业务 | 现有接口与返回 | UI 可直接复用的行为 |
|---|---|---|
| 候选列表 | GET `/api/v1/policy-proposals` → ProposalView | source_text / source_type / compiler_version / evidence_ids / configuration / configuration_hash / validation_ready / status / confirmed_policy_id。结构完整不等于证据有效或已授权。 |
| 历史发现 | POST `/api/v1/policies/discover` | 服务端可信事实生成候选，客户端无时间、金额或权限注入。只有用户点击“发现候选”时调用。 |
| 自然语言输入 | POST `/api/v1/policies/compile` `{text,engine:'rules'}` → CompilationResponse | 完整与不完整结果均有 compilation_id；原始 compilation 具有 reference_date、timezone、draft、issues、assumptions。仅 goal_saving / emergency_buffer 支持编译。 |
| 编译候选修订 | POST `/api/v1/policy-compilations/{id}/revise` `{configuration}` | 复用原日期锚点；本次有效配置在外层 configuration，不把原 compilation.configuration 当成编辑后结果。同源新草稿使旧候选过期；已确认后改走策略 PATCH。 |
| 首次确认 | POST `/api/v1/policy-proposals/{id}/confirm` `{accepted:true, reviewed_hash}` | 摘要必须是刚展示的服务端规范化配置摘要；独立明确确认，不能把编译成功当成确认。 |
| 当前策略 | GET `/api/v1/policies` → PolicyView | status / effective_status / version_authorized / current_version / updated_at。使用 effective_status 判断到期和未来生效，不能只看数据库 ACTIVE。 |
| 历史 | GET `/api/v1/policies/{id}/versions` | 版本号升序；旧 configuration、confirmation、evidence_ids、content_hash、previous_hash、change_reason、valid_from/until、impact_analysis。 |
| 修改 | PATCH `/api/v1/policies/{id}` | 完整 configuration / expected_version_id / reviewed_hash / accepted / reason / idempotency_key；追加版本且不改类型。只允许 ACTIVE / CONFIRMED / SUSPENDED；暂停中修改仍暂停，已撤销/到期不能修改复活。 |
| 暂停/撤销 | POST `/api/v1/policies/{id}/suspend` 或 `/revoke` `{expected_version_id}` | 不删除历史、不自动回拨现金/归属/持仓。返回失效旧动作和待对账原动作。没有 resume API。 |
| 目标列表 | GET `/api/v1/goals` → GoalView | 配置投影、goal_id / policy_id / policy_version_id / account_id、目标和月度范围、优先级、跨目标 flag、asset_policy_id。allocated_cents 不能同时充当现金与本金。 |
| 建立目标 | POST `/api/v1/goals` `{policy_id,expected_version_id,account_id}` | 仅已确认当前有效 goal_saving；明确选择自己的 CASH/GOAL 账户。真实建立零归属与零当月贡献证明，不移动已有资金；同参数重复返回原目标，不能改绑账户。 |
| 目标分配预览 | GET `/api/v1/goals/{id}/allocation-preview` | 当前真实收入来源的分配规划，preview_only；不是策略配置替换后的边界影响。 |
| 当前资产规划 | GET `/api/v1/asset-policies/{id}/allocation-preview` | 当前正式资产授权下的配置候选。也不是更改资产授权配置的比较预览。 |
| 原始账户/持仓 | GET `/api/v1/accounts/summary`、`/positions`、`/products` | 目标账户选择与当前产品/持仓明细。手工持仓要如实单列。 |
| 已验证归属与本金 | GET `/api/v1/dashboard` | goal_ownership 的现金/本金/合计归属与 managed_assets/by_goal 可复用展示；两者存在交叉。保留查询时点与核验状态。 |

LifecycleResult 是首次命令的历史回执，含 invalidated_action_ids、inflight_action_ids、requires_recompute；操作成功或幂等重放后必须重新 GET policies / versions / goals / dashboard。不得拿历史 ACTIVE 回执渲染当前权限。

服务端日期按用户时区日界，valid_until 配置日期包含当日，版本 effective_until 为次日零点排他。未来 valid_from 保持 CONFIRMED，不能沿用被替换旧版本填补生效空窗。

## 3. 必须补齐的修改预览

现有 OpenAPI 没有 policy-change-preview。GET `/boundary` 不接收配置且 extra='forbid'；PolicyVersion.impact_analysis 当前只有 lifecycle_result，没有金融 before/after。浏览器自行减应急金、重算目标最低额或用 allocation-preview 假充比较均不符合验收。

建议最小新接口：POST `/api/v1/policies/{policy_id}/change-preview`。

请求仅 `{expected_version_id, configuration}`，extra='forbid'。不接 accepted、user_id、as_of、cash、source_evidence_ids、状态或权限 flags。理由和最终命令键留在确认 PATCH，预览不写任何候选/版本/审计/银行对象。

响应建议正式 DTO（待 root 在 402 实现和生成合同，不由前端手写）：

- schema_version / simulation=true / preview_only=true / financial_only=true；真实 user_id、可信 as_of、timezone。
- policy_id、expected_version_id、规范化完整 configuration、configuration_hash、假设确认后的有效起止与策略状态。
- 同一金融事实基准的 before / after FinancialBoundaryCard 或明确等价的轻量比较 DTO；null 与来源不足保留，91 日口径一致。
- delta_safe_idle_cents / delta_minimum_margin_cents 仅在双方对应值都已核验时由服务端计算，否则 null。
- current_fact_input_digest、hypothetical_input_digest、来源问题与“假设用户确认此配置”的说明。后者是反事实参数摘要，不是新的确认/银行事实。
- would_invalidate_action_ids、would_require_reconciliation_action_ids 可选只读预测；明确与真正 PATCH 后的 invalidated/inflight 回执区分。没有安全纯读分类接缝时宁可省略，不能调用写函数拿结果。

只需 CHANGE 比较先满足修改验收；SUSPEND / REVOKE 若复用同一反事实框架，采用严格区分的 operation DTO，不能将任意客户端 status 当权限。暂停/撤销确认弹层至少展示真实策略、版本、已归属资金保留和原操作待核对语义。

### 服务端实现接缝与禁止捷径

1. `app/api/dependencies.py:get_session` 当前只为 GET 或 audit POST 设 REPEATABLE READ；READ ONLY 仅 audit/dashboard。新 POST 预览路径必须在 DemoUser 首个 SELECT 前加入 RR + READ ONLY 分支。不能在 service 中开始查询后再设隔离级别。
2. 使用同一 Session、同一 trusted now、session.no_autoflush。不能调用 change_policy / _append_version / _project_goal / _invalidation 后靠 savepoint rollback 充当预览；这些有锁、写入与审计副作用。
3. 基准须与 401 的金融读取口径一致：`load_boundary_context`、独立 validate_bank_projection、完整 asset exposure、已有 income ledger 校验、当前审计完整性与完整 sources digest。只调用旧 GET boundary 的较窄包装会漏掉 401 的银行/来源检查，可能与首页金额不一致。宜抽取 401 已验证的只读金融 basis helper，供首页与预览复用；不建立跨请求缓存。
4. `clone_boundary_context(context,user_id,now)` 已存在，隔离可变 Sources bookkeeping；`compute_boundary_with_details(snapshot,versions,positions,products)` 已存在且金融 v1 原入口兼容。新增纯反事实 adapter，替换策略参数后独立计算；不写 ORM Policy/Version/Goal，不制造 USER_CONFIRMED_POLICY 或银行零金额证据。
5. recurring_obligation 有已生成旧周期时，修改/暂停可能触发 HISTORICAL_OBLIGATION_RECONCILIATION_REQUIRED；必须复用 `_policies` 的真实历史判断，不能把候选 confirmed_at 设为现在然后抹掉旧欠款。真实账单债务始终保留。
6. 目标配置修改只改变目标承诺参数，已有 verified cash/principal/month contribution/position/source claims 保持真实值；截止日不是默认外部扣款义务。暂停/撤销/到期不能释放既有归属或跨目标本金。新目标未建立真实投影时不能构造“已核验零归属”。
7. living_reserve 修改需用同一真实历史重新估计；asset_authorization 本身不在财务 boundary 的保护策略集合内，金融安全闲置可能不变，但授权范围/上限仍需单独展示。不能把财务 READY 宣称新资产权限已满足。
8. 当前确证坏源在 after 仍不可凭替换配置抹除；同时，要区分针对被更改参数的估计不足与独立银行/归属坏源，不机械删除所有 issues 或把全量当前 issues 永久当成候选必然失败。

比较只是所示时点的假设，不是锁定经济效果、具体执行权限或锁价回执。现 PATCH 有 expected_version 与 configuration reviewed_hash，没有金融 input_digest 的原子比较要求；402 最小合同保持这一事实，显示预览时点并在提交后重取真实总览，不声称银行事实跨请求冻结。若 root 决定增加提交时基准冲突检查，必须明确新增合同并验证，不能只靠前端“刷新了一次”宣称原子锁定。

## 4. 生命周期与执行来源的潜在接缝（源码发现，尚未实测）

`policy_lifecycle._invalidation` 当前只改 ActionPlan.status→INVALIDATED 并记录审计；该文件没有 finish resource reservations、release_income_for_action 或 refresh_execution_exposure 调用。现 `execution_exposure` 的 NO_EFFECT 验证要求已失效/取消、无原银行操作/回执且 claims 已 RELEASED；PLANNED_UNRESERVED 状态又要求仍 PLANNED/AUTHORIZED。

因此 402 必须实际验证：已有 301 execution 命令的未提交动作，在 PATCH/suspend/revoke 后曝光证明、原资源与 income reservations 是否仍一致；不能在影响预览中直接把失效当成资金已经释放。若证实接缝缺失，修复在真实生命周期事务内进行：仅严格确认无经济效果的原动作释放原资源/收入占用并刷新完整曝光证明；SUBMITTED / UNKNOWN / 已受理 / 已执行仍保持原身份与占用，返回待核对。原103人工动作 fixture 可能没有 execution command，要保留其兼容性。任何证明问题不得通过削弱 NO_EFFECT 检查来掩盖。

## 5. 原编译恢复的接口缺口

CompilationResponse 提供原 issues / assumptions / reference_date，但当前没有 GET `/policy-compilations/{id}`，ProposalView 又无 compilation_id。新建输入的当前浏览器会话可保留 id 并完成 revise→confirm；刷新后只看候选列表，无法稳定取得原编译详细说明或恢复原锚点编辑。不得猜 evidence_ids[0] 或重编译原文替换旧日期解释。

若 402 要支持既有编译候选的持久编辑与完整初次复核，建议 ProposalView 增加可核验 nullable compilation_id，并提供只读 GET compilation 原记录。`policy_compilation._load` 当前使用 with_for_update，不能直接挂在只读 GET；须新增锁可选/只读 reader，复用实际内容、归属、状态、时钟与原锚点校验。非编译发现候选当前只有确认入口，没有通用 revise；不要在 UI 宣称所有候选都能编辑。结构不完整的发现候选禁用确认并说明缺失。

## 6. 具体 UI 流程

### 策略中心

- 添加可工作的总览 / 策略中心 / 目标导航；只展示已实现页面。保留 401 首页语义、金额 util 和模拟标记，可在402闭环时抽取页面组件，不在当前冻结期移动文件。
- 当前策略卡片展示类型、effective_status、当前版本号、有效期、version_authorized 的有限含义。ACTIVE 不表示必然可扣款；CONFIRMED 是尚未生效。SUSPENDED 无恢复按钮；EXPIRED/REVOKED 无“修改并重新激活”。
- 候选区展示原文、来源层级、结构完整性、全部结构字段。自然语言 rules 编译展示原日期锚点、问题、默认假设；不完整字段空白待补齐，不能 Number('')→0。LLM 默认不提供开启操作。
- 确认：结构化复核页 → 未默认勾选的明确接受 → POST confirm（服务端 hash）→ 重新读取当前列表。网络丢失不换身份；幂等重放仅作为历史回执。
- 修改：取最新版本完整配置 → 按类型表单 → 原字段/候选字段并排 → 点击服务端边界预览 → 查看 before/after/null/风险及时点 → 填修改原因并明确接受 → PATCH。
- 任意候选字段变化立即废弃旧 preview/hash/checkbox；预览只读时不发送 accepted。最终 PATCH 的 idempotency_key 对冻结的同一 payload 只创建一次，网络重试保持原 key 与 payload。新编辑才新建命令，不按点击次数换 key。
- 409 陈旧版本/复核不一致：保留未提交编辑，重取策略，废弃旧预览，要求重新查看；不自动把旧修改套到新版本。统一错误展示 message 与 request_id。
- 暂停/撤销：独立弹层展示策略名/当前版本/已有资金保留和在途说明，按钮只发送 expected_version_id。成功展示实际 invalidated/inflight 数量与原项，再刷新，不自动执行任何资金恢复或重付。
- 版本页按版本序列展示配置、确认时间、有效窗、变更原因与原哈希。配置 previous_hash 只是追溯字段，不把它称为完整审计链证明。

### 类型表单

完整保留五种已存在 DSL：recurring_obligation 的 payee/amount_rule/due/prepare/auto/priority；living_reserve 的窗口/quantile/categories/one-off/buffer；emergency_buffer 的金额；goal_saving 的目标/截止/月度range/priority/asset link；asset_authorization 的scope/goal/classes/total/single/risk/lock/delay/recovery flags。所有公共 name/valid_from/valid_until 也展示和编辑。候选编译只支持目标和应急金，不能伪装为全部类型的自然语言编译器。

金额输入用十进制字符串→BigInt整数分→明确 safe-integer 校验→JSON number；超过可精确表达范围拒绝而不舍入。不使用 parseFloat*100 / toFixed；量纲为比例的 quantile 单独校验。展示继续调用 401 formatMoneyCents。前端表单校验只改善交互，确定性配置规范化/hash/权限均以服务端为准。

### 目标页

- GET goals 的目标参数与关联 policy 当前状态、月度[min,target,max]、deadline；归属取 dashboard 已验证 cash/principal/allocated，source不足时进度与金额待核验，不能以 Goal.allocated 推测现金。
- 已归属金额可能与管理本金交叉；资产放置显示真实 positions/products 与 managed_by_goal，并区分手工持仓。asset_policy_id为空显示未绑定，不自动选择一般闲置授权或别的目标。
- 配置与 dashboard 是不同 HTTP 请求时，保留各自时点/版本；发现关联版本不符先刷新，不把多请求 join 宣称为单次事务快照。
- 新目标确认后若无 goal projection，明确“目标配置已确认，尚未建立目标归属”；独立选择真实自己的 CASH/GOAL账户并调用已有 create_goal。未创建前源不足如实保留；创建不是资金划拨。
- 修改目标走它的策略版本 PATCH，不直接修改 Goal 或 account balance。已归属资金不会因为目标金额/期限/策略状态改变而被转给别的目标。跨目标 flag 不包装成已实现跨目标执行能力。
- 若提供当前收入分配/资产规划查看入口，只显示真实既有 GET preview结果及 preview_only，不新增执行按钮。

## 7. 定向验证方案（仅计划，均尚未执行）

新后端预览模块：一份真实临时 PG 的 `test_policy_change_preview.py`（建议名）验证 READ ONLY/RR、所有表前后行/列/哈希相同、同钟同事实before/after、同租户、额外资金/时钟/权限字段拒绝、规范化hash、坏源null、目标归属不变、已生成旧周期不能消债、future生效空窗、生活估计、资产授权与财务口径分离。预览不新增审计/版本/资金记录。

直接相关回归按实际修改选择：`test_policy_api.py` 的确认/PATCH/retry/suspend/revoke与expiry；`test_policy_lifecycle.py` 的不可变版本、陈旧竞争、旧动作/在途、目标配置不移动现金/持仓；`test_policy_compilation.py` 的原锚点修订/关闭草稿不复活/原源码完整性；`test_goal_api.py` 的零归属创建和同参数重放/账户不可改绑；新纯反事实core及现有boundary直接相关测试。

涉及上述失效与占用接缝时增加对应集成：真实execution PLANNED/AUTHORIZED含无/有来源预留→修改/暂停→仅合法无效果原项释放并仍资金守恒；SUBMITTED/UNKNOWN/已受理→暂停/撤销不释放、不改键、不重扣；迁移若没有新增表/列则不为了 UI 造迁移，若实际改库则对应迁移往返测试。

前端：类型检查+ESLint+策略/目标相关HTTP单元交互（明确标注单元fixture），覆盖查看完整结构、accepted默认false、编辑废弃预览、错误/重试同key、409不能静默覆盖、历史ACTIVE回执后真实REVOKED刷新、EXPIRED禁改、null进度、归属交叉与创建目标不划款。金额新解析的精确分和safe整数反例单独验证。

真实 Edge 页面：沿真实compile→revise→候选确认→创建零目标→查看归属；修改前服务端比较→明确确认→新的版本与实际dashboard；暂停/撤销→当前effective_status/历史不变；可信注入时钟到期显示不需手工refresh命令；涉及原UNKNOWN必须保持原操作。这些由真实临时PG/API与本地Edge驱动，不能 route.fulfill 假HTTP冒充金融E2E。

只运行改动模块和直接相关集成/页面验证。全量仍集中于初版25项和完整版92项两个验收节点，失败在同节点修复再验收。

## 8. 现阶段结论

确认/修改/暂停/撤销/版本/目标创建后端大部可复用。阻止402完整验收的确定缺口是“现有配置替换前后的服务端只读比较”；原编译恢复reader取决于是否覆盖刷新后的原始候选编辑；生命周期与301来源占用接缝需要新真实集成证实，不能先宣称已坏或已修。401冻结源文件未编辑，402未正式开始。

## 9. 2026-10-05 复核：可直接实施的最小前端分工

本节仍为 DESIGN_ONLY。复核了当前真实 OpenAPI、policies/goals 路由、确定性配置模型、App、dashboard 客户端与 package.json。未启动数据库、浏览器、HTTP 或测试。只追加本 ignored 文件；生产实现必须等待 root 宣布 401 关闭并启动 402。

当前首页组件、查询与公共 shell 同在 `App.tsx`，`pages/`、`components/` 仍只有占位文件；没有路由依赖。当前复核的 `App.tsx` / `App.test.tsx` SHA256 分别是 `1779585e8ac75a0225d4f06928bc8e238df2f3689c33e9a7294751f01405e8bd` / `ef7c05ac503bdd869b0b76d39a79daa62c979e41d9090198790afb8c0bbfab65`，与正式 label-only 冻结记录一致。

### 文件边界与实施顺序（仅建议，尚未创建）

下面路径均相对 `apps/web/`。全部前端文件由 dashboard_ui owner 修改；root 负责后端服务、事务隔离、生成合同、PG 与真实 Edge 验收。不得同时让另一 agent 修改 App 或同一个客户端文件。

| 文件 | 最小职责 | 实际合同与复用 | 开始条件 / 定向检查 |
| --- | --- | --- | --- |
| `src/App.tsx` | 公共品牌、模拟标记、页脚与总览/策略/目标导航；无对应页面的入口不显示 | 不增加路由依赖，使用可返回/前进的实际 hash 导航；默认资金总览 | 402 启动后；原 App 13 条金融显示断言保留，并新增导航/返回验证 |
| `src/pages/DashboardPage.tsx` | 移入当前首页查询、状态、刷新与全部卡片，不改变任何口径 | 原 `getDashboard`、`DashboardResponse`、money/labels 保留；首页仍唯一 GET dashboard，金融卡片仍单响应 | 与 shell 同批完成；401 页面断言与工程 dashboard GET 检查只跑相关项 |
| `src/api/http.ts` | 新策略/目标客户端共用 fetch、JSON 入口安全整数检查、错误 code/message/request_id；禁止自动重试 POST/PATCH | 导入生成的 ErrorEnvelope，复用既有 `assertMoneyFields`；不为此重写已验证 dashboard parser | 无后端新增依赖；相关客户端单元检查 malformed/unsafe/4xx/network |
| `src/api/policies.ts` | 列表/候选/版本、rules compile、当前会话 revise、confirm、PATCH、suspend/revoke；服务端 change-preview 接入 | 请求与响应均引用 `components['schemas']` 或 `operations`；preview 类型在 root 真正生成后才接入 | 已有接口可先接；修改提交闭环依赖新的 preview 合同 |
| `src/api/goals.ts` | goals 列表、真实 accounts/summary 账户选择、零归属 create；按需读取已有目标/资产 allocation-preview | GoalList/GoalResponse/CreateGoalRequest/AccountSummary/GoalAllocationResponse/AssetAllocationResponse；dashboard 不再复制一份接口实现 | 无新接口依赖；创建 payload 不含金额/权限/用户时钟 |
| `src/features/policy-form.ts` | 五类配置的本地表单状态、精确金额输入、必填与范围交互校验、完整配置保存；编辑序号管理 | 本地输入模型不是服务端 DTO；规范化与 hash 全交服务端，不在前端实现资金边界 | 与类型表单同批；新增金额解析纯函数测试与结构完整性检查 |
| `src/components/PolicyConfigForm.tsx` | 共用公共有效窗与五类字段，完整只读复核/编辑态；未提供的字段空白待补齐 | 按 `policy_configuration.py` 真实字段构造；不漏 priority/recovery/scope/default flags | 后端配置 shape 保持当前时可实现；服务端拒绝为最终依据 |
| `src/pages/PolicyCenterPage.tsx` | 活动/未来/暂停/失效策略、候选、编译修订、结构化首次确认、版本详情、修改预览与确认、暂停/撤销 | 仅使用实际接口；review/preview 面板放在本文件先完成闭环，暂不再拆通用 modal/state 框架 | 当前列表/确认/生命周期可先做；无服务端 preview 时不能放行修改最终按钮 |
| `src/pages/GoalsPage.tsx` | 参数/月度 range/期限、真实 goal 建立、已核验 cash/principal/allocated、资产放置、当前关联策略 | `getDashboard` 查询 key 复用为归属来源；配置与金融查询各自保留时点，版本不符先刷新 | 现有接口可做；允许来源不足页，禁止 raw Goal.allocated 当现金 |
| `src/styles.css` | 延续401视觉、可键盘操作的导航、表单、复核/版本/预览块、小屏布局 | 复用原金额样式与 null/错误视觉，不引入 UI 包 | 相关页面验证；不为 CSS 单独新建镜像测试 |

关联新增测试紧邻上述文件：`PolicyCenterPage.test.tsx`、`GoalsPage.test.tsx`、`policy-form.test.ts`、`policies.test.ts`、`goals.test.ts`，以及原 `App.test.tsx` 中保留的首页断言。明确这些是 HTTP fixture 单元交互。真实资金页面的 Edge 验收由 root 运行真实服务，不使用 route.fulfill 代替银行/PG 证据。若 shell 抽取影响原 `health.spec.ts` 的实际选择器，只改这一相关工程检查，不重跑无关资金链。

顺序：shell+首页抽取 → 只读策略/版本与目标 → rules 编译/修订/首次复核确认 → 零目标建立 → 暂停/撤销 → 正式服务端 preview → 修改提交/409/replay → 相关类型检查和页面验收。各步可以在合同到位后连续实施，不能把末尾 preview 缺口包装成402已完成。

### 页面验收节点（均待正式实现与验证）

| 节点 | 用户真实可见行为 | 必须验证的边界 | 对应最小页面验证 |
| --- | --- | --- | --- |
| P1 导航与查看 | 总览/策略/目标可访问、返回/前进正确；当前版本/有效期可展开 | 首页保留目标现金保护“含待归属”与单 dashboard 响应；current_version=null 不造版本；version_authorized 不等于可执行资金 | 原 App 金融断言 + 导航 HTTP 单元；root 实际页面选择器验证 |
| P2 首次复核确认 | rules 编译显示原 reference_date/timezone/issues/assumptions；不完整候选可修订；查看全部字段后明确接受并确认 | accepted 默认 false；revise 后使用外层最新 configuration/hash，不覆盖原编译锚点；结构不完整禁止 confirm；已确认原编译不能重修订；刷新后的旧编译若无 reader 只能完整候选只读复核 | compile/revise/confirm 客户端与页面单元；root 真实 compile→revise→confirm |
| P3 修改前比较与提交 | 最新配置→编辑→服务端 before/after/null/时点→原因与接受→同键 PATCH→新版本 | 任意编辑立即清 preview/hash/accepted；不使用 GET boundary 冒充候选比较；网络重试保持被冻结 payload/key；409 保留草稿但废弃 preview，不自动套新版本；刷新真实列表，不把历史 ACTIVE 回执当现状 | policy-form + preview/PATCH/409/retry 页面单元；新服务端正式 DTO 到位后 root 真实比较→修改链 |
| P4 暂停/撤销与历史 | 弹层明确原版本；成功显示实际 invalidated/inflight，当前列表更新；历史配置与确认记录可查 | 不自动释放 UNKNOWN/已受理占用、不产生新银行操作；没有 resume；暂停后修改仍暂停；版本 immutable；哈希字段只说明追溯 | 相关生命周期页面单元；root 对有/无执行来源和 UNKNOWN 的定向 PG 集成 |
| P5 到期/未来有效窗 | 可信服务端时钟下 ACTIVE/CONFIRMED/EXPIRED 正确展示；刷新/进入页面后状态更新 | 不靠客户端 Date.now 授权；到期/撤销不能“修改并复活”；有效期上界沿真实服务端本地日排他口径；暂停不因有效窗变化自动恢复 | 状态/禁用交互单元；root 时钟注入的真实 API/Edge 节点 |
| P6 目标建立与归属 | 确认配置但无投影时明确待建立；选择真实本人 CASH/GOAL account 建立；已核验 cash/principal/进度和资产分开展示 | create 仅 policy/currentversion/account，不划款；账户不允许改绑；来源不足显示待核验；已归属和managed本金不重复加总；手工持仓不混入自主配置；asset_policy_id 空不自动绑定 | goal 创建/409/null/交叉归属页面单元；root 真实零目标建立→dashboard 复查 |
| P7 预览与错误恢复 | 当前目标收入分配、当前资产规划仅按需真实 GET 展示；错误显示服务端 message/request_id，可安全重读 | 当前 allocation-preview 不是策略修改影响；不提供执行按钮；不同HTTP时点不宣称单事务金融快照；恶意/不安全金额 JSON 必须入口拒绝 | goals/policies 客户端、相关页面错误/重试单元；真实 GET 结果抽查 |

前端每批保留命令、exit、raw log 与 source hash；独立 typecheck/lint/组件或纯函数检查可以并行。预览后端、生命周期与来源占用的定向金融集成按真实依赖运行；没有生产改动的本设计批次不执行任何测试。全量仍只在初版25项与完整版92项两个验收节点。

### 后端合同缺口与完成门槛（本次真实复核）

1. **确定缺失 / 402完整验收阻塞：** OpenAPI 当前没有 `POST /api/v1/policies/{policy_id}/change-preview` 或等价候选比较入口，也没有正式 before/after 比较 DTO。既有 `GET /boundary`、`GET /goals/{id}/allocation-preview`、`GET /asset-policies/{id}/allocation-preview` 都不能替代。root 实现第3节严格只读同金融基准合同并真正生成 OpenAPI/schema 后，前端才接入 P3。
2. **条件缺失 / 旧编译刷新恢复：** ProposalView 无 compilation_id，路由无 GET compilation。若要求刷新后继续原草稿编辑并取原 issues/assumptions，root 需补第5节 reader 与 nullable reference；否则明确仅支持当前会话修订，新编译 id 不跨刷新伪造恢复。已经完整的候选仍可按现有 confirmation 接口复核确认。
3. **合同精度限制 / 不是假类型可补齐：** 当前 PolicyChangeRequest、PolicyVersionView、ProposalView 的 configuration 仍是 `additionalProperties=true`；正式 OpenAPI 没有五类配置的 discriminated union。前端用生成的通用 JSON shape + 本地 UI 输入模型 + 运行时类型/金额检查，依赖真实服务端 validate_configuration；不能手写同名“合同 DTO”宣称已生成强类型。root 若将确定性五类模型正式公开，应由真实 API 导出后再消除该精度限制；不强制为了 UI 另做迁移。
4. **真实服务端语义已提供 / 可直接复用：** list/proposals/versions/compile/revise/confirm/PATCH/suspend/revoke/goal-create 真实存在；LifecycleResult 是可能历史命令结果而不是独立现状查询；错误为 ErrorEnvelope.error.{code,message,request_id}；正常列表 simulation=true。配置读者不提供可信 as_of 字段时，不自行生成“服务端查询时点”。
5. **实测未证实 / 非新合同绕过：** 第4节生命周期占用疑点仍待 root 定向真实集成，不在设计里断言已坏或已修。金融差值和权限预测不能由前端算出，不能用保留字段假值降低服务端检查。

本次读取绑定：schema.d.ts SHA256 `0d18fd09e21a6ca18e79e3ef89a972569e3760b006ae1b9bad4686a18b5fe928`，openapi.json `3fb958a7546982029b590479f47022dd829b415c22b038bdb1b526afca417c6d`，policies.py `6f7f09f85cdb6626c3c96bbd186a0048ef6987611f5aecbb6c94839b393f86f5`，goals.py `bf0c263b650d1204c5a810a9fc73ad680f5c432af2965a26fab8dafa47b734ca`，policy_configuration.py `e3645cd3faa23921b765bc7e952d4953489d508eb39e88065632e24d49c94657`。

真实后端测试目录为 `apps/api/app/tests/`；原计划在仓库根目录。复核中的一次 PowerShell foreach 管道语法错误、一次猜错 tests/原计划父级路径的只读 rg 错误均未改文件、未运行测试；已用实际路径重新读取成功，不能作为测试失败或实测通过记录。

状态仍是：402 **未开始生产实现**，等待 root 启动。
