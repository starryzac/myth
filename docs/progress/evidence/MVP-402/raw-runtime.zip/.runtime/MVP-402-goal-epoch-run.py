"""Record only the authorized targeted tests and their actual process result."""

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
label, *nodes = sys.argv[1:]
assert label.startswith("MVP-402-goal-epoch-") and nodes
argv = [
    str(repo / ".venv/Scripts/python.exe"),
    "-m",
    "pytest",
    *nodes,
    "--no-cov",
    "-vv",
    "-s",
    "-x",
    "--durations=10",
    "-p",
    "no:cacheprovider",
]
sources = [
    "apps/api/app/services/goals.py",
    "apps/api/app/tests/test_goal_creation_income_epoch.py",
]
sources.extend(
    path
    for path in dict.fromkeys(node.split("::", 1)[0] for node in nodes)
    if path not in sources
)
hashes = lambda: {
    p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in sources
}
metadata_file = repo / ".runtime" / f"{label}.json"
log_file = repo / ".runtime" / f"{label}.txt"
assert not metadata_file.exists() and not log_file.exists()
env = os.environ.copy()
env.update(
    PYTHONUTF8="1",
    UV_CACHE_DIR=str(repo / ".uv-cache"),
    PYTEST_ADDOPTS="",
    PYTHONPATH="apps/api",
)
metadata = {
    "command": argv,
    "nodes": nodes,
    "started_at": datetime.now(UTC).isoformat(),
    "source_before": hashes(),
    "pytest_addopts": "",
    "log_file": log_file.relative_to(repo).as_posix(),
    "scope": "Existing temporary_database bf_test fixture only; no formal DB actions.",
}
metadata_file.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
started = time.perf_counter()
print(f"STARTED {label}", flush=True)
with log_file.open("xb") as output:
    result = subprocess.run(argv, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
metadata.update(
    finished_at=datetime.now(UTC).isoformat(),
    elapsed_seconds=time.perf_counter() - started,
    exit_code=result.returncode,
    source_after=hashes(),
    log_sha256=hashlib.sha256(log_file.read_bytes()).hexdigest(),
)
metadata["changed_during_run"] = [
    p for p in sources if metadata["source_before"][p] != metadata["source_after"][p]
]
metadata_file.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
print(json.dumps({k: metadata[k] for k in ["exit_code", "elapsed_seconds", "changed_during_run"]}))
print(log_file.read_text(encoding="utf-8", errors="replace")[-5000:])
sys.exit(result.returncode)
