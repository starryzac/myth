"""Prepare real UI evidence on one disposable PG database; never automate acceptance.

Explicit future launch (PowerShell, repo cwd):
  $env:PYTHONUTF8='1'; $env:UV_CACHE_DIR="$PWD/.uv-cache"
  .venv/Scripts/python.exe .runtime/drive_mvp402_goal_epoch.py --run

ready.json publishes run_id, sequence, nonce, before-snapshot and URLs. Perform the real
Edge interaction after ready, then atomically rename a JSON file to
checkpoints/0001.command.json (next sequence uses 0002, etc.). Strict command shape:
  {"run_id": "<ready>", "sequence": 1, "nonce": "<ready>",
   "operation": "CHECKPOINT", "mode": "READ_ONLY", "label": "initial-view",
   "artifacts": [".runtime/<actual native capture file>"]}
mode POLICY_GOAL allows policy/lifecycle/zero Goal changes, never money operations.
operation FINISH checks the final checkpoint and shuts down; STOP aborts without PASS.
Wait for the next ready sequence before another UI interaction. The command is consumed
once and preserved verbatim. A failed oracle stops the run. All raw snapshots are retained.

Oracle distinctions: original database_snapshot is 23 mapped business tables; an independent
RR/READ ONLY capture includes all 24 physical tables, including alembic_version. POLICY_GOAL
keeps existing bank originals and financial rows exact, permitting only the two exact new
zero GOAL_CASH/GOAL_PRINCIPAL OPENING rows emitted by create_goal_projection. No generic
zero-bank-row exception. This post-fix fragment permits only a strict complete-income epoch carry,
with every economic field and original occurrence/observation time unchanged. No old income gains
eligibility for the newly confirmed Goal policy. The original12-step driver remains untouched.

NOT_EXECUTED_AT_PREPARATION. Actual driver status is DB_CHECKPOINTS_COMPLETE, not a UI
acceptance claim; root separately reviews real Edge requests and pixels. Timings are fixture
diagnostics, NOT_PRODUCT_SLA. No profiling or route patches. No formal seed or reset.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen
from uuid import UUID, uuid4, uuid5

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 10, 4, 1, tzinfo=UTC)
FINANCIAL_TABLES = (
    "users",
    "accounts",
    "transactions",
    "credit_card_bills",
    "asset_products",
    "asset_positions",
    "bank_operations",
    "simulated_bank_redemptions",
    "external_bank_facts",
    "action_plans",
    "action_receipts",
    "action_resource_reservations",
    "decision_runs",
    "decision_constraints",
    "alembic_version",
)
OWNERSHIP = "SIMULATED_GOAL_OWNERSHIP"
CONTRIBUTION = "SIMULATED_GOAL_MONTH_CONTRIBUTION"
EXPOSURE = "SIMULATED_ASSET_EXPOSURE"
INCOME = "SIMULATED_NEW_FUNDS_LEDGER"


def dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.now(UTC).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def source_hashes():
    paths = [p for p in (ROOT / "apps/api/app").rglob("*.py") if "tests" not in p.parts]
    paths += list((ROOT / "apps/api/alembic").rglob("*.py"))
    paths += [p for p in (ROOT / "apps/web/src").rglob("*") if p.suffix in {".ts", ".tsx", ".css"}]
    paths += [
        ROOT / name
        for name in (
            "packages/contracts/openapi.json",
            "packages/contracts/schema.d.ts",
            "apps/api/app/tests/test_demo_seed.py",
            "apps/api/app/tests/test_boundary_service.py",
            "apps/web/vite.config.ts",
        )
    ]
    return {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in sorted(paths)}


def by_id(rows):
    result = {row["id"]: row for row in rows}
    require(len(result) == len(rows), "Duplicate physical row identity")
    return result


def epoch_carry_oracle(
    old_evidence, evidence, added_evidence, new_goals, previous_goals, user_id, configuration_hash
):
    """Exact replace_proof carry, without treating a new epoch as new income eligibility."""
    if not new_goals:
        return {}
    require(len(new_goals) == 1, "This minimal fragment creates one zero Goal per checkpoint")
    new_goal_id = next(iter(new_goals))
    current_income = [
        row
        for row in old_evidence.values()
        if row["source_type"] == INCOME and row["status"] == "VALID" and row["user_id"] == user_id
    ]
    require(
        len(current_income) == 1, "Native before-state must have one complete actual income proof"
    )
    from app.domain.income_ledger import IncomeLedger

    ledger = IncomeLedger.model_validate_json(dump(current_income[0]["content"]))
    require(
        str(ledger.user_id) == user_id and ledger.as_of <= NOW,
        "Complete before ledger owner/known clock mismatch",
    )
    carries = {}
    for original in old_evidence.values():
        source = original["source_type"]
        if original["status"] != "VALID" or source not in {INCOME, OWNERSHIP, CONTRIBUTION}:
            continue
        if source != INCOME and original["content"].get("goal_id") not in previous_goals:
            continue
        expected_content = {**original["content"], "as_of": NOW.isoformat()}
        if (
            expected_content == original["content"]
            and datetime.fromisoformat(original["observed_at"]) == NOW
        ):
            continue
        digest = configuration_hash(expected_content)
        identity = str(uuid5(UUID(new_goal_id), f"evidence:{original['id']}:{digest}"))
        successor = added_evidence.get(identity)
        require(
            original["user_id"] == user_id
            and original["evidence_level"] == "BANK_CONFIRMED"
            and original["content_hash"] == configuration_hash(original["content"])
            and datetime.fromisoformat(original["observed_at"]) <= NOW
            and datetime.fromisoformat(original["content"]["as_of"]) <= NOW,
            "Carry must originate in an actual valid owned bank proof",
        )
        require(
            evidence.get(original["id"]) == {**original, "status": "SUPERSEDED"},
            "Carried original can change only VALID to SUPERSEDED",
        )
        expected = {
            **original,
            "id": identity,
            "content": expected_content,
            "content_hash": digest,
            "source_ref": f"bank-projection:{identity}",
            "status": "VALID",
            "supersedes_id": original["id"],
            "valid_to": None,
        }
        require(
            successor is not None and set(successor) == set(expected),
            "Carry successor schema/identity missing",
        )
        clocks = {"created_at", "valid_from", "observed_at"}
        require(
            all(successor[key] == value for key, value in expected.items() if key not in clocks)
            and all(datetime.fromisoformat(successor[key]) == NOW for key in clocks),
            "Carry successor must match exact replace_proof fields and fixed server clock",
        )
        if source == INCOME:
            updated = IncomeLedger.model_validate_json(dump(successor["content"]))
            require(
                updated.as_of == NOW
                and updated.origins == ledger.origins
                and updated.fragments == ledger.fragments
                and updated.reservations == ledger.reservations
                and updated.scope_account_ids == ledger.scope_account_ids,
                "Origins, known clocks, amounts, locations and claims cannot change",
            )
        carries[identity] = {
            "source_type": source,
            "previous_id": original["id"],
            "successor_id": identity,
            "goal_operation_id": new_goal_id,
            "source_ref": successor["source_ref"],
            "content_hash": digest,
            "economic_body_except_as_of_exact": True,
            "origin_clocks_preserved_not_new_policy_eligibility": True,
        }
    require(
        any(row["source_type"] == INCOME for row in carries.values()),
        "This post-fix native fragment must actually carry the earlier income epoch",
    )
    return carries


def policy_goal_oracle(before, after, user_id, configuration_hash):
    for table in FINANCIAL_TABLES:
        require(before[table] == after[table], f"Financial table changed: {table}")
    previous_goals, goals = by_id(before["goals"]), by_id(after["goals"])
    for identity, original in previous_goals.items():
        current = goals.get(identity)
        require(current is not None, f"Existing Goal disappeared: {identity}")
        for field in ("id", "user_id", "policy_id", "account_id", "allocated_cents", "created_at"):
            require(
                current[field] == original[field], f"Existing Goal funds/binding changed: {field}"
            )
    new_goals = {key: row for key, row in goals.items() if key not in previous_goals}
    accounts = by_id(after["accounts"])
    versions = by_id(after["policy_versions"])
    for identity, goal in new_goals.items():
        require(
            goal["user_id"] == user_id and goal["allocated_cents"] == 0, "New Goal must own zero"
        )
        require(
            identity == str(uuid5(UUID(goal["policy_id"]), "goal-projection-v1")), "Wrong Goal ID"
        )
        account = accounts.get(goal["account_id"])
        require(
            account is not None
            and account["user_id"] == user_id
            and account["account_type"] in {"CASH", "GOAL"},
            "Wrong Goal account",
        )
        version = versions.get(goal["policy_version_id"])
        require(
            version is not None
            and version["user_id"] == user_id
            and version["policy_id"] == goal["policy_id"]
            and version["configuration"]["type"] == "goal_saving"
            and configuration_hash(version["configuration"]) == version["content_hash"],
            "New Goal must bind actual goal policy version",
        )
        require(datetime.fromisoformat(goal["created_at"]) == NOW, "Wrong Goal creation clock")
    old_postings, postings = (
        by_id(before["simulated_bank_postings"]),
        by_id(after["simulated_bank_postings"]),
    )
    for identity, original in old_postings.items():
        require(postings.get(identity) == original, f"Existing bank original changed: {identity}")
    additions = {key: row for key, row in postings.items() if key not in old_postings}
    expected_ids = set()
    for identity, goal in new_goals.items():
        for label in ("GOAL_CASH", "GOAL_PRINCIPAL"):
            key = f"{label}:{identity}"
            posting_id = str(uuid5(UUID(user_id), "execution-opening:" + key))
            expected_ids.add(posting_id)
            row = additions.get(posting_id)
            require(row is not None, f"Missing exact zero Goal opening: {key}")
            expected = {
                "id": posting_id,
                "user_id": user_id,
                "ledger_key": key,
                "ledger_dimension": "GOAL_OWNERSHIP",
                "ledger_metadata": {"goal_id": identity, "account_id": goal["account_id"]},
                "account_id": goal["account_id"],
                "position_id": None,
                "redemption_id": None,
                "operation_id": None,
                "external_fact_id": None,
                "leg_ref": None,
                "previous_posting_id": None,
                "sequence_number": 1,
                "entry_kind": "OPENING",
                "balance_before_cents": 0,
                "delta_cents": 0,
                "balance_after_cents": 0,
            }
            require(
                set(row) == set(expected) | {"created_at", "occurred_at"}, "Opening schema changed"
            )
            require(
                all(row[field] == value for field, value in expected.items()),
                "Illegal Goal opening",
            )
            require(
                all(
                    datetime.fromisoformat(row[field]) == NOW
                    for field in ("created_at", "occurred_at")
                ),
                "Goal opening must use real fixed server time",
            )
    require(
        set(additions) == expected_ids, "Unexpected new bank row; only two per new Goal allowed"
    )

    old_evidence, evidence = by_id(before["evidence_items"]), by_id(after["evidence_items"])
    added_evidence = {key: row for key, row in evidence.items() if key not in old_evidence}
    carries = epoch_carry_oracle(
        old_evidence,
        evidence,
        added_evidence,
        new_goals,
        previous_goals,
        user_id,
        configuration_hash,
    )
    carried_originals = {row["previous_id"] for row in carries.values()}
    for identity, original in old_evidence.items():
        if (
            original["evidence_level"] != "BANK_CONFIRMED"
            and original["source_type"] != "SIMULATED_SEED_INCOME_IMPORT"
        ):
            continue
        current = evidence.get(identity)
        if current == original:
            continue
        if identity in carried_originals:
            continue  # Already compared every immutable column and complete economic body above.
        require(
            bool(new_goals)
            and original["source_type"] == EXPOSURE
            and current is not None
            and original["status"] == "VALID"
            and current == {**original, "status": "SUPERSEDED"},
            f"Existing financial proof changed: {identity}",
        )
    goal_proof_ids = set()
    for identity, goal in new_goals.items():
        common = {
            "simulation": True,
            "user_id": user_id,
            "goal_id": identity,
            "as_of": NOW.isoformat(),
        }
        bodies = {
            OWNERSHIP: {
                **common,
                "protocol": "goal-ownership-v1",
                "policy_id": goal["policy_id"],
                "account_id": goal["account_id"],
                "allocated_cents": 0,
                "cash_owned_cents": 0,
                "principal_owned_cents": 0,
                "position_ids": [],
            },
            CONTRIBUTION: {
                **common,
                "protocol": "goal-month-contribution-v1",
                "period": "2026-10",
                "contributed_cents": 0,
                "complete": True,
            },
        }
        for source, content in bodies.items():
            proof_id = str(uuid5(UUID(identity), source))
            goal_proof_ids.add(proof_id)
            row = added_evidence.get(proof_id)
            require(
                row is not None
                and row["user_id"] == user_id
                and row["content"] == content
                and row["evidence_level"] == "BANK_CONFIRMED"
                and row["source_type"] == source
                and row["source_ref"] == f"goal-initialization:{identity}"
                and row["content_hash"] == configuration_hash(content)
                and row["status"] == "VALID"
                and row["supersedes_id"] is None
                and row["valid_to"] is None,
                "Invalid new zero Goal bank proof",
            )
            require(
                all(
                    datetime.fromisoformat(row[field]) == NOW
                    for field in ("created_at", "observed_at", "valid_from")
                ),
                "Goal proof clock mismatch",
            )
    exposures = [row for row in added_evidence.values() if row["source_type"] == EXPOSURE]
    require(
        len(exposures) == len(new_goals),
        "Each new Goal must publish exactly one exposure successor",
    )
    for row in exposures:
        predecessor = evidence.get(row["supersedes_id"])
        require(
            predecessor is not None
            and predecessor["source_type"] == EXPOSURE
            and predecessor["status"] == "SUPERSEDED"
            and row["user_id"] == user_id
            and row["evidence_level"] == "BANK_CONFIRMED"
            and row["content_hash"] == configuration_hash(row["content"])
            and row["source_ref"] == f"bank-projection:{row['id']}"
            and row["status"] in {"VALID", "SUPERSEDED"},
            "Invalid exposure successor",
        )
        require(
            all(
                datetime.fromisoformat(row[field]) == NOW
                for field in ("created_at", "observed_at", "valid_from")
            ),
            "Exposure clock mismatch",
        )
    require(
        all(
            row["id"] in goal_proof_ids or row["source_type"] == EXPOSURE or row["id"] in carries
            for row in added_evidence.values()
            if row["evidence_level"] == "BANK_CONFIRMED"
        ),
        "Unexpected new bank-confirmed fact",
    )
    return {
        "financial_tables_exact": list(FINANCIAL_TABLES),
        "existing_bank_rows_exact": len(old_postings),
        "new_zero_goal_ids": sorted(new_goals),
        "exact_zero_goal_openings": sorted(additions),
        "exact_zero_goal_proofs": sorted(goal_proof_ids),
        "exposure_successors": [r["id"] for r in exposures],
        "income_epoch_carry": [row for row in carries.values() if row["source_type"] == INCOME],
        "old_goal_epoch_carry": [row for row in carries.values() if row["source_type"] != INCOME],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run", action="store_true", help="Explicitly create one disposable DB and servers"
    )
    parser.add_argument("--output", default=".runtime/MVP-402-browser-goal-epoch")
    parser.add_argument("--api-port", type=int, default=18042)
    parser.add_argument("--web-port", type=int, default=15174)
    parser.add_argument("--checkpoint-timeout", type=int, default=1800)
    parser.set_defaults(skip_expired_fixture=True)
    args = parser.parse_args()
    if not args.run:
        parser.error("Preparation only; explicit --run is required")
    require(
        1024 <= args.api_port <= 65535
        and 1024 <= args.web_port <= 65535
        and args.api_port != args.web_port
        and 1 <= args.checkpoint_timeout <= 7200,
        "Invalid ports or synchronization budget",
    )
    destination = (ROOT / args.output).resolve()
    require(
        destination.is_relative_to((ROOT / ".runtime").resolve())
        and destination != (ROOT / ".runtime").resolve()
        and not destination.exists(),
        "Output must be a fresh directory strictly inside this repo .runtime",
    )
    sys.path.insert(0, str(ROOT / "apps/api"))
    from alembic import command
    from alembic.config import Config
    from app.db.base import Base
    from app.db.session import create_database_engine
    from app.db.settings import DatabaseSettings
    from app.db.testing import require_test_database, temporary_database
    from app.domain.policy_configuration import configuration_hash
    from app.services.demo_seed import DEMO_USER_ID, seed_demo
    from app.tests.test_boundary_service import confirmed_policy
    from app.tests.test_demo_seed import database_snapshot
    from sqlalchemy import event, select, text
    from sqlalchemy.engine import make_url
    from sqlalchemy.orm import Session

    source = make_url(DatabaseSettings().database_url)
    require(
        source.drivername == "postgresql+psycopg"
        and source.host in {"127.0.0.1", "localhost", "::1"}
        and source.port == 54329,
        "Only local54329 disposable-test administration is allowed",
    )
    node = shutil.which("node")
    require(
        node is not None and (ROOT / "apps/web/node_modules/vite/bin/vite.js").is_file(),
        "Vite runtime missing",
    )
    destination.mkdir()
    checkpoints = destination / "checkpoints"
    checkpoints.mkdir()
    manifest = {
        "status": "STARTING",
        "classification": "REAL_TEST_FIXTURE_NOT_PRODUCT_SLA",
        "started_at": utc(),
        "trusted_now": NOW.isoformat(),
        "checkpoints": [],
        "phases": [],
        "code_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "source_before": source_hashes(),
        "processes": [],
        "temporary_database_exited": False,
        "ui_acceptance": "REQUIRES_ROOT_REVIEW_OF_ACTUAL_EDGE_EVIDENCE",
        "tool_hashes": {
            p.name: sha(p.read_bytes())
            for p in (Path(__file__), ROOT / ".runtime/mvp402_e2e_server.py")
        },
    }
    processes, logs = [], []

    def save():
        (destination / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def phase(label, function):
        started_at, start = utc(), time.monotonic()
        try:
            return function()
        finally:
            manifest["phases"].append(
                {
                    "phase": label,
                    "started_at": started_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - start,
                }
            )
            save()

    def cleanup():
        for process, item in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
            item.update(exit_code=process.returncode, closed_at=utc())
            save()
        for log in logs:
            log.close()

    def launch(argv, environment, name):
        log = (destination / f"{name}.log").open("x", encoding="utf-8")
        logs.append(log)
        process = subprocess.Popen(
            argv,
            cwd=ROOT,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        item = {"name": name, "argv": argv, "pid": process.pid, "started_at": utc()}
        processes.append((process, item))
        manifest["processes"].append(item)
        save()

    def wait_url(url):
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            require(
                all(process.poll() is None for process, _ in processes),
                "Owned server exited during startup",
            )
            try:
                with urlopen(url, timeout=2) as response:
                    if response.status == 200:
                        return
            except (URLError, TimeoutError, OSError):
                pass
            time.sleep(0.2)
        raise TimeoutError("Server startup synchronization budget elapsed: " + url)

    save()
    try:
        created_at, create_start = utc(), time.monotonic()
        with temporary_database() as url:
            manifest["phases"].append(
                {
                    "phase": "create_database",
                    "started_at": created_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - create_start,
                }
            )
            generated = require_test_database(make_url(url).database)
            manifest["database"] = generated
            manifest["database_url_redacted"] = make_url(url).render_as_string(hide_password=True)
            save()
            engine = create_database_engine(url)
            snapshot_engine = create_database_engine(url).execution_options(
                isolation_level="REPEATABLE READ"
            )

            @event.listens_for(snapshot_engine, "begin")
            def readonly_begin(connection):
                connection.exec_driver_sql("SET TRANSACTION READ ONLY")

            def capture(label):
                started_at, start = utc(), time.monotonic()
                mapped_raw = database_snapshot(snapshot_engine)
                with snapshot_engine.connect() as connection:
                    isolation = connection.exec_driver_sql(
                        "SHOW transaction_isolation"
                    ).scalar_one()
                    readonly = connection.exec_driver_sql("SHOW transaction_read_only").scalar_one()
                    require(
                        isolation == "repeatable read" and readonly == "on", "Snapshot is not RR/RO"
                    )
                    names = set(
                        connection.execute(
                            text(
                                "SELECT table_name FROM information_schema.tables "
                                "WHERE table_schema='public' AND table_type='BASE TABLE'"
                            )
                        ).scalars()
                    )
                    expected = set(Base.metadata.tables) | {"alembic_version"}
                    require(
                        names == expected and len(names) == 24,
                        "Physical table set differs from exact current24",
                    )
                    content = {
                        table.name: [
                            dict(row)
                            for row in connection.execute(
                                select(table).order_by(table.c.id)
                            ).mappings()
                        ]
                        for table in Base.metadata.sorted_tables
                    }
                    require(
                        mapped_raw == dump(content),
                        "Independent mapped23 snapshots differ; UI requests must be quiescent",
                    )
                    content["alembic_version"] = [
                        dict(row)
                        for row in connection.execute(
                            text("SELECT version_num FROM alembic_version ORDER BY version_num")
                        ).mappings()
                    ]
                physical_raw = dump(content)
                records = {}
                for suffix, raw in (("mapped23", mapped_raw), ("physical24", physical_raw)):
                    path = checkpoints / f"{label}.{suffix}.json"
                    path.write_text(raw, encoding="utf-8")
                    records[suffix] = {
                        "path": str(path.relative_to(ROOT)),
                        "sha256": sha(path.read_bytes()),
                        "bytes": path.stat().st_size,
                    }
                record = {
                    "started_at": started_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - start,
                    "isolation": isolation,
                    "read_only": readonly,
                    "physical_tables": sorted(names),
                    **records,
                }
                (checkpoints / f"{label}.snapshot-meta.json").write_text(
                    json.dumps(record, indent=2), encoding="utf-8"
                )
                return json.loads(physical_raw), record

            try:
                config = Config(str(ROOT / "alembic.ini"))
                config.set_main_option("sqlalchemy.url", url.replace("%", "%%"))
                phase("migration", lambda: command.upgrade(config, "head"))
                phase("seed", lambda: seed_demo(engine))
                if not args.skip_expired_fixture:
                    before_expired, _ = capture("fixture-before-expired")
                    with Session(engine) as session, session.begin():
                        policy_id, version_id = confirmed_policy(
                            session,
                            {
                                "type": "emergency_buffer",
                                "name": "已到期零应急（测试）",
                                "amount_cents": 0,
                                "valid_from": "2026-10-01",
                                "valid_until": "2026-10-03",
                            },
                            now=NOW,
                        )
                    after_expired, _ = capture("fixture-after-expired")
                    manifest["expired_fixture"] = {
                        "policy_id": str(policy_id),
                        "version_id": str(version_id),
                        "confirmed_at": NOW.isoformat(),
                        "oracle": policy_goal_oracle(
                            before_expired, after_expired, str(DEMO_USER_ID), configuration_hash
                        ),
                    }
                    require(
                        by_id(after_expired["policies"])[str(policy_id)]["status"] == "EXPIRED",
                        "Fixture is not actually expired",
                    )
                environment = dict(
                    os.environ,
                    PYTHONUTF8="1",
                    PYTHONPATH=str(ROOT / "apps/api"),
                    DATABASE_URL=url,
                    BF_POLICY_TEST_NOW=NOW.isoformat(),
                    API_PROXY_TARGET=f"http://127.0.0.1:{args.api_port}",
                )
                launch(
                    [
                        sys.executable,
                        "-m",
                        "uvicorn",
                        "--no-access-log",
                        "--app-dir",
                        ".runtime",
                        "mvp402_e2e_server:api",
                        "--host",
                        "127.0.0.1",
                        "--port",
                        str(args.api_port),
                    ],
                    environment,
                    "api",
                )
                launch(
                    [
                        node,
                        str(ROOT / "apps/web/node_modules/vite/bin/vite.js"),
                        str(ROOT / "apps/web"),
                        "--host",
                        "127.0.0.1",
                        "--port",
                        str(args.web_port),
                    ],
                    environment,
                    "web",
                )
                wait_url(f"http://127.0.0.1:{args.api_port}/api/v1/health")
                wait_url(f"http://127.0.0.1:{args.web_port}")
                for sequence in range(1, 6):
                    before, before_record = capture(f"{sequence:04d}-before")
                    nonce = uuid4().hex
                    ready = {
                        "run_id": destination.name,
                        "sequence": sequence,
                        "nonce": nonce,
                        "status": "WAITING_FOR_REAL_UI",
                        "trusted_now": NOW.isoformat(),
                        "browser_url": f"http://127.0.0.1:{args.web_port}",
                        "before": before_record,
                        "command_file": str(
                            (checkpoints / f"{sequence:04d}.command.json").relative_to(ROOT)
                        ),
                        "cash_accounts": [
                            r for r in before["accounts"] if r["account_type"] in {"CASH", "GOAL"}
                        ],
                        "expired_fixture": manifest.get("expired_fixture"),
                    }
                    ready_path = destination / "ready.json"
                    ready_tmp = destination / "ready.pending.json"
                    ready_tmp.write_text(
                        json.dumps(ready, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                    ready_tmp.replace(ready_path)
                    manifest["status"] = "WAITING_FOR_REAL_UI"
                    save()
                    print("READY " + str(ready_path), flush=True)
                    control = checkpoints / f"{sequence:04d}.command.json"
                    deadline = time.monotonic() + args.checkpoint_timeout
                    while not control.exists():
                        require(
                            all(process.poll() is None for process, _ in processes),
                            "Owned server exited",
                        )
                        if time.monotonic() >= deadline:
                            raise TimeoutError(
                                "UI control synchronization budget elapsed; this is not an SLA"
                            )
                        time.sleep(0.2)
                    raw = control.read_bytes()
                    require(len(raw) <= 65536, "Command exceeds 64KiB")
                    instruction = json.loads(raw)
                    require(
                        isinstance(instruction, dict)
                        and set(instruction)
                        == {
                            "run_id",
                            "sequence",
                            "nonce",
                            "operation",
                            "mode",
                            "label",
                            "artifacts",
                        },
                        "Invalid control fields",
                    )
                    require(
                        instruction["run_id"] == destination.name
                        and type(instruction["sequence"]) is int
                        and instruction["sequence"] == sequence
                        and instruction["nonce"] == nonce,
                        "Stale control identity",
                    )
                    require(
                        instruction["operation"] in {"CHECKPOINT", "FINISH", "STOP"}
                        and instruction["mode"] in {"READ_ONLY", "POLICY_GOAL"}
                        and isinstance(instruction["label"], str)
                        and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", instruction["label"]),
                        "Invalid control action",
                    )
                    require(
                        isinstance(instruction["artifacts"], list)
                        and len(instruction["artifacts"]) <= 50,
                        "Invalid evidence references",
                    )
                    artifacts = []
                    for value in instruction["artifacts"]:
                        require(isinstance(value, str), "Evidence reference must be a path")
                        path = (ROOT / value).resolve()
                        require(
                            path.is_relative_to((ROOT / ".runtime").resolve()) and path.is_file(),
                            "Evidence must exist inside repo .runtime",
                        )
                        artifacts.append(
                            {"path": str(path.relative_to(ROOT)), "sha256": sha(path.read_bytes())}
                        )
                    item = {
                        "sequence": sequence,
                        "instruction": instruction,
                        "command_sha256": sha(raw),
                        "command_read_at": utc(),
                        "before": before_record,
                        "artifacts": artifacts,
                    }
                    manifest["checkpoints"].append(item)
                    save()
                    if instruction["operation"] == "STOP":
                        raise RuntimeError("Explicit root stop: run ABORTED, no acceptance claim")
                    after, after_record = capture(f"{sequence:04d}-after")
                    item["after"] = after_record
                    save()
                    if instruction["mode"] == "READ_ONLY":
                        require(
                            before == after,
                            "READ_ONLY checkpoint wrote one or more of the physical24 tables",
                        )
                        item["oracle"] = {"physical24_exact": True, "mapped23_exact": True}
                    else:
                        item["oracle"] = policy_goal_oracle(
                            before, after, str(DEMO_USER_ID), configuration_hash
                        )
                    item["status"] = "PASSED"
                    item["finished_at"] = utc()
                    save()
                    if instruction["operation"] == "FINISH":
                        manifest["status"] = "DB_CHECKPOINTS_COMPLETE"
                        break
                else:
                    raise RuntimeError("Checkpoint count synchronization bound reached")
            finally:
                cleanup()
                snapshot_engine.dispose()
                engine.dispose()
        manifest["temporary_database_exited"] = True
        # Independently prove generated database absence after the context's guarded DROP.
        administration = create_database_engine(
            source.set(database="postgres").render_as_string(False)
        )
        try:
            with administration.connect().execution_options(
                isolation_level="REPEATABLE READ"
            ) as connection:
                connection.exec_driver_sql("SET TRANSACTION READ ONLY")
                manifest["generated_database_absent"] = not connection.execute(
                    text("SELECT EXISTS (SELECT 1 FROM pg_database WHERE datname=:name)"),
                    {"name": generated},
                ).scalar_one()
                require(
                    manifest["generated_database_absent"],
                    "Generated database remains after context exit",
                )
        finally:
            administration.dispose()
    except BaseException as error:
        manifest["status"] = "ABORTED" if str(error).startswith("Explicit root stop") else "FAILED"
        manifest["error"] = repr(error)
        save()
        raise
    finally:
        cleanup()
        manifest["source_after"] = source_hashes()
        manifest["changed_during_run"] = sorted(
            key
            for key in set(manifest["source_before"]) | set(manifest["source_after"])
            if manifest["source_before"].get(key) != manifest["source_after"].get(key)
        )
        manifest["finished_at"] = utc()
        if manifest["changed_during_run"]:
            manifest["status"] = "FAILED_SOURCE_CHANGED"
        save()
    return 0 if manifest["status"] == "DB_CHECKPOINTS_COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
