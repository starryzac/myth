# 新零 Goal 与完整收入证明时点：只读结论

未改 production/tests，未执行 DB/pytest/browser。实际现象引用 root 的 402 Edge 12 checkpoint 结果：native seed ledger 2026-10-03T16Z，正常新 Goal 的零归属/月贡献证明 2026-10-04T01Z，GET allocation-preview 返回200但唯一 issue 为 `INVALID_NEW_FUNDS_LEDGER / Ledger and goal ownership/contribution must have one epoch`，页面如实 null/待核验、没有执行。

结论：拒绝不同 epoch 的校验正确，安全未失守；但正常零 Goal 创建没有合法继承已完整验证的收入证明，是应在 402 关闭前补齐的小功能缺口，不应仅按预期缺源关闭。已完成的确认/修改/生命周期/版本及12浏览器 checkpoint证据仍有效，不需重跑黄金慢链。

源码链：

- `services/goals.py:106–188` 先验证真实 bank projection/exposure；创建 allocated/cash/principal均0的 Goal，两个证明 as_of=now，开本 Goal 独立0 anchors，刷新完整 exposure并审计。没有收入证明继承。
- `services/goal_allocation.py:94–104` native v2先完整 `read_income_state`，再检查所选 Goal OWNERSHIP/MONTH 与 ledger.as_of完全相等。实际唯一该问题符合“源本身已验证但聚合时点不同”，不是坏income/假银行余额。
- `services/income_ledger.py:86–276` 强验完整 CASH scope、所有已知 CASH 交易均被 epoch覆盖、原交易/证据/经济时钟、可用+reserved不超未归属cash、真实LOT余额。不能绕过这组检查来更新时点。
- `_prepared_income_matches:396` 已接受内容除 as_of外完全相同、有完整原hash/supersedes/status/tenant链的纯时点继承。`test_income_ledger_service::test_pure_epoch_successor_keeps_prepared_income_identity` 明确验证合法继承不改准备command；改变一分 spent/available则拒绝。
- `recovery_projection._epochs:125` 已有继承机制，但不能未经金融源验证在Goal create直接盲调：它会根据模型重算旧目标owned金额，而非仅拷原已验证值。最小修应仅carry真实验证过的不可变经济内容，不修复已有坏源。

既有验收为何未发现：203 legacy 无income节点本来就预期INSUFFICIENT；正例在创建后显式导入同epoch来源。301 `test_execution_goal_creation.public_zero_goal` 在 SEED_AS_OF创建，income与新Goal本来相同epoch。401 golden `dashboard_scenario` 在later NOW创建后再真实工资；external投影 `_epochs:767` 已同步ledger，之后才allocate。它们覆盖各自来源语义，没有覆盖native既有完整ledger→later正常Goal创建→立即读preview。

安全最小方案：在现user锁/创建事务内先验证原完整bank/income/归属来源，保留所有origins/fragments/reservations、原资格发生时点、spent/assigned/reserved/available及tenant/scope。对已完整来源创建as_of=now的真实继承proof，原content/hash保留并SUPERSEDED，现有相关归属/月证明纯carry同epoch（period和贡献不改，不生成跨月零贡献），最后完整 exposure与审计。不存在/冲突/坏income不能创建空ledger、伪造零收入或通过刷新修复；原缺源行为保持。重复创建原Goal早返回，不能再次carry/写proof。没有金额移动、新工资、claim释放或银行经济腿。

修后仍不可把旧seed收入授权给新Goal：`domain/goal_allocation.py:169` 只选 `occurred_at >= max(policy.confirmed_at,policy.valid_from)`。正常新确认Goal的旧收入不合格，完整preview应明确 eligible=0、suggested=0；min>0时MINIMUM_SHORTFALL，min=0时可READY0。现在的null来源失败与合法0/shortfall不同，测试不得期待凭此修复正金额自动分配。

最小新真实RED建议：native fresh seed、不发工资、不手改证明；NOW>SEED，实际确认min0/target10000/max10000的Goal策略→公开创建0Goal→原只读preview。断言来源无epoch issue/eligible0/suggestion0（仍按原资格规则）；原ledger经济字段、原proof正文/hash、所有旧cash/position/transaction/原bank经济行/外部fact/claims保持，只有原协议允许的0Goal anchors和真实继承证据。重复创建和重复GET全表零变；默认bank/exposure/audit验证仍真实通过。沿旧missing-income负例确认不会把缺源当0。不改epoch约束，不额外执行资金动作，不重跑整黄金链。
