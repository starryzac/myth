async (page) => {
  const text = '买车目标三万元，截止2027年10月1日，每月至少一千八百、建议两千、最多两千五百元。';
  await page.getByRole('textbox', { name: '策略描述', exact: true }).fill(text);
  const compiledResponse = page.waitForResponse(r => r.request().method() === 'POST' && r.url().endsWith('/api/v1/policies/compile'));
  await page.getByRole('button', { name: '编译候选', exact: true }).click();
  const compiled = await compiledResponse;
  const candidate = await compiled.json();
  if (compiled.status() !== 200 || candidate.configuration?.type !== 'goal_saving' || candidate.configuration.target_cents !== 3000000 || candidate.configuration.monthly_contribution.min_cents !== 180000 || candidate.configuration.monthly_contribution.target_cents !== 200000 || candidate.configuration.monthly_contribution.max_cents !== 250000) throw new Error('Unexpected actual complete Goal candidate');
  const submit = page.getByRole('button', { name: '确认编译策略', exact: true });
  if (!(await submit.isDisabled())) throw new Error('Explicit Goal confirmation was skipped');
  await page.getByRole('checkbox', { name: '我已逐项复核完整配置与原编译说明，明确接受此策略', exact: true }).check();
  const confirmationResponse = page.waitForResponse(r => r.request().method() === 'POST' && r.url().endsWith('/api/v1/policy-proposals/' + candidate.proposal_id + '/confirm'));
  await submit.click();
  const response = await confirmationResponse;
  const result = await response.json();
  const command = response.request().postDataJSON();
  if (response.status() !== 200 || result.effective_status !== 'ACTIVE' || command.accepted !== true || command.reviewed_hash !== candidate.configuration_hash) throw new Error('Wrong original explicit confirmation');
  await page.getByRole('link', { name: '目标储备', exact: true }).click();
  await page.getByRole('article', { name: '待建立目标 买车', exact: true }).waitFor();
  await page.waitForLoadState('networkidle');
  return { compiled: { status: compiled.status(), request: compiled.request().postDataJSON(), body: candidate }, confirmed: { status: response.status(), request: command, body: result }, pending_goal: await page.getByRole('article', { name: '待建立目标 买车', exact: true }).innerText() };
}
