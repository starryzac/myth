# MVP-402 pure hypothetical boundary handoff

READY / FROZEN. Scope is the pure domain seam, not completion of 402 or a full-version check. No PG, CLI, browser, bank action or service/contract changes were performed by this owner.

- Owner files: `apps/api/app/domain/boundary.py`, new `apps/api/app/domain/policy_change_types.py`, new `apps/api/app/tests/test_policy_change_boundary.py`.
- `compute_policy_change_boundary(..., *, source_version, assumption, living_estimate=None)` returns `PolicyChangeBoundaryComputation` with preview/simulation/financial markers, after boundary/details and assumption digest. `calculate_assumption_digest` is exported from the types module and imported by boundary.
- Source version is separately actual and strictly revalidated. Actual inputs pass the original financial validation including old settlement amount rules before the hypothesis; the internal policy parameter table alone receives canonical candidate configuration/known-from/window. No fake version, confirmation, evidence, `model_construct`, authority flag or mutated original DTO is used.
- Actual-only public entry points keep their signatures and none-hypothesis behavior. The 30 pre-existing complete financial-v1 frozen JSON cases passed through both entry points; directly related boundary examples, capacity/validation and properties also passed.
- Five kinds covered: emergency amount and future gap; living separate estimate bound to new configuration/clock; goal cash/principal/current contributions and minimum cap; recurring future assumptions versus generated history, without old confirmation IDs in hypothetical items; asset authorization changes leave existing principal/contract cash ordering intact and grant no authority. Bills and bank/position/source errors remain real.
- A generated old ordinary cycle or an existing target recurring settlement is conservatively `HISTORICAL_OBLIGATION_RECONCILIATION_REQUIRED`, even for rename/fully-paid statements. No old payment is reinterpreted under a new payee/rule. Living parameter-specific source-issue replacement and reading actual monthly proof are the service owner's responsibilities; the domain never clears actual snapshot issues.
- Candidate `effective_status` checks expiration before suspension, matching actual lifecycle effective-status order; `source_status` remains the separately supplied actual column. New expired/suspended parameters do not release owned goal cash.

Actual evidence, all `.runtime/MVP-402-policy-boundary-*`:

1. `red.{txt,json}`: initial missing public seam, one actual failure (ImportError); cache-access warnings retained and not treated as the cause.
2. `first.{txt,json}`: first implementation 149 passed, source unchanged.
3. `expired-red.{txt,json}`: genuine candidate bug, SUSPENDED reported instead of EXPIRED for an already ended hypothetical window; one actual assertion failure, then narrowly fixed.
4. `final-green.{txt,json}`: final 157 passed in 10.89 seconds, exit 0, 35 new + 122 directly related old pure checks, no coverage and no PG. The old invalid-float-input test emits its existing Pydantic serializer warning; the original rejection assertions pass.
5. `ruff-final`, `format-final`, `mypy-final` each actual exit 0; exact command/start/end/log/hash recorded. No pending exec handle remains (19760 closed with exit 0).

Final before/after hashes match in the final metadata:

| File | SHA256 |
| --- | --- |
| domain/boundary.py | a607e220ed637a22c3dd7ec3efcae57a88d698d94104a36e00aad420143706cb |
| domain/policy_change_types.py | 627ca5546b3cb8e7033f2273e19dbafbb0cc1b206bbe77d825a63dc1f2d29500 |
| tests/test_policy_change_boundary.py | 05b67f56a56d0d0499c0dd648eae5693e6b7ce2990df3948309e1dd034207e78 |

Parent is now responsible for the real RR/READ ONLY API/service basis and controlled PATCH equivalence, lifecycle, dashboard and monthly-parser PG regressions. Production files remain frozen while that runner is active. The ignored verifier performance candidate is separately frozen in `.runtime/MVP-401-verify-reuse-candidate/`; it has not been deployed into 401 or 402.
