"""Prepare-only helper; root runs with --archive after final closure documents are saved.

Future repo command: .venv/Scripts/python.exe .runtime/archive_mvp403_closure.py --archive
No tests, database, browser, formal migration, source changes, or deletion. Preserves historical
RED and intermediate artifacts as raw evidence; archive success does not turn them into GREEN.
Fresh output only: docs/progress/evidence/MVP-403. ZIP members use exact repo-relative paths.
"""

import argparse
import difflib
import hashlib
import json
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".runtime"
OUTPUT = ROOT / "docs/progress/evidence/MVP-403"
BROWSER = RUNTIME / "MVP-403-browser-cli"
HELPERS = (
    "drive_mvp403_browser.py",
    "mvp403_e2e_server.py",
    "mvp403_fixture.py",
    "drive_mvp403_policy_browser.py",
    "mvp403_policy_fixture.py",
    "drive_mvp402_goal_epoch.py",
    "browser_cli_mvp403.py",
    "capture_mvp403.py",
    "checkpoint_mvp402_folder.py",
    "archive_mvp403_closure.py",
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked_paths(paths):
    result = []
    for path in sorted(set(paths)):
        require(path.resolve().is_relative_to(ROOT.resolve()), "Archive member escapes repository")
        if any("MVP-404" in part.upper() for part in path.relative_to(ROOT).parts):
            continue
        if any(
            part in {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules"}
            for part in path.relative_to(ROOT).parts
        ):
            continue
        require(
            not any(
                suffix.lower() in {".part", ".pending", ".tmp", ".partial", ".lock"}
                for suffix in path.suffixes
            ),
            "Active/partial artifact must reach a terminal state before archive: " + str(path),
        )
        require(path.is_file(), "Missing exact archive member: " + str(path))
        result.append(path)
    return result


def runtime_paths():
    paths = []
    for path in RUNTIME.glob("MVP-403-*"):
        # capture_mvp403 owns these while this helper runs. Root copies their actual
        # terminal bytes separately and adds archive_execution to index after exit.
        if path.name in {"MVP-403-archive-launch.txt", "MVP-403-archive-launch.json"}:
            continue
        if path.is_file():
            paths.append(path)
        elif path.is_dir() and path != BROWSER:
            paths.extend(member for member in path.rglob("*") if member.is_file())
    paths.extend(RUNTIME / name for name in HELPERS)
    return checked_paths(paths)


def native_paths():
    require(BROWSER.is_dir(), "Exact native Edge evidence folder is missing")
    # Includes the actual screenshots with names such as change-preview.png, not only prefix files.
    paths = [path for path in BROWSER.rglob("*") if path.is_file()]
    paths += [path for path in (ROOT / "output/playwright").glob("MVP-403-*.png") if path.is_file()]
    require(
        any(path.suffix.lower() == ".png" for path in paths), "Native screenshot originals missing"
    )
    return checked_paths(paths)


def source_paths():
    paths = list((ROOT / "apps/api/app").rglob("*.py"))
    paths += list((ROOT / "apps/api/alembic").rglob("*.py"))
    paths += [path for path in (ROOT / "apps/web/src").rglob("*") if path.is_file()]
    paths += list((ROOT / "apps/api/app/tests/fixtures").glob("*.json"))
    paths += [
        ROOT / name
        for name in (
            "packages/contracts/openapi.json",
            "packages/contracts/schema.d.ts",
            "apps/web/vite.config.ts",
        )
    ]
    return checked_paths(paths)


def fingerprint(paths):
    return {path.relative_to(ROOT).as_posix(): sha(path.read_bytes()) for path in paths}


def _terminal_driver_gate(folder, launch_name, helper_name):
    manifest_path = RUNTIME / folder / "manifest.json"
    driver = json.loads(manifest_path.read_text(encoding="utf-8"))
    launch_path = RUNTIME / (launch_name + ".json")
    launch = json.loads(launch_path.read_text(encoding="utf-8"))
    require(
        launch["exit_code"] == 0 and launch.get("finished_at"), "403 runner is not terminal exit0"
    )
    require(
        launch["log_sha256"] == sha(launch_path.with_suffix(".txt").read_bytes()),
        "Launch log hash mismatch",
    )
    require(
        driver["status"] == "DB_CHECKPOINTS_COMPLETE" and driver.get("finished_at"),
        "403 driver not complete",
    )
    require(
        driver["temporary_database_exited"] is True and driver["generated_database_absent"] is True,
        "Generated DB cleanup lacks actual terminal proof",
    )
    require(
        driver["changed_during_run"] == [] and launch["changed_during_run"] == [],
        "403 source changed during run",
    )
    require(driver["source_before"] == driver["source_after"], "Actual source sets/bytes differ")
    require(
        any(
            isinstance(arg, str) and arg.replace("\\", "/").endswith(".runtime/" + helper_name)
            for arg in launch["command"]
        )
        and "--run" in launch["command"],
        "Launch does not bind the explicit expected driver",
    )
    for name, digest in driver["tool_hashes"].items():
        require(
            name == Path(name).name and sha((RUNTIME / name).read_bytes()) == digest,
            "Actual fixture tool bytes changed: " + name,
        )
    require(
        len(driver["processes"]) == 2
        and all(
            row.get("exit_code") is not None and row.get("closed_at") for row in driver["processes"]
        ),
        "403 owned servers are not both closed",
    )
    checkpoints = driver["checkpoints"]
    require(
        checkpoints
        and [row["sequence"] for row in checkpoints] == list(range(1, len(checkpoints) + 1))
        and checkpoints[-1]["instruction"]["operation"] == "FINISH",
        "403 sequential checkpoints not terminal",
    )
    for checkpoint in checkpoints:
        require(
            checkpoint["status"] == "PASSED"
            and checkpoint["instruction"]["mode"] == "READ_ONLY"
            and checkpoint["oracle"]
            == {"physical24_exact": True, "mapped23_exact": True, "browser_get_only": True},
            "403 checkpoint is not a full24 GET/readonly PASS",
        )
        for side in ("before", "after"):
            snap = checkpoint[side]
            require(
                snap["isolation"] == "repeatable read"
                and snap["read_only"] == "on"
                and len(snap["physical_tables"]) == 24,
                "Snapshot was not physical24 RR/RO",
            )
            for kind in ("mapped23", "physical24"):
                source = ROOT / snap[kind]["path"].replace("\\", "/")
                require(
                    source.resolve().is_relative_to(ROOT.resolve())
                    and source.is_file()
                    and sha(source.read_bytes()) == snap[kind]["sha256"],
                    "Snapshot original hash mismatch",
                )
            physical = json.loads((ROOT / snap["physical24"]["path"]).read_text(encoding="utf-8"))
            mapped = json.loads((ROOT / snap["mapped23"]["path"]).read_text(encoding="utf-8"))
            require(
                set(physical) == set(snap["physical_tables"])
                and len(physical) == 24
                and mapped
                == {key: value for key, value in physical.items() if key != "alembic_version"}
                and len(mapped) == 23,
                "Original raw snapshot is not exact physical24/mapped23",
            )
        for artifact in checkpoint["artifacts"]:
            path = ROOT / artifact["path"].replace("\\", "/")
            require(
                path.resolve().is_relative_to(RUNTIME.resolve())
                and path.is_file()
                and sha(path.read_bytes()) == artifact["sha256"],
                "Actual checkpoint evidence bytes changed",
            )
        require(
            all(
                checkpoint["before"][kind]["sha256"] == checkpoint["after"][kind]["sha256"]
                for kind in ("mapped23", "physical24")
            ),
            "Original full snapshot bytes differ",
        )
        require(
            checkpoint["actual_api_http_requests"]
            and all(row["method"] == "GET" for row in checkpoint["actual_api_http_requests"]),
            "HTTP was not all GET",
        )
    actual_requests = []
    for line in (manifest_path.parent / "api.log").read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("event") == "http_request":
            actual_requests.append(row)
    require(
        actual_requests and all(row["method"] == "GET" for row in actual_requests),
        "Raw final API log includes a command",
    )
    images, screenshot_commands = [], []
    for checkpoint in checkpoints:
        for artifact in checkpoint["artifacts"]:
            path = ROOT / artifact["path"].replace("\\", "/")
            if path.suffix.lower() == ".png":
                require(path.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"), "Invalid actual PNG")
                images.append(path.relative_to(ROOT).as_posix())
            elif path.suffix.lower() == ".txt" and path.parent == BROWSER:
                metadata = path.with_suffix(".json")
                if not metadata.is_file():
                    continue
                record = json.loads(metadata.read_text(encoding="utf-8"))
                command = record.get("command", [])
                if isinstance(command, list) and any(
                    isinstance(arg, str) and (arg == "screenshot" or ".screenshot(" in arg)
                    for arg in command
                ):
                    require(
                        record.get("exit_code") == 0
                        and record.get("finished_at")
                        and not record.get("reported_error")
                        and record.get("log_sha256") == sha(path.read_bytes()),
                        "Fragment screenshot command has no successful terminal original",
                    )
                    screenshot_commands.append(metadata.relative_to(ROOT).as_posix())
    require(images and screenshot_commands, "Fragment has no actual checkpoint screenshot proof")
    return driver, {
        "driver_status": driver["status"],
        "runner_exit_code": launch["exit_code"],
        "checkpoint_count": len(checkpoints),
        "physical24_all_readonly_get": True,
        "generated_database_absent": True,
        "owned_servers_closed": True,
        "fixture_tool_bytes_match": True,
        "native_checkpoint_screenshots": images,
        "native_checkpoint_screenshot_commands": screenshot_commands,
    }


def _historical_first_source_binding(driver):
    original_path = RUNTIME / "MVP-403-first-source-snapshot.json"
    original = json.loads(original_path.read_text(encoding="utf-8"))
    zip_path = RUNTIME / "MVP-403-first-web-source-snapshot.zip"
    require(sha(zip_path.read_bytes()) == original["zip_sha256"], "First source ZIP hash mismatch")
    tested = {name.replace("\\", "/"): digest for name, digest in driver["source_after"].items()}
    allowed = {
        "apps/web/src/pages/DecisionTracePage.tsx",
        "apps/web/src/pages/DecisionTracePage.test.tsx",
    }
    changes = {}
    with zipfile.ZipFile(zip_path) as archive:
        members = archive.namelist()
        require(
            len(members) == len(set(members))
            and set(members) == set(original["source_paths"])
            and len(members) == 31,
            "First original source member set differs from exact31",
        )
        for name in members:
            data = archive.read(name)
            require(
                sha(data) == original["source_paths"][name] == tested.get(name),
                "First original source bytes not bound to the real first run: " + name,
            )
        for name, digest in tested.items():
            path = ROOT / name
            require(
                path.resolve().is_relative_to(ROOT.resolve()) and path.is_file(), "Source missing"
            )
            current = sha(path.read_bytes())
            if current == digest:
                continue
            require(
                name in allowed and name in members, "Change exceeds reviewed label files: " + name
            )
            old_text = archive.read(name).decode("utf-8").splitlines(keepends=True)
            new_text = path.read_bytes().decode("utf-8").splitlines(keepends=True)
            changes[name] = {
                "first_sha256": digest,
                "closure_sha256": current,
                "actual_diff_requires_root_review": "".join(
                    difflib.unified_diff(
                        old_text, new_text, fromfile="first/" + name, tofile="final/" + name
                    )
                ),
            }
    return {
        "classification": "HISTORICAL_FIRST_RESULT_BOUND_TO_ORIGINAL_BYTES",
        "snapshot": original_path.relative_to(ROOT).as_posix(),
        "snapshot_sha256": sha(original_path.read_bytes()),
        "source_zip": zip_path.relative_to(ROOT).as_posix(),
        "source_zip_sha256": original["zip_sha256"],
        "exact_original_members": 31,
        "allowed_label_delta_files": sorted(allowed),
        "actual_label_delta": changes,
        "other_first_tested_source_matches_current": True,
        "boundary": (
            "Historical first screenshots retain first UI bytes; "
            "final policy fragment binds final UI"
        ),
    }


def terminal_browser_gate():
    first, first_gate = _terminal_driver_gate(
        "MVP-403-browser-first", "MVP-403-browser-first-launch", "drive_mvp403_browser.py"
    )
    policy, policy_gate = _terminal_driver_gate(
        "MVP-403-browser-policy", "MVP-403-browser-policy-launch", "drive_mvp403_policy_browser.py"
    )
    first_gate["source_binding"] = _historical_first_source_binding(first)
    for name, digest in policy["source_after"].items():
        path = ROOT / name.replace("\\", "/")
        require(
            path.resolve().is_relative_to(ROOT.resolve())
            and path.is_file()
            and sha(path.read_bytes()) == digest,
            "Final policy-fragment tested source changed at closure: " + name,
        )
    policy_gate["source_subset_matches_at_closure"] = True
    fixture = policy["fixture"]
    require(
        fixture["trace_policy_count"] >= 1
        and fixture["authority"]["status"] == "AUTHORIZED"
        and fixture["policy_version_id"] in fixture["authority"]["policy_version_ids"]
        and fixture["policy_confirmation_evidence_ids"]
        and fixture["goal_allocated_cents"] == 0
        and fixture["new_income_after_confirmation"] is False
        and fixture["action_id"] is None
        and fixture["receipt_id"] is None
        and fixture["bank_operation_id"] is None
        and fixture["top_audit_chain_status"] == "VALID",
        "Final actual policy fragment lacks policy permission/provenance and no-money boundaries",
    )
    policy_gate["actual_policy_fixture"] = {
        key: fixture[key]
        for key in (
            "saved_assessment_run_id",
            "policy_id",
            "policy_version_id",
            "goal_id",
            "policy_confirmation_evidence_ids",
            "trace_policy_count",
            "top_audit_chain_status",
        )
    }
    images = [path for path in native_paths() if path.suffix.lower() == ".png"]
    require(
        images and all(path.read_bytes().startswith(b"\x89PNG\r\n\x1a\n") for path in images),
        "Original PNG screenshot bytes missing",
    )
    screenshot_commands, historical_screenshot_failures = [], []
    for path in BROWSER.rglob("*.json"):
        record = json.loads(path.read_text(encoding="utf-8"))
        command = record.get("command", []) if isinstance(record, dict) else []
        if isinstance(command, list) and any(
            isinstance(arg, str) and (arg == "screenshot" or ".screenshot(" in arg)
            for arg in command
        ):
            require(
                record.get("exit_code") is not None and record.get("finished_at"),
                "Native screenshot command is still active",
            )
            if record["exit_code"] == 0 and not record.get("reported_error"):
                screenshot_commands.append(path.relative_to(ROOT).as_posix())
            else:
                historical_screenshot_failures.append(path.relative_to(ROOT).as_posix())
    require(screenshot_commands, "No actual terminal native screenshot command record")
    return {
        "first_historical_fragment": first_gate,
        "final_policy_fragment": policy_gate,
        "native_screenshot_records": screenshot_commands,
        "historical_screenshot_failures_retained": historical_screenshot_failures,
        "boundary": "Archive preserves evidence; root separately reviews actual403 UI acceptance",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    if not args.archive:
        parser.error("Prepared helper only; explicit root --archive is required")
    require(not OUTPUT.exists(), "Never replace evidence from a prior closure")
    gate = terminal_browser_gate()
    groups = {
        "raw-runtime.zip": runtime_paths(),
        "native-edge-command-logs.zip": native_paths(),
        "source-at-closure-snapshot.zip": source_paths(),
    }
    before = {name: fingerprint(paths) for name, paths in groups.items()}
    require(
        not (set(before["raw-runtime.zip"]) & set(before["native-edge-command-logs.zip"])),
        "Raw/native member groups overlap",
    )
    OUTPUT.mkdir()
    records, bundles = [], []
    for name, paths in groups.items():
        target = OUTPUT / name
        with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for source in paths:
                member = source.relative_to(ROOT).as_posix()
                data = source.read_bytes()
                require(
                    sha(data) == before[name][member], "Input changed before ZIP write: " + member
                )
                archive.writestr(member, data)
                records.append(
                    {
                        "original": member,
                        "zip": target.relative_to(ROOT).as_posix(),
                        "member": member,
                        "sha256": sha(data),
                        "bytes": len(data),
                    }
                )
        with zipfile.ZipFile(target) as archive:
            require(set(archive.namelist()) == set(before[name]), "ZIP member set mismatch")
            for source in paths:
                member = source.relative_to(ROOT).as_posix()
                require(
                    archive.read(member) == source.read_bytes(),
                    "Raw byte comparison failed: " + member,
                )
        bundles.append(
            {
                "path": target.relative_to(ROOT).as_posix(),
                "sha256": sha(target.read_bytes()),
                "bytes": target.stat().st_size,
                "members": len(paths),
            }
        )
    after = {
        "raw-runtime.zip": fingerprint(runtime_paths()),
        "native-edge-command-logs.zip": fingerprint(native_paths()),
        "source-at-closure-snapshot.zip": fingerprint(source_paths()),
    }
    require(before == after, "Input membership or bytes changed during closure archive")
    index = {
        "archived_at": datetime.now(UTC).isoformat(),
        "classification": "RAW_CLOSURE_ARCHIVE_INCLUDES_RED_AND_DESIGN_NOT_AGGREGATE_TEST_PASS",
        "code_commit_before_closure": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "browser_terminal_gate": gate,
        "source_at_closure": before["source-at-closure-snapshot.zip"],
        "bundles": bundles,
        "records": records,
        "exact_source_and_log_bytes_verified": True,
        "source_and_member_set_unchanged_during_archive": True,
        "excluded_scope": (
            "No402 old logs/ZIP or404 research; shared pure402 oracle retained; "
            "partial artifacts abort archival"
        ),
    }
    with (OUTPUT / "index.json").open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(index, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                "zip_members": len(records),
                "source_files": len(before["source-at-closure-snapshot.zip"]),
                "bytes_preserved": sum(row["bytes"] for row in records),
                "bundles": bundles,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
