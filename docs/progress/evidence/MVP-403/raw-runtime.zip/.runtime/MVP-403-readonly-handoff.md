# MVP-403 decisions / receipt transaction boundary — frozen handoff

Owned source: `apps/api/app/api/dependencies.py`. New tests: `apps/api/app/tests/test_decision_readonly_transaction.py`. Baseline commit: `869ba84da3af0847205d667c04c0fb15396344b9`. Actual final PG session **32418 is closed, exit 0**; no own remaining DB/test process. No formal database, business source, DTO, contract, financial algorithm or MVP-402 proof change.

The minimal dependency addition matches the **server-selected route template plus GET** for decisions list/detail/explanation and action decision/receipt. It joins the existing `SET TRANSACTION READ ONLY` before yielding the session, thus before the existing `DemoUser` SELECT. Existing GET repeatable-read selection and all user/clock/query/immutable/receipt validators are unchanged. Funds POSTs do not match the new whitelist.

## Actual evidence

- RED: `.runtime/MVP-403-readonly-red.{json,txt}`; **1 failed / 4.28s, exit 1**, process 5.5317s; actual first DemoUser SELECT transaction was `repeatable read / off` for GET decisions. UTC 2026-10-04 18:18:29.149037 → 18:18:34.681756. Source unchanged during the run.
- GREEN: `.runtime/MVP-403-readonly-green.{json,txt}`; **7 passed / 52.83s, exit 0**, process 54.4421s. UTC 18:19:40.457108 → 18:20:34.900577. `changed_during_run=[]` for dependencies, new tests and the three reused test source files.
- Ruff check, format --check and `mypy --follow-imports=silent` for both owned files all **exit 0**; raw output `.runtime/MVP-403-readonly-{ruff,format,mypy}.txt`.

Actual pytest argv (full absolute executable path and node selection are in metadata):

```text
.venv/Scripts/python.exe -m pytest
  apps/api/app/tests/test_decision_readonly_transaction.py
  apps/api/app/tests/test_decision_trace_api.py
  apps/api/app/tests/test_execution_api.py::test_http_preparation_confirmation_execution_and_receipt_roundtrip
  apps/api/app/tests/test_decision_trace_audit.py::test_cross_user_history_is_404_and_does_not_touch_any_business_table
  --no-cov -vv -s -x --durations=10 -p no:cacheprovider
```

The environment explicitly sets PYTHONUTF8=1, UV_CACHE_DIR to repository `.uv-cache`, PYTEST_ADDOPTS empty and PYTHONPATH=apps/api. All fixtures use the original guarded random `bf_test_*` database mechanism, with real migration/native seed. New setup timing spies call the actual operations and do not substitute financial results.

The new first-query probe executes actual PostgreSQL `SHOW` on the same Connection **before** the first actual users SELECT. Five GET paths (including 404) observe RR/on. Actual POST prepare observes read committed/off. A successful history response followed by missing 404, unready receipt 409 and an actual corrupted original snapshot hash returns only the error envelope; detail, explanation and action-decision corruption is rejected without repair. All **23 mapped business-table** snapshots are identical across those reads (`Base.metadata.sorted_tables`; excludes physical `alembic_version`). Reused tests cover original frozen inputs, query/clock/authority rejection, explicit assessment write/idempotency, tenant 404, and real prepare/confirm/execute/successful receipt roundtrip. No full suite or golden rerun.

## Timing boundary and frozen hashes

For the new tests, actual create/migrate/seed times were recorded separately; one GREEN setup was 0.041 / 0.666 / 0.819s. The slowest existing history read test is 10.41s across prepare and several reads; successful complete GET HTTP durations were 2.547–2.610s and include original/reference/audit verification. **Audit internals were not separately timed**, and no product SLA or performance optimization is claimed. The real full receipt command/read test took 9.72s; receipt GET 200 HTTP duration was 47ms in this fixture. These are local test observations, not benchmarks.

- dependencies.py SHA256: `1a76d79010de5c90a858a4ee24b1243ed12753e4292a6f70a45a4f7e5f39ce7e`
- new test SHA256: `89f1f4125f4fdc32b4ec156647958b822bde2bc867c4570a0c15521b183848bb`
- GREEN raw log SHA256: `b50ff2ea50975edc87afc4236ae038b15c2400deb299dd29b364bd6fb2cdb072`

Both owned files are FROZEN and handed to root. Root/trace_audit may now start the explicitly planned real Edge acceptance. This evidence establishes the backend read transaction boundary, not completion of the entire MVP-403 page acceptance.
