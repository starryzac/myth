"""Real minimal 403 initialization; invoked only by the explicit disposable driver.

Native seed plus the existing trusted zero-CASH import; no old income amount is fabricated.
Assessment is an explicit saved preference, not an execution grant. A separate original
transfer is prepared, exactly confirmed, and executed using existing financial services.
All returned IDs/DTOs are actual. Browser verification starts after initialization ends.
"""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

from app.db.models import DecisionRun
from app.domain.decision_trace_types import DecisionTrace
from app.services.action_contracts import ConfirmActionRequest, PrepareActionRequest, TransferIntent
from app.services.decision_assessment import SaveAssessmentRequest, save_assessment
from app.services.decision_trace import get_action_trace
from app.services.demo_seed import DEMO_USER_ID, seed_demo
from app.services.execution import confirm_action, execute_action, prepare_action
from app.tests.test_execution_service import transfer_accounts
from sqlalchemy import select
from sqlalchemy.orm import Session

BASE_NOW = datetime(2026, 10, 4, 1, tzinfo=UTC)
READ_NOW = BASE_NOW + timedelta(minutes=1)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def initialize_fixture(engine, readonly_engine, destination: Path, phase, capture):
    raw_directory = destination / "initialization"
    raw_directory.mkdir()

    def raw(name, dto):
        path = raw_directory / (name + ".json")
        with path.open("x", encoding="utf-8") as handle:
            handle.write(dto.model_dump_json(indent=2))

    phase("seed", lambda: seed_demo(engine))
    source_id, destination_id = phase(
        "trusted-zero-cash-scope-import", lambda: transfer_accounts(engine)
    )
    before, before_meta = capture("fixture-before-assessment")
    accounts = {row["id"]: row for row in before["accounts"]}
    source_balance = accounts[str(source_id)]["balance_cents"]
    require(
        accounts[str(destination_id)]["balance_cents"] == 0, "Trusted target must start at zero"
    )
    amount = 12345
    options = [amount, source_balance + 1]
    intent = TransferIntent(
        kind="transfer_internal",
        source_account_id=source_id,
        destination_account_id=destination_id,
        amount_cents=amount,
    )
    saved = phase(
        "save-amount-option-assessment",
        lambda: save_assessment(
            engine,
            DEMO_USER_ID,
            SaveAssessmentRequest(
                idempotency_key="403-amount-options", intent=intent, amount_options_cents=options
            ),
            BASE_NOW,
        ),
    )
    raw("saved-assessment", saved)
    require(
        saved.trace is not None
        and saved.trace.phase == "EVALUATION"
        and len(saved.trace.candidates) == 2
        and saved.actions == [],
        "Saved finite assessment is incomplete",
    )
    require(
        any(row.status == "BLOCKED" and row.reasons for row in saved.trace.candidates),
        "Excess-balance amount must have an actual rejection reason",
    )
    after_assessment, assessment_meta = capture("fixture-after-assessment")
    for table in (
        "accounts",
        "transactions",
        "bank_operations",
        "simulated_bank_postings",
        "external_bank_facts",
        "action_plans",
        "action_receipts",
        "action_resource_reservations",
    ):
        require(
            before[table] == after_assessment[table],
            "Saved evaluation wrote financial facts: " + table,
        )
    prepared = phase(
        "funds-prepare-transfer",
        lambda: prepare_action(
            engine,
            DEMO_USER_ID,
            PrepareActionRequest(idempotency_key="403-real-transfer", intent=intent),
            BASE_NOW + timedelta(seconds=10),
        ),
    )
    raw("prepared-action", prepared)
    require(
        prepared.autonomy_level == "ASK_ONCE"
        and prepared.effect.action_type == "TRANSFER_INTERNAL"
        and prepared.effect.amount_cents == amount,
        "Original transfer must require exact human consent",
    )
    confirmed = phase(
        "funds-confirm-exact-effect",
        lambda: confirm_action(
            engine,
            DEMO_USER_ID,
            prepared.action_id,
            ConfirmActionRequest(effect_hash=prepared.effect_hash, accepted=True),
            BASE_NOW + timedelta(seconds=20),
        ),
    )
    raw("confirmed-action", confirmed)
    settled = phase(
        "funds-execute-original-operation",
        lambda: execute_action(
            engine, DEMO_USER_ID, prepared.action_id, BASE_NOW + timedelta(seconds=30)
        ),
    )
    raw("settled-action", settled)
    require(
        settled.status == "SUCCEEDED"
        and settled.receipt is not None
        and settled.receipt.executed_cents == amount
        and settled.receipt.fee_cents == 0
        and settled.receipt.loss_cents == 0,
        "Real transfer did not reconcile its exact receipt",
    )

    def read_parent():
        with Session(readonly_engine) as session:
            return get_action_trace(session, DEMO_USER_ID, prepared.action_id, READ_NOW)

    parent = phase("readonly-read-parent-trace-and-financial-links", read_parent)
    raw("original-parent-trace-at-native-read-now", parent)
    require(
        parent.trace is not None
        and parent.trace.phase == "PREPARE"
        and parent.audit_chain_status == "VALID",
        "Original trace or actual top audit status is not valid",
    )
    with Session(readonly_engine) as session:
        children = list(
            session.scalars(
                select(DecisionRun)
                .where(DecisionRun.parent_run_id == parent.run_id)
                .order_by(DecisionRun.as_of, DecisionRun.id)
            )
        )
        child_records = []
        for row in children:
            trace = DecisionTrace.model_validate_json(
                json.dumps(row.input_snapshot["decision_trace"])
            )
            require(
                trace.parent_run_id == parent.run_id and trace.action_id == prepared.action_id,
                "Child trace does not retain its actual parent and operation identity",
            )
            child_records.append(
                {
                    "run_id": str(trace.run_id),
                    "phase": trace.phase,
                    "parent_run_id": str(trace.parent_run_id),
                    "as_of": trace.as_of.isoformat(),
                }
            )
        missing_id = uuid4()
        require(session.get(DecisionRun, missing_id) is None, "Missing-path ID unexpectedly exists")
    require(
        {row["phase"] for row in child_records} == {"CONFIRM", "RESERVE", "BANK_ACCEPT"},
        "Actual execution child phases are incomplete",
    )
    after_funds, funds_meta = capture("fixture-after-settled-transfer")
    new_accounts = {row["id"]: row for row in after_funds["accounts"]}
    require(
        new_accounts[str(source_id)]["balance_cents"] == source_balance - amount
        and new_accounts[str(destination_id)]["balance_cents"] == amount,
        "Real two-account transfer did not conserve its exact money",
    )
    require(
        sum(row["balance_cents"] for row in before["accounts"])
        == sum(row["balance_cents"] for row in after_funds["accounts"]),
        "Total account money changed",
    )
    require(
        len(after_funds["bank_operations"]) == len(before["bank_operations"]) + 1
        and len(after_funds["action_receipts"]) == len(before["action_receipts"]) + 1,
        "Fixture must create exactly one original bank operation and reconciled receipt",
    )
    actual_operation = next(
        row
        for row in after_funds["bank_operations"]
        if row["id"] == str(settled.receipt.bank_operation_id)
    )
    require(
        actual_operation["operation_type"] == "TRANSFER_INTERNAL",
        "Receipt is not a native transfer",
    )
    return {
        "classification": "ACTUAL_INITIALIZATION_NOT_BROWSER_ACCEPTANCE_OR_PRODUCT_SLA",
        "base_now": BASE_NOW.isoformat(),
        "native_read_now": READ_NOW.isoformat(),
        "saved_assessment_run_id": str(saved.run_id),
        "amount_options_cents": options,
        "candidate_statuses": [
            {"key": row.candidate_key, "status": row.status, "reasons": row.reasons}
            for row in saved.trace.candidates
        ],
        "assessment_constraint_count": len(saved.trace.constraints),
        "action_id": str(prepared.action_id),
        "parent_run_id": str(parent.run_id),
        "phases": [
            {"run_id": str(parent.run_id), "phase": "PREPARE", "parent_run_id": None},
            *child_records,
        ],
        "native_receipt_kind": "ActionReceiptResponse",
        "bank_action_type": actual_operation["operation_type"],
        "receipt_id": str(settled.receipt.receipt_id),
        "bank_operation_id": str(settled.receipt.bank_operation_id),
        "posting_ids": [str(identity) for identity in settled.receipt.posting_ids],
        "receipt_path": f"/api/v1/actions/{prepared.action_id}/receipt",
        "top_audit_chain_status": parent.audit_chain_status,
        "original_explanation_audit_chain": parent.explanation.audit_chain
        if parent.explanation
        else None,
        "missing_run_id": str(missing_id),
        "source_account_id": str(source_id),
        "destination_account_id": str(destination_id),
        "executed_cents": amount,
        "source_cash_before_cents": source_balance,
        "source_cash_after_cents": source_balance - amount,
        "data_sources": [
            "app.services.demo_seed.seed_demo",
            "app.tests.test_execution_service.transfer_accounts",
            "app.services.decision_assessment.save_assessment",
            "app.services.execution.prepare_action",
            "app.services.execution.confirm_action",
            "app.services.execution.execute_action",
            "app.services.decision_trace.get_action_trace",
        ],
        "before_assessment": before_meta,
        "after_assessment": assessment_meta,
        "after_funds": funds_meta,
        "raw_dto_directory": str(raw_directory),
        "budget_boundary": "One saved evaluation and one real transfer; sync budgets are not SLA",
    }
