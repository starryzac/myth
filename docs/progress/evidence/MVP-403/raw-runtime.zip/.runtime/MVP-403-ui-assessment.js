async (page) => {
  const id = 'c0a6c96f-b812-5e9f-8f6b-aadea282ab7e';
  const start = Date.now();
  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/decisions/' + id) && r.request().method() === 'GET'),
    page.getByRole('link', {name: '查看 ' + id, exact: true}).click(),
  ]);
  await page.getByRole('region', {name: '8 审计哈希状态'}).waitFor({state: 'visible'});
  const names = ['1 银行事实与证据','2 当时用户策略','3 受保护金额与约束','4 候选动作','5 拒绝与限制原因','6 当时自主等级','7 当前关联动作与回执','8 审计哈希状态'];
  const layers = [];
  for (const name of names) layers.push({name, text: (await page.getByRole('region', {name}).innerText()).slice(0, 1400)});
  const reasons = await page.getByRole('region', {name: '5 拒绝与限制原因'}).getByRole('button').allTextContents();
  await page.screenshot({path: '.runtime/MVP-403-browser-cli/assessment-top.png'});
  await page.getByRole('region', {name: '4 候选动作'}).screenshot({path: '.runtime/MVP-403-browser-cli/assessment-candidates.png'});
  return {url: page.url(), method: response.request().method(), status: response.status(), wall_ms: Date.now() - start, layers, reason_buttons: reasons,
    user_agent: await page.evaluate(() => navigator.userAgent), overflow: await page.evaluate(() => document.documentElement.scrollWidth > innerWidth)};
}
