"""Plain disposable-test API: real routes; only engine and trusted now dependencies differ.

NOT_EXECUTED_AT_PREPARATION. No profiling, route monkeypatch, synthetic response, or control API.
The driver alone owns creation and deletion of the generated local bf_test database.
"""

import os
import sys
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy.engine import make_url

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps/api"))

from app.api.dependencies import get_engine, get_now  # noqa: E402
from app.db.session import create_database_engine  # noqa: E402
from app.db.testing import require_test_database  # noqa: E402
from app.main import create_app  # noqa: E402

NOW = datetime(2026, 10, 4, 1, 1, tzinfo=UTC)
url = make_url(os.environ["DATABASE_URL"])
require_test_database(url.database)
if (
    url.drivername != "postgresql+psycopg"
    or url.host not in {"127.0.0.1", "localhost", "::1"}
    or url.port != 54329
    or os.environ.get("BF_DECISION_TEST_NOW") != NOW.isoformat()
):
    raise ValueError(
        "Only the explicit generated local54329 database and fixed trusted now are allowed"
    )

trusted_engine = create_database_engine(url.render_as_string(hide_password=False))


@asynccontextmanager
async def lifespan(_api):
    try:
        yield
    finally:
        trusted_engine.dispose()


api = create_app()
api.router.lifespan_context = lifespan
api.dependency_overrides[get_engine] = lambda: trusted_engine
api.dependency_overrides[get_now] = lambda: NOW
