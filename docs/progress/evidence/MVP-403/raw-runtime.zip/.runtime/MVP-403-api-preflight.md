# MVP-403 后端与性能预检

`READ_ONLY_SOURCE_REVIEW / NOT_IMPLEMENTED / NO_NEW_DB_TEST_BROWSER_RUN`。本次仅查源码及已有 ignored 证据，未连接数据库、运行 GET、pytest、浏览器或优化候选。402 的 23 项定向集成 GREEN 是 root 已报告结果，不是本预检新增测试。源码基线 HEAD `afc32e6d956255b5cf9147501865185946a7ef06`，工作区已有冻结的 402 修改；读取时刻约 2026-10-04T17:00Z（本地 2026-10-05）。

## 原计划八层与现有数据

依据 repo 原始《钱途有界_初版开发计划_Codex执行版.md》10.4（约 653–664 行）及 MVP-403（约 789–792 行），验收是评委无需后端日志理解一次决策，不能把新计算解释成旧决策。

| 层 | 已有真实数据 | 403 展示边界/缺口 |
| --- | --- | --- |
| 1 银行事实 | `trace.sources`：当时 evidence level/type/ref、content、声明与实际 capture hash、VALID/INVALID、observed/valid time/supersedes；`inputs` 保存实际边界/执行依据。 | 当时副本是主内容；`current_references` 另列当前 status/MISSING，不能用最新余额覆盖历史。原坏源金额类型仍按原文显示无效，不转换为 0 或假合规金额。完整外部银行事实/分录原件主要在 audit subject snapshots，当前无公开 subject reader。 |
| 2 用户策略 | `trace.policies` 保存原 policy/version UUID、version number、configuration/capture hash、当时状态、确认与有效时间。 | 与当前 policy 状态分开；不读取当前版本替代原配置。 |
| 3 受保护金额 | `constraints` 包含 required/available（可负）、due_date、tri-state satisfied、is_hard、calculation/reason；`outcome.validation` 等冻结实际/预计 boundary。 | 原约束来源数值与未知态可直接展示；不同 phase 可能没有该项，不能补算。273 个边界点等完整 JSON 已保存，展开/折叠是显示选择，不得剪掉原件。 |
| 4 候选动作 | `candidates` 的 key/kind/status、inputs/result；`inputs.effect` 与执行规划原件。 | 候选不等于授权或已经执行；保留 NOT_EVALUATED/空候选的真实阶段含义。 |
| 5 被拒绝及原因 | candidate.reasons、constraint.reason_code、`explanation.reasons` 的原字段引用；未知码保留明确 fallback。 | 不把所有非最终候选都标成拒绝，按原 status/reasons；不重新跑引擎生成理由。 |
| 6 最终自主等级 | `outcome.autonomy_level` 或 decision/autonomy、`explanation.level`、financial_evaluation、confirmation_required/satisfied。 | 原 ASK 的人工确认来源在 phase 输入；UNKNOWN 银行状态、财务 NOT_EVALUATED 与自主等级是独立维度。 |
| 7 执行回执 | `response.actions` 给原动作/run/request hash、bank operation/status、receipt id/status；`GET /actions/{id}/receipt` 给金额/费用/损失、posting ids、经济时钟。 | trace link 不含全部回执正文；新 301 动作可单独读经核验的回执。旧 205 recovery 的 trace link 已核验，但同一动作 GET 入口不保证能解码 legacy BankCommand，不能假定全种类通用。重置后旧 live action/run 删除，永久回执/trace snapshot 留存但尚无公开完整原件详情入口。 |
| 8 审计哈希状态 | response 顶层 `audit_chain_status`；audit verify 给 status/chain/reference/checkpoint、tail/count、errors；audit head/event envelope。 | explanation.audit_chain 的旧字段固定 NOT_IMPLEMENTED，403 应以顶层真实状态为准。event/head 的 COMPLETE 表示正文可读/有 head，不能替代完整 verify 的 VALID；LEGACY/UNSUPPORTED/INCOMPLETE 不显示通过。 |

## 已公开的查询合同

| 入口 | 参数/输出 | 实际读取与校验 |
| --- | --- | --- |
| `GET /api/v1/decisions` | limit 1..100，默认20；cursor；`DecisionTraceList` 摘要及 next_cursor。 | `(as_of DESC,id DESC)` 稳定 keyset；URL-safe cursor 限256字符/严格JSON键/aware时间/UUID。每项仍加载完整 run 并 `_stored_trace`，核 input hash、trace hash/身份/父链/索引/约束投影；不查全链或当前来源。 |
| `GET /decisions/{run_id}` | 完整 `DecisionTraceResponse`，含 trace、explanation、current refs、action links、children、legacy、read_at。 | 同 user 查 run，拒绝未来 run；校验原轨迹、当前来源内容及经济回执，再查本 run 审计锚并完整 verify。没有客户端 clock/authority。 |
| `GET /decisions/{run_id}/explanation` | `TraceExplanation`。 | 内部调用同一完整 detail getter；不完整/不支持时409。detail 已带 explanation，页面无需重复发该请求。 |
| `GET /actions/{action_id}/decision` | 同完整 trace response。 | 同 user 取原 action→run，再核 response.actions 确有此原 action；完整 trace 可读入口已存在。 |
| `GET /audit/events` | epoch_id 可选；limit1..100 默认50；cursor；`AuditEventPage`。 | 未选 epoch 取当前；序号升序。cursor绑定 user/epoch/sequence/id，原 cursor 行必须存在。单条解析规范正文/hash；legacy/unknown 用 original 保留。不是全链核验结果。 |
| `GET /audit/head` | epoch_id 可选；head 或 null、COMPLETE/LEGACY_UNAUDITED。 | 明确指定别人的/不存在 epoch 404；无当前 head 为 legacy，不创建 epoch。非 verify。 |
| `POST /audit/verify` | 只读；epoch_id 可选、严格 checkpoint 对象、mode PREFIX/EXACT。 | 完整选定 epoch 的 chain+typed原件+当前不可变绑定；prefix不等于exact，预算不足不通过。未传 checkpoint 不签发/输出新 checkpoint。 |

**当前没有服务器过滤**：decisions 没有 phase、status、action_id、parent、时间区间；audit events 只有 epoch，缺 type/run/action/correlation 过滤。没有 epoch 列表、单 event 详情、永久 subject 原件读取接口。Query extra forbid（audit 额外显式 `_queries`）不能静默接受拟新增字段。页面若只过滤本页必须标明本页范围；不能声称覆盖全部历史。

cursor容量也有差别：decision显式256字符上限；audit cursor在解码前没有同样的长度门禁。后者仍严格检查内容及原行，但不能把“limit100”说成全部请求输入都已有字节上限。本次未发送大请求。

`children` 仅直接子 run IDs，`trace.parent_run_id` 指父，完整 phase 要按真实关系逐条读，不依赖列表的相邻时间。分页跨多个 HTTP 请求没有统一 export 快照；并发新写入可能改变头部，cursor 只提供已有 keyset 的稳定前进，不保证全量固定快照。

## 权限、来源与只读边界

- `api/dependencies.py:25,54`：固定保留 DEMO_USER 身份必须存在、external_ref 正确、is_simulated=True。无客户端 user selector，也无真正登录/RBAC；这是初版明确的单模拟用户边界，403 不应宣称多用户认证已经完成。
- `decision_trace.py:238,305,344,492,599,682`：tenant 查询、最长32层父链防循环、action→祖先绑定、索引与冻结来源集合、约束 projection、request/effect身份/hash、原 bank/receipt 验证都存在。原 source/policy 内容变化409；正常生命周期只附注。缺当前 source 可展示 MISSING；已锚 OPEN 原件缺失由 audit verify 报 INTEGRITY_ERROR，不修复。没有由源码确认的跨 tenant 越权读取路径。
- audit 按 `(user,epoch,kind,id,snapshot_hash)` 核永久副本；同 UUID 跨 kind 不混用。OPEN 完整 current originals；SEALED 从永久 archive 验原旧账本/封口，不能借重置后 live 填补。legacy gap 保留且不能掩盖当前完整性错误。
- 所有 GET 依赖取得 RR 单 Session；audit GET/POST 明确 READ ONLY，dashboard 与新 compilation reader 也明确 READ ONLY。**decision/action GET 当前没有 SET TRANSACTION READ ONLY**。getter有 no_autoflush且源码只 SELECT，已有测试证明其结果零写入；但数据库级 RO 保障尚未覆盖这些路径。这是 403 reader 接缝待定，不是本次已经补齐。
- list/detail 两类 COMPLETE 与 audit VALID 范围不同；列表不核实时引用/全链，不能提前给列表每行绿色“审计通过”。若来源不完整/unknown schema，保留 legacy/unsupported 原件与原因，不补造八层数据。

## 容量与现有 SQL 边界

`audit_chain.py:84,672` 在装载前 count+octet_length：每 epoch <=10000 events、<=20000 snapshots、规范原文合计<=64MiB；超出返回 INCOMPLETE。纯域另有原件/current bundle 的预算/错误顺序，不能优化掉。页面100条分页不是完整核验的预算替代。

trace 单包限10MiB、深32、JSON节点250000、sources10000/policies1000/constraints10000/candidates1000。decision 列表每行都拿完整 JSON，100条不是轻量元数据查询；当前未有整页字节预检。detail children/动作/回执集合亦不是分页输出。未来改动需明确资源失败语义，不能将被截断记录称 COMPLETE。本次没有跑压力测试或估算实际内存峰值。

已有索引：decision `(user,as_of)`、`(user,subject_action,as_of,id)`、`(user,parent,as_of,id)`；audit epoch sequence/key/hash unique、fact唯一索引、`(user,occurred_at)`。未执行 EXPLAIN，无证据称数据库索引缺失是当前主要慢因，也不建议先加猜测索引。

## 只由源码确认的重复调用链

1. detail → `_stored_trace`（hash/DTO/verify/relations/constraints）→ `explain_trace` 再 `verify_trace` → `_current_references` 逐source/逐policy SELECT及复制/hash → `_action_links` 逐动作、bank、receipt并真实经济校验。
2. 同 detail → `get_decision_audit_status` 再查同 run/current epoch/DECISION_RECORDED锚 → `verify_audit_chain` 全 epoch。后者 OPEN 末段又对每个 audited run执行 `_stored_trace/_current_references/_action_links`。初次 detail 对选中 run 的工作因此会重复；不能仅按 epoch VALID 让未锚 run 继承有效。
3. service verify 每 snapshot：`parse_subject` 完整校验，再 `subject_hash` 严格重验；current 按 kind/id 去重查 live 后 `build_subject`。ReferenceBundle 构造及 pure verify 的原件 bytes预算→`_subject_index` build+public hash→`_current_index` build/重复版本 hash，反复复制编码。
4. pure `_references/_external_references` 同一个已准入原件为 role/anchor 再求 subject_hash；`_immutable` 对原/当前逐字段 canonical；decision anchor 再核 trace；seal manifest/digest也重建完整版本索引。这些是实际源码调用重复，不是已测比例。
5. 前端若每个 parent/child、每行 summary 点击都并发 detail，会每次重新验证整个 epoch；另发 explanation 也是完整重读。现 dashboard 的 `current_epoch_audit` 已展示正确批量模式：一次验证+真实DECISION_RECORDED锚集合，未锚仍LEGACY。它不是通用已验证详情缓存，不能直接把 dashboard card 的 status当 detail读取证明。

## 401 可复用候选及实际性能证据界线

已经部署的 401 新副本编码优化是 `encode_subject_original`（domain:209 / service capture:408）：一次完整验证后同 bytes 得 text+原 namespace SHA；public hash/text/parse仍强验。此优化已有原字节/错误对照及 root实际链验收，403 不能再次将其称未实施或重复收益。

仍**未部署/未运行**的 `.runtime/MVP-401-verify-reuse-candidate`：stage A仅 `_subject_index/_current_index`，同调用私有已验证copy+bytes建索引/digest；stage B只复用已准入原件 digest 给 role/anchor，不用head-only、entity-id/global/cache授权。这是合理先测候选，必须保留预算先行/错误优先级、typed identity、完整tenant/epoch/cause/receipt/经济legs、current missing、legacy/unsupported及PREFIX/EXACT输出精确等价。当前源码 SHA与该候选原稿仍一致；candidate的AST范围证据不等于功能验证。

已有证据：`.runtime/MVP-401-golden-optimized-phases.json`（SHA `b8bee33c38c92dffbcdb3709578d680d2b5cfe6bdcb1ac155f2858210fdb6640`）为 root 802.35s真实黄金节点中的必要 dashboard GET monotonic观测，末对82.047/89.485s；其它阶段对34.484/36.579、43.172/46.641、37.813/50.203、58.829/65.437s。这是带 instrumentation 的必要验收，不是产品SLA，不是decision detail时延，也不证明stage A/B可节省多少。

早期第四轮同步资金 profile 确证新副本编码热点；旧 GET worker pstats 有 asyncio累计超过wall/错误caller的污染，不能精确归因。`.runtime/MVP-401-audit-performance-observed.md` 已明确该限制。402新增读路径/403 decision/audit列表详情未有可靠的新分段实测。本次只读取已有证据，不启动任何新 profile。

403实施前最小决策：八层先消费同一次 detail，回执按实际解码种类处理；live轨迹与已SEALED归档回看范围须明示；是否补 server filters/epoch/原件reader另行冻结；decision GET 的数据库RO接缝补齐；性能先选单次pure验证stage A，不把 UI分页、跨请求cache或资金授权改动混入。若进一步共享详情核验，只能在同Session/same RR/RO且明确未变输入下提供私有上下文，仍单独核选中run锚和原件；资金写入/flush/savepoint/epoch切换/新请求后不能沿用。

## 可复用验证源（未在此次重跑）

`test_decision_trace_api/storage/audit` 已覆盖原 explanation/zero-write、tenant404、源重hash/合法supersession、约束/父链/索引/cursor/未来时钟、unknown算法、301/旧receipt/UNKNOWN原身份。`test_audit_api/storage/chain_domain` 覆盖真正RR+RO、预算、typed锚、head/epoch/checkpoint/永久归档；`test_audit_subject_encoding` 有旧字节oracle。403界面E2E仍须新真实逐层观察，不能拿以上后端节点替代。只挑新增页面与实际被改接缝的风险最小集；本预检不规定立即重跑黄金慢链或全量。

读取时源 SHA：decision_trace `f1566cbd9fefa4ffa9cb6f3154a5bebce5424246df8554db4c71bef0b8944c47`；audit service `d1e977b64d6f80b70bbab7d980ba891d8e5c97bcdc4859f8f52ab4dac3b8f402`；audit domain `5c1877cd4f1d1b41e5dd498ad0d07de39633aa21299d085f6c08f6e57bc4a640`；dependencies `733c63153e0e1db85cf548cfd688405d77175d478f5837471c410a0e7ae15f15`。仅此 ignored MD 为本任务新写文件。
