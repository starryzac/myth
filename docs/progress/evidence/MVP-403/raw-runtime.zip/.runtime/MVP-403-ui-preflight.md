# MVP-403 最小决策轨迹页面预研

状态：DESIGN_ONLY，403未开始实施。只读原计划653–664、789–792、真实决策/动作/审计GET路由、DTO和录制/读取服务；未改生产、测试、合同或正式docs，未运行测试、DB、HTTP或浏览器。402 Web继续冻结。

原验收目标：评委不看后端日志也能理解一次决策，按银行事实→用户策略→受保护金额→候选→被拒原因→自主等级→执行回执→审计哈希状态八层展示。此项不实现404资金事件控制台、FULL策略关系图或新的金融推演算法。

## 1. 最小读取与导航

- 在现hash shell正式实现后增加“决策轨迹”入口 `#decisions`；详情用 `#decisions/<run_id>`，只解析/校验真实UUID，不拼伪后端route。列表→详情→父/子阶段均可返回/前进，未知hash保持明确错误或安全默认。
- GET `/api/v1/decisions?limit=20` → `DecisionTraceList`。展示 run_id、as_of、trigger_type、status、completeness、phase、parent_run_id、action_id；next_cursor原样传回真实GET加载下一页。不发未经支持的phase/action/search参数，不声称当前20条是全部或有未提供的total。
- GET `/api/v1/decisions/{run_id}` → `DecisionTraceResponse`，已经同时给 trace、explanation、current_references、actions、children、read_at、audit_chain_status。默认详情只需这一响应，避免再调用 explanation 重复完整核验。header明确“决策依据时点 as_of / 当前关联读取时点 read_at”。
- 只有从真实action_id进入但不知道run时才使用 GET `/api/v1/actions/{action_id}/decision`（同Response）；不得通过GET actions/autonomy重新计算后替换历史结果。
- 回执金额展开时按真实actions[].action_id调用 GET `/actions/{id}/receipt`，其他历史层仍用所选run的冻结副本；不是把今日accounts/policies/dashboard补进旧轨迹。
- 页面为空真实显示“暂无保存的决策轨迹”。不调用 POST decisions/assess、prepare、confirm、execute 或恢复动作制造展示数据。

## 2. 八层页面 / 实际DTO映射

以下均引用 `components['schemas']` 正式合同。JsonObject动态层需要运行时识别已知字段和阶段；没有记录就显示未记录/待核验，不补理由或金额。

| 层 / 最小可见内容 | 真实API与字段 | 可执行锚点与展示边界 |
| --- | --- | --- |
| 1 银行事实与证据 | 详情.trace.sources[]: TraceEvidence.id/evidence_level/source_type/source_ref/status_at_decision/observed_at/valid_from/valid_to/content_integrity/content_hash/captured_content_hash；录制inputs内冻结snapshot/positions/products | 每个source本页锚点 `evidence-<id>`；BANK_CONFIRMED与BANK_OBSERVED、USER_DECLARED、MODEL_INFERRED、用户确认来源分清。VERIFIED只是声明内容hash一致，不将原声明或MODEL解释当银行事实。current_references标注状态变更/缺失，但不改冻结依据 |
| 2 用户策略 | trace.policies[]: TracePolicy.id（版本id）/policy_id/version_number/configuration/status_at_decision/confirmed_at/valid_from/valid_to/configuration_integrity/configuration_hash/captured_configuration_hash | 本页 `policy-<versionid>`；展示当时版本全部已记录字段，current_references同id的状态变化另行说明。不能取402当前版本填替历史；原配置INVALID不能用PolicyConfigForm金额格式化误当合法配置 |
| 3 受保护金额与约束 | trace.constraints[]: TraceConstraint.constraint_key/policy_version_id/is_hard/satisfied/required_cents/available_cents/due_date/reason_code/calculation；calculation有录制calculation_trace点的 protected_cents_by_reason/cash_cents/margin_cents；outcome.validation中记录baseline/projected/reservation-adjusted BoundaryResult | 本页 `constraint-<index>`，日期/阶段/实际或预计的分组沿constraint_key与记录路径。required/available/null/signed margin精确显示；不在前端重算分层sum、最小余量或91日安全闲置。已有BoundaryResult.safe_idle/minimum_margin直接显示并标识该路径，未记录就空，不填今日总览 |
| 4 候选动作 | trace.candidates[]: candidate_key/kind/status/inputs/result/reasons；真实kind有ASSET_ALLOCATION、GOAL_ALLOCATION、RECOVERY_POSITION、USER_AMOUNT_PREFERENCE | 本页 `candidate-<index>`；显示已存类型/状态、经济参数与计算上限/净模拟收益/退出可用时点等已有结果。普通执行没有候选时显示“该阶段未保存候选集合”，不捏造备选动作。TraceCandidate.status是Label，不假定全类型共用一枚举 |
| 5 被拒绝候选及原因 | candidates[].reasons + explanation.reasons[]: TraceReason.code/text/references；constraints[].reason_code/satisfied；已保存的outcome理由 | explanation引用如 candidates[0].reasons[1]、constraints[0].required_cents、outcome.validation.reasons[0]，映射到本页对应元素。ASSET_ALLOCATION REJECTED/FEASIBLE、其他kind BLOCKED等按实际已知类型标注；ASK_ONCE/ADVISE_ONLY不统称被拒。未知code保留原code与服务端“未提供模板”，不LLM补原因 |
| 6 最终自主等级 | explanation.level/financial_evaluation/confirmation_required/confirmation_satisfied/summary；trace.outcome.decision或autonomy、执行记录顶层autonomy_level | 显示AUTO_EXECUTE/ASK_ONCE/ADVISE_ONLY/BLOCKED的当时等级；financial NOT_EVALUATED明确未评估。需要确认与已确认分开；COMPLETE/row.status=SUCCEEDED只代表保存/读取完整，不是资金执行成功。阶段父/子链接用trace.parent_run_id、Response.children，不把子BANK_ACCEPT替代父PREPARE结论 |
| 7 执行回执 | Response.actions[] TraceActionLink: action_id/decision_run_id/status/request_hash/bank_operation_id/bank_status/receipt_id/receipt_status；按需GET receipt→ActionReceiptResponse.executed_cents/fee_cents/loss_cents/posting_ids/occurred_at/reconciled_at | 原action/operation/receipt编号关联，当前link有receipt才展示已核对回执详情。无回执且UNKNOWN/在途保持未完成；GET receipt的409 RECEIPT_NOT_READY显示尚无已对账回执。历史EVALUATION无action自然无回执，不能当缺失失败；不生成新操作或资金POST |
| 8 审计哈希状态 | trace.input_hash/trace_hash + Response.audit_chain_status；服务端GET详情已调用 _stored_trace/verify_trace、来源/约束/经济回执核验与 get_decision_audit_status | 区分冻结轨迹hash、原源/配置声明hash、所选run审计链status。状态VALID/INTEGRITY_ERROR/UNSUPPORTED_VERSION/LEGACY_UNAUDITED/INCOMPLETE按正式枚举显示。TraceExplanation.audit_chain固定NOT_IMPLEMENTED是旧解释器兼容字段，不覆盖Response实际审计状态，也不把它叫已验证。hash不在前端算，不用绿色head替所选run核验 |

录制路径接缝：`capture_boundary`保存 inputs.{name}.snapshot/versions/positions/products/source_issues，名字有autonomy_boundary/asset_boundary等；执行trace将其置于 inputs.planning 内，同时保存inputs.effect/execution_context/confirmation。保护点由服务端 `boundary_constraints` 录制 required_cents与完整calculation；前端只选取已记录点显示，不重算。版本、证据引用均优先使用trace冻结对象和其记录的id。

## 3. 实际审计GET与锚点缺口

- GET `/audit/head?epoch_id=<uuid>` → HeadResponse/nullable AuditHead。未带epoch默认当前纪元；有head或COMPLETE不等于校验成功。
- GET `/audit/events?epoch_id=<uuid>&limit=50&cursor=<opaque>` → AuditEventPage，真实payload.references[]、anchors[]与 envelope.decision_run_id/action_plan_id可查事件关联；只读分页按sequence升序。API**不支持run_id/action_id filter**，不支持GET单事件；不能将本页偶遇匹配事件宣称全链/全范围核验。
- 当前 Response.audit_chain_status由get_decision_audit_status只在**当前纪元**找该run的DECISION_RECORDED事件；不在当前纪元则LEGACY_UNAUDITED，即使其他run或当前head正常也不能继承VALID。
- 确定没有GET `/audit/verify`。现POST `/audit/verify`是真实只读RR/READ ONLY，body `{epoch_id,checkpoint,mode:'PREFIX'|'EXACT'}`返回AuditVerification，但403最小页面用详情已有状态即可保持全GET；不要伪造GET核验路径或增加“修复审计”操作。
- **展示精度缺口（非八层基础阻塞）：** DecisionTraceResponse只有audit_chain_status，没有audit_epoch_id、锚定event_id/sequence/anchor或完整验证diagnostic。若评委需直接看到“本run是哪一条事件锚定/哪一纪元/为什么失败”，root可在实际详情合同中补这组只读真实字段，或给严格分页的run-event读取接口；前端不能从当前head、部分event页、字符串哈希自制完整锚点。无需为最小403先做FULL全图。
- explanation.reasons.references是内容路径，现可在本页映射到已渲染事实/约束/候选/结果；部分动态路径不存在统一类型或没有被展示时显示“原引用路径”并可展开该保存分支，不做伪点击链接。

## 4. 必须专门处理的历史JSON入口

402的 `http.request` 默认对完整JSON递归assertMoneyFields，直接复用会拒绝两类合法历史记录：

1. TraceEvidence.content / TracePolicy.configuration 明确是RawJsonObject，允许保留导致BLOCKED的错误金额/权限声明；例如声明金额字符串。内容hash完整不意味着金融字段有效。原始声明必须仅作未核验文字（React安全转义）展示，不coerce为number、不调用Money/合法PolicyConfigForm；主层只格式化实际typed/verified计算结果。
2. trace.inputs中允许 `amount_options_cents`（2–8个非零整数分）。默认 `_cents` scalar guard会拒绝数组；403专用解析须逐元素safe整数校验，不能把所有数组免检。

实施接缝建议：新增 `api/decisions.ts`专用合同parser；通用HTTP错误/模拟标记逻辑可提取传输入口，但保持402默认金融guard不变。结构身份/阶段/schema/时间/数组完整性先检查；可信inputs/outcome/calculation/candidate结果/receipt金额递归校验，加明确options数组规则；RawJsonObject副本单独隔离为声明原文，不参与金融展示。禁止为了让历史原文进页面而取消所有金额检查。所有金额展示继续用401 BigInt formatMoneyCents，null待核验，signed余量保留。

COMPLETE时显示8层；LEGACY_PARTIAL或UNSUPPORTED_VERSION时显示原完整性标记、已有关联与“未保存/当前版本不能解释”，旧legacy_snapshot/result只作受限原文补充，不造8层来源。409 DECISION_TRACE_INTEGRITY_ERROR/未来决策不可读、404租户/不存在等直接错误并隐藏旧成功面板；不能保留绿色旧核验状态遮盖失败。

## 5. 正式启动后的最小文件与验证（尚未执行）

- `App.tsx`：增加实际第四页hash导航/详情选择，不触碰402生命周期表单。
- `api/decisions.ts`：list/detail/action-decision/receipt真实GET、专用历史parser；类型用正式schema。
- `pages/DecisionTracePage.tsx`：列表与8层详情/父子阶段/本页reason锚点/回执按需展开，复用money与视觉；不做复杂图或通用规则引擎。
- 必要静态phase、原因锚点与JSON字段显示助手可留本page/API模块，真的变大再抽取 `features/trace-view.ts`；不先造架构层。
- 只跑tsc、相关API/页面单元（明确HTTP夹具）与受影响导航；覆盖COMPLETE8层、missing/null、raw错误声明隔离、options数组精度、Legacy/Unsupported、404/409、current_references不覆盖过去、无回执409、同action/operation回执、unknown保留、本页理由路径可达、opaque分页。root统一真实PG/Edge；若改服务端核验/迁移，跑对应集成。无全量，除初版25/完整版92验收节点。
- 当前服务端大部分合同可复用。基础403没有确定缺金融API阻塞；精细审计锚点/diagnostic属明确合同精度缺口，须在正式实施时先定最小验收范围，不能用前端哈希或全量扫描补成证明。

只读source绑定：schema.d.ts `a6bc48dfab89ffb1cd4038179822f9b62cf50cc2dcb2a507e23e86ccae314a02`；decision_trace.py `f1566cbd9fefa4ffa9cb6f3154a5bebce5424246df8554db4c71bef0b8944c47`；decision_trace_types.py `83d6d3621c02cbd89dd26bdf15cde0f78ddeb4159c21e7a1a748fb1e495c03a2`；audit.py `fc1f6eead5297c8127c4a87f406e9667466ea90404b614cdafcea3a2ffa949ce`；App.tsx `e587debf073442c3ab28b30f434e35b49e8db60a49b726ded69b1b7f358939db`。这些是预研时读到的源码版本，不是运行通过证据。
