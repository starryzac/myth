import hashlib, json, os, subprocess, sys, time
from datetime import datetime, UTC
from pathlib import Path
label, *command = sys.argv[1:]
assert label.startswith("MVP-403-") and command
out=Path(".runtime",label+".txt");meta=out.with_suffix(".json")
assert not out.exists() and not meta.exists()
paths=sorted(Path("apps/api/app").rglob("*.py"))
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
start=time.monotonic();record={"command":command,"started_at":datetime.now(UTC).isoformat(),"code_commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"source_before":before}
with out.open("xb") as log:
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONUTF8="1",PYTHONUNBUFFERED="1"))
    for line in process.stdout:
        log.write(line);log.flush();print(line.decode("utf-8",errors="replace"),end="",flush=True)
    code=process.wait()
record.update(exit_code=code,finished_at=datetime.now(UTC).isoformat(),elapsed_seconds=time.monotonic()-start,log_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),changed_during_run=[p for p,h in before.items() if not Path(p).exists() or hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h])
meta.write_text(json.dumps(record,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in record.items() if k!="source_before"}))
raise SystemExit(code)
