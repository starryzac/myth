from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
records = ['20261004T183631Z-typecheck.json', '20261004T183645Z-lint.json', '20261004T183648Z-unit.json', '20261004T183716Z-bundle.json']
source = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in list((ROOT / 'apps/web/src').rglob('*')) + [ROOT / 'packages/contracts/schema.d.ts'] if path.is_file()}
checks = []
for name in records:
    record = json.loads((OUT / name).read_text(encoding='utf-8'))
    assert record['exit_code'] == 0
    assert record['source_before'] == record['source_after'] == source, name
    assert hashlib.sha256(Path(record['log']).read_bytes()).hexdigest() == record['log_sha256']
    checks.append({'record': name, 'command': record['command'], 'exit_code': 0, 'seconds': record['seconds'], 'log': record['log'], 'log_sha256': record['log_sha256']})
changed = ['apps/web/src/App.tsx', 'apps/web/src/App.test.tsx', 'apps/web/src/api/http.ts', 'apps/web/src/api/decisions.ts',
           'apps/web/src/api/decisions.test.ts', 'apps/web/src/pages/DecisionTracePage.tsx', 'apps/web/src/pages/DecisionTracePage.test.tsx',
           'apps/web/src/tests/trace-fixture.ts', 'apps/web/src/styles.css']
report = {'status': 'FRONTEND_SOURCE_FROZEN', 'created_at': datetime.now(UTC).isoformat(), 'base_commit': '869ba84',
          'scope': 'MVP-403 only; real GET adapters + HTTP unit fixtures + tsc/lint/build; no browser/PG/full suite by this agent',
          'checks': checks, 'unit_result': '4 files / 36 tests PASS: decisions API 9, trace page 10, App 14, policies API 3',
          'changed_source': {name: source[str(Path(name))] for name in changed}, 'source': source,
          'preserved_failures': ['20261004T181418Z-red.json', '20261004T182217Z-ui-red.json', '20261004T182822Z-typecheck.json',
                                '20261004T183041Z-unit.json', '20261004T183134Z-red.json', '20261004T183547Z-unit.json'],
          'remaining': ['Root real PostgreSQL and Edge acceptance', 'Root MVP-403 closure and commit'],
          'limitations': ['Selected-run audit status is supplied by API; precise event anchor/diagnostics are not in this DTO',
                          'Legacy/unsupported records remain raw supplements and do not claim reconstructed historical decisions']}
(OUT / 'final-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'source_files': len(source), 'changed_source': report['changed_source'],
                  'manifest_sha256': hashlib.sha256((OUT/'final-verification.json').read_bytes()).hexdigest()}, ensure_ascii=False))
