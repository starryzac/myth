# 集合继续显示标签候选（只读准备）

状态：CANDIDATE_ONLY。root 的 first driver 46600 仍运行，Web 源继续冻结。未修改生产/测试，不启动浏览器、服务或 DB；待 root 明确驱动退出后才应用。

冻结基线：DecisionTracePage.tsx SHA 31ccc4674a77abd635646c0a162bf1ec98d283890dc4f069d2d808a3ce84cb6e。

实际问题：Records 的按钮仅区分 constraints/candidates/sources，其他集合默认叫“策略”，导致 reasons/actions/current_references 的下一批按钮文案错误。

最小实现：在本页面增加模块级名称映射，按钮用 `collectionNames[prefix] ?? '条目'`。

```ts
const collectionNames: Record<string, string> = {
  constraints: '约束', candidates: '候选', sources: '证据', policies: '策略',
  reasons: '原因', actions: '关联动作', current_references: '当前关联状态',
};
// Records:
<button onClick={() => setLimit(limit + 20)}>继续显示{collectionNames[prefix] ?? '条目'}</button>
```

仅展示文案，不改变真实 GET、集合读取范围、opaque 游标、历史/当前字段分离、金额或身份 parser、理由定位和回执行为。

对应验证：待解冻后只做 DecisionTracePage 相关单元、tsc、该页面 lint。增加一个窄交互用例，以明确 HTTP 单元夹具提供21条理由/关联动作/当前关联状态，核对三个真实集合标签且点击后显示第21项；当前引用先展开说明区域。所有记录明确单元夹具，不宣称非空策略银行 E2E。若 root 要求仅文案不增加断言则复用10条页面测试，并保留标签由源码/真实页面独立核对的边界。

原生 transfer 当前 trace.policies=0 是真实无策略权限状态；非空冻结政策演示由 root 准备真实允许策略版本记录，前端不为展示补政策。

后续实施：root确认first driver46600 closed/exit0后，正式仅应用上述集合显示映射。没有添加或修改测试。对应TracePage既有10项PASS、tsc/page-lint及当前标签bundle均exit0；详见 final-verification.json。当前页面SHA c3ca6a61cbb91a67b5e1e6457e4c2bded4d6fdf3ce4dced735ac734a0242d930，再次冻结。
