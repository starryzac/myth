"""Capture focused MVP-403 frontend verification with actual output/source hashes."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
COMMANDS = {'red': ['test', 'src/api/decisions.test.ts'],
            'ui-red': ['test', 'src/pages/DecisionTracePage.test.tsx'],
            'page-labels': ['test', 'src/pages/DecisionTracePage.test.tsx'],
            'unit': ['test', 'src/api/decisions.test.ts', 'src/pages/DecisionTracePage.test.tsx', 'src/App.test.tsx', 'src/api/policies.test.ts'],
            'typecheck': ['typecheck'], 'lint': ['lint'], 'bundle': ['build']}
def hashes():
    files = list((ROOT / 'apps/web/src').rglob('*'))+[ROOT / 'packages/contracts/schema.d.ts']
    return {str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in files if path.is_file()}
mode=sys.argv[1]; start=datetime.now(UTC); name=f'{start:%Y%m%dT%H%M%SZ}-{mode}'
pnpm = shutil.which('pnpm.cmd')
if mode == 'page-lint':
    node=(Path(pnpm).parent/'../../node/bin/node.exe').resolve()
    command=[str(node), str(ROOT/'apps/web/node_modules/eslint/bin/eslint.js'), 'src/pages/DecisionTracePage.tsx', '--max-warnings', '0']
    cwd=ROOT/'apps/web'
else:
    command=[pnpm, '--dir', 'apps/web', *COMMANDS[mode]]
    cwd=ROOT
before=hashes(); result=subprocess.run(command,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); finish=datetime.now(UTC)
log=OUT/(name+'.txt'); log.write_bytes(result.stdout)
report={'scope':'403 focused frontend/API HTTP unit fixtures; no PG/Edge/full suite', 'command':command,'exit_code':result.returncode,
        'cwd': str(cwd),
        'start':start.isoformat(),'finish':finish.isoformat(),'seconds':(finish-start).total_seconds(),
        'source_before':before,'source_after':hashes(),'log':str(log),'log_sha256':hashlib.sha256(result.stdout).hexdigest()}
manifest=OUT/(name+'.json'); manifest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(result.stdout.decode('utf-8',errors='replace')); print(json.dumps({'manifest':str(manifest),'exit_code':result.returncode,'seconds':report['seconds']},ensure_ascii=False))
sys.exit(result.returncode)
