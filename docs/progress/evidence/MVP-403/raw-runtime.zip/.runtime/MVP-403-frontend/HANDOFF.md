# MVP-403 前端冻结交回

状态：FRONTEND_SOURCE_FROZEN。仅实现只读决策轨迹页，等待 root 的真实 PG/Edge 和关闭。基线 869ba84。未由本 agent 启动浏览器、DB、服务或全量测试。

后续标签修订已冻结：只修改 DecisionTracePage.tsx 中 Records 续显集合名称（原因/关联动作/当前关联状态，未知条目）。本批185413Z tsc、185414Z页面lint、185432Z页面10 PASS、185453Z新bundle均exit0；新JS index-gcTS7mMD，CSS仍BqxwVFg3。原冻结manifest逐字保留在 final-verification-before-record-labels.json，SHA仍07ffd6ebf95bad3f90f9b6a930d5c17807c1d6827b14fefd9eab1373ccc92256；当前final-verification.json注明只有该页面展示文案delta。API9/App14/policies3共26条未受影响单元复用原4文件36 PASS，不宣称本批重跑36条。Parser/HTTP/API/data/money及所有测试源码未改。下面记录保留首次冻结的历史检查与走查接缝。

## 源码与验证

最终源/合同 SHA、每个真实 command/exit/log hash 见 final-verification.json。9 个变更 Web 文件：App/App.test、api/http、api/decisions(.test)、DecisionTracePage(.test)、trace-fixture、styles。

- tsc：20261004T183631Z-typecheck exit 0。
- lint：20261004T183645Z-lint exit 0。
- 单元：20261004T183648Z-unit exit 0，4 文件 36 PASS（API9/页面10/App14/默认 policies API3）。这是 HTTP 单元夹具，不是金融 E2E。
- 构建：20261004T183716Z-bundle exit 0，88 modules；index-DQF4RkEt.js、index-BqxwVFg3.css。
- 所有最终检查 source_before == source_after == freeze 当前 Web/TS 合同；freeze.py 实际校验了绑定及 raw log SHA。

保留初始缺模块 RED、首次 unused import 类型失败、夹具列表默认参数与嵌套展开 2 FAIL、storage 身份/回执 3 FAIL、结构共享刷新与隐藏引用/unknown 分项 3 FAIL，各原始报告均未覆盖。

## 真实页面走查接缝

1. `#decisions` 从真实 GET `/decisions?limit=20` 列表进入 `#decisions/<run>`。加载下一页按返回 opaque cursor 原样 URL 编码 GET。没有自动评估或资金 POST。列表记录 SUCCEEDED 不能解释成资金成功。
2. COMPLETE 详情需要同身份 trace 和 explanation。八个 region 可按标题定位：`1 银行事实与证据`、`2 当时用户策略`、`3 受保护金额与约束`、`4 候选动作`、`5 拒绝与限制原因`、`6 当时自主等级`、`7 当前关联动作与回执`、`8 审计哈希状态`。
3. 冻结 facts/版本/constraints 与 `read_at` 当前来源/动作分开。来源变化说明在“当前关联状态”；父子链接来自 trace.parent_run_id / response.children。历史金额只格式化可信安全整数，显式 null 待核验，未记录字段不作 0。
4. 每类集合先20项，后续按需。理由 `定位 <path>` button 保持同一 run hash，展开真实已存在分支并 focus/scroll 到 `trace-constraint-N` / `trace-candidate-N` / `trace-outcome` 等。超出20项的目标仅额外显示该项，不先铺273条。无保存字段的引用为不可点击原路径。
5. 声明内容/配置只作解析字段，不用合法策略表单或可信金额组件展示。真实原响应通过 custom HTTP text parser 原样保留，按需“查看原响应文本（保留原始数字词法）”，分800字符显示/下载。unsafe数字明确显示保真限制。详情query structuralSharing:false，刷新 read_at 后仍持有新原响应 WeakMap。402 默认 response.json + assertMoneyFields 分支不变。
6. 回执 button“读取原动作回执”，按当前关联 action GET `/actions/<id>/receipt`；必须同 action/operation/receipt，金额严格。UNKNOWN或409显示仍未完成；经济发生/对账时点独立展示，不覆盖当时自主结论。
7. top-level audit_chain_status 是所选 run 状态；不用固定 NOT_IMPLEMENTED 的旧 explanation 字段，也不用 current audit head。LEGACY_PARTIAL / UNSUPPORTED_VERSION 有明确不足说明及受限补充原文。404/409读取失败隐藏旧成功面板，可重试。

基础8层无已知前端合同阻塞。API未返回精细锚定事件/纪元/完整诊断，页面已如实限定说明。未实现404控制台或FULL图。冻结期间不再修改 Web，发现真实验收问题等 root 指令再解除冻结。
