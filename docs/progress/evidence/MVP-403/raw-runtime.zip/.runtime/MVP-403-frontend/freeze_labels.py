from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
previous_path=OUT/'final-verification-before-record-labels.json'
previous=json.loads(previous_path.read_text(encoding='utf-8'))
source={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
        for path in list((ROOT/'apps/web/src').rglob('*'))+[ROOT/'packages/contracts/schema.d.ts'] if path.is_file()}
delta=[name for name, sha in source.items() if previous['source'].get(name) != sha]
assert delta == [str(Path('apps/web/src/pages/DecisionTracePage.tsx'))], delta
records=['20261004T185413Z-typecheck.json','20261004T185414Z-page-lint.json','20261004T185432Z-page-labels.json','20261004T185453Z-bundle.json']
checks=[]
for name in records:
    record=json.loads((OUT/name).read_text(encoding='utf-8'))
    assert record['exit_code'] == 0
    assert record['source_before'] == record['source_after'] == source, name
    assert hashlib.sha256(Path(record['log']).read_bytes()).hexdigest() == record['log_sha256']
    checks.append({'record':name,'command':record['command'],'exit_code':0,'seconds':record['seconds'],
                   'log':record['log'],'log_sha256':record['log_sha256']})
report={**previous,'status':'FRONTEND_SOURCE_FROZEN_LABEL_DELTA','created_at':datetime.now(UTC).isoformat(),
        'checks':checks,'source':source,'changed_source':{name:source[str(Path(name))] for name in previous['changed_source']},
        'label_delta':{'only_changed_since_first_freeze':delta,
                       'description':'Records button names: reasons=原因, actions=关联动作, current_references=当前关联状态, unknown=条目; existing four names retained',
                       'previous_sha256':previous['source'][delta[0]],'current_sha256':source[delta[0]],
                       'parser_http_api_money_test_source_changed':False},
        'previous_verification':{'path':str(previous_path),'sha256':hashlib.sha256(previous_path.read_bytes()).hexdigest()},
        'unit_result':'This batch: TracePage 10 PASS. Unchanged decisions API9/App14/policies API3 (26) reuse original 20261004T183648Z 4-file/36 PASS; no claim of a new 36-test command.',
        'reused_checks':[{'record':'20261004T183648Z-unit.json','scope':'26 unchanged API/App/policies tests; parser/HTTP/money and test source hashes unchanged'},
                         {'record':'20261004T183645Z-lint.json','scope':'unchanged files; modified page lint rerun in current batch'}],
        'bundle':'Current labels: 20261004T185453Z-bundle exit0, 88 modules, index-gcTS7mMD.js/index-BqxwVFg3.css. Original bundle log retained as historical.',
        'remaining':['Root real policy fragment Edge acceptance and MVP-403 close']}
(OUT/'final-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'only_delta':delta,'page_sha256':source[delta[0]],
                  'manifest_sha256':hashlib.sha256((OUT/'final-verification.json').read_bytes()).hexdigest()},ensure_ascii=False))
