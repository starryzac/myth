async (page) => {
  const child = '6c029709-2830-5090-8c5d-7498207fb65d';
  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/decisions/' + child) && r.request().method() === 'GET'),
    page.getByRole('link', {name: '查看子阶段 ' + child, exact: true}).click(),
  ]);
  await page.getByRole('region', {name: '8 审计哈希状态'}).waitFor({state: 'visible'});
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path: '.runtime/MVP-403-browser-cli/child-mobile.png'});
  const childRecord = {url:page.url(), status:response.status(), parent:await page.getByRole('link', {name:/查看父阶段/}).getAttribute('href'),
    audit:await page.getByRole('region',{name:'8 审计哈希状态'}).innerText(), overflow: await page.evaluate(() => document.documentElement.scrollWidth > innerWidth)};
  const [missingResponse] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/decisions/734381b1-f86c-48fc-9b7b-515850ff9f2b') && r.request().method() === 'GET'),
    page.goto('http://127.0.0.1:15175/#decisions/734381b1-f86c-48fc-9b7b-515850ff9f2b'),
  ]);
  const error = page.getByRole('alert');
  await error.waitFor({state:'visible'});
  await page.screenshot({path: '.runtime/MVP-403-browser-cli/missing-mobile.png'});
  return {child:childRecord, missing:{status:missingResponse.status(), text:await error.innerText(), old_green_sections:await page.getByRole('region',{name:'8 审计哈希状态'}).count()},
    overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)};
}
