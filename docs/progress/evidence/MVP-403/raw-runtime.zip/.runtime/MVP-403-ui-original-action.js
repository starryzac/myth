async (page) => {
  const id = '6ab82bcb-beb2-5bc3-befc-95d19fddf02b';
  await page.getByRole('link', {name: '返回决策列表', exact: true}).click();
  const start = Date.now();
  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/decisions/' + id) && r.request().method() === 'GET'),
    page.getByRole('link', {name: '查看 ' + id, exact: true}).click(),
  ]);
  const audit = page.getByRole('region', {name: '8 审计哈希状态'});
  await audit.waitFor({state: 'visible'});
  const detailMs = Date.now() - start;
  const actions = page.getByRole('region', {name: '7 当前关联动作与回执'});
  const beforeReceipt = await actions.innerText();
  const receiptStart = Date.now();
  const [receiptResponse] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/actions/893b5d5e-133f-414c-882b-e5fc7b718236/receipt') && r.request().method() === 'GET'),
    actions.getByRole('button', {name: '读取原动作回执', exact: true}).click(),
  ]);
  const receipt = page.getByRole('region', {name: '回执 b47fe8e8-fe69-59f5-bbbf-8c190a355b22'});
  await receipt.waitFor({state: 'visible'});
  await actions.screenshot({path: '.runtime/MVP-403-browser-cli/original-action-receipt.png'});
  await page.getByRole('region', {name: '6 当时自主等级'}).screenshot({path: '.runtime/MVP-403-browser-cli/prepare-autonomy.png'});
  return {url: page.url(), detail_status: response.status(), detail_wall_ms: detailMs, receipt_status: receiptResponse.status(), receipt_wall_ms: Date.now() - receiptStart,
    history: await page.getByRole('region', {name: '6 当时自主等级'}).innerText(), before_receipt: beforeReceipt, receipt: await receipt.innerText(),
    actual_children: await page.getByRole('link', {name:/查看子阶段/}).allTextContents(), audit: await audit.innerText()};
}
