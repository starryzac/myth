"""Prepared real403 policy-layer fixture; no runtime work occurs on import.

Only the explicit disposable driver calls initialize_fixture. Native seed has no Goal;
real rules compilation, reviewed-hash confirmation, zero Goal creation and explicit
allocate_goal assessment go through actual public routers. The two dependency overrides
are the generated test engine and trusted fixed clock. No execution or external income
is injected. Existing bank originals and income economics must survive unchanged.
This is a synthetic trusted fixture, not a production feature or browser acceptance.
"""

import json
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

from app.api.dependencies import get_engine, get_now
from app.db.models import DecisionRun
from app.domain.income_ledger import IncomeLedger
from app.domain.policy_configuration import configuration_hash
from app.main import create_app
from app.services.decision_trace import DecisionTraceResponse
from app.services.demo_seed import DEMO_USER_ID, seed_demo
from app.services.goals import GoalResponse
from app.services.policy_compilation import CompilationResponse
from app.services.policy_lifecycle import LifecycleResult
from drive_mvp402_goal_epoch import FINANCIAL_TABLES, policy_goal_oracle
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

BASE_NOW = datetime(2026, 10, 4, 1, tzinfo=UTC)
READ_NOW = BASE_NOW + timedelta(minutes=1)
TEXT = "买车目标三万元，截止2027年10月1日，每月至少一千八百、建议两千、最多两千五百元。"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def by_id(rows):
    result = {row["id"]: row for row in rows}
    require(len(result) == len(rows), "Duplicate actual row identity")
    return result


def initialize_fixture(engine, readonly_engine, destination: Path, phase, capture):
    raw_directory = destination / "initialization"
    raw_directory.mkdir()
    requests = []
    clock = {"now": BASE_NOW}

    def raw(name, value):
        with (raw_directory / (name + ".json")).open("x", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2)

    phase("seed", lambda: seed_demo(engine))
    before, before_meta = capture("fixture-native-before-policy")
    require(before["goals"] == [], "Native seed must not supply a fabricated existing Goal")
    income = [
        row
        for row in before["evidence_items"]
        if row["source_type"] == "SIMULATED_NEW_FUNDS_LEDGER"
        and row["status"] == "VALID"
        and row["user_id"] == str(DEMO_USER_ID)
    ]
    require(len(income) == 1, "Native seed must have one complete actual income proof")
    ledger = IncomeLedger.model_validate_json(json.dumps(income[0]["content"]))
    require(
        ledger.origins
        and ledger.user_id == DEMO_USER_ID
        and all(
            origin.occurred_at < BASE_NOW and origin.observed_at < BASE_NOW
            for origin in ledger.origins
        ),
        "History cannot be presented as new income after this policy confirmation",
    )
    accounts = [
        row
        for row in before["accounts"]
        if row["user_id"] == str(DEMO_USER_ID) and row["account_type"] == "GOAL"
    ]
    require(len(accounts) == 1, "Use exactly one actual native owned Goal account")

    api = create_app()
    api.dependency_overrides[get_engine] = lambda: engine
    api.dependency_overrides[get_now] = lambda: clock["now"]
    require(len(api.dependency_overrides) == 2, "Only engine and clock may be overridden")

    with TestClient(api) as client:

        def request(label, method, path, body=None):
            started = time.monotonic()
            response = (
                client.request(method, path, json=body)
                if body is not None
                else client.request(method, path)
            )
            requests.append(
                {
                    "label": label,
                    "method": method,
                    "path": path,
                    "trusted_now": clock["now"].isoformat(),
                    "status_code": response.status_code,
                    "wall_seconds": time.monotonic() - started,
                }
            )
            raw(
                label,
                {"request": body, "status_code": response.status_code, "response": response.json()},
            )
            require(response.status_code == 200, "Actual router failed: " + label)
            return response

        compiled = phase(
            "public-rules-compile-goal-policy",
            lambda: CompilationResponse.model_validate_json(
                request(
                    "compile-policy",
                    "POST",
                    "/api/v1/policies/compile",
                    {"text": TEXT, "engine": "rules"},
                ).text
            ),
        )
        require(
            compiled.user_id == DEMO_USER_ID
            and compiled.proposal_id is not None
            and compiled.configuration is not None
            and compiled.configuration["type"] == "goal_saving"
            and compiled.configuration_hash == configuration_hash(compiled.configuration),
            "Rules compilation must produce an actual reviewed Goal proposal",
        )
        confirmed = phase(
            "public-confirm-exact-reviewed-policy",
            lambda: LifecycleResult.model_validate_json(
                request(
                    "confirm-policy",
                    "POST",
                    f"/api/v1/policy-proposals/{compiled.proposal_id}/confirm",
                    {"accepted": True, "reviewed_hash": compiled.configuration_hash},
                ).text
            ),
        )
        goal = phase(
            "public-create-zero-goal-no-allocation",
            lambda: GoalResponse.model_validate_json(
                request(
                    "create-zero-goal",
                    "POST",
                    "/api/v1/goals",
                    {
                        "policy_id": str(confirmed.policy_id),
                        "expected_version_id": str(confirmed.current_version_id),
                        "account_id": accounts[0]["id"],
                    },
                ).text
            ),
        ).goal
        require(
            goal.allocated_cents == 0
            and goal.policy_id == confirmed.policy_id
            and goal.policy_version_id == confirmed.current_version_id,
            "Goal must bind the actual confirmed version with zero ownership",
        )
        after_goal, goal_meta = capture("fixture-after-real-zero-goal")
        # Reuse only the pure, frozen post-fix oracle. All initialization commands use
        # its Oct4 01:00Z clock; the separate native browser clock is Oct4 01:01Z.
        zero_goal_oracle = policy_goal_oracle(
            before, after_goal, str(DEMO_USER_ID), configuration_hash
        )
        require(
            zero_goal_oracle["new_zero_goal_ids"] == [str(goal.id)]
            and zero_goal_oracle["income_epoch_carry"],
            "Actual zero Goal must preserve complete income by the verified carry protocol",
        )
        saved = phase(
            "public-save-policy-bound-allocation-assessment",
            lambda: DecisionTraceResponse.model_validate_json(
                request(
                    "saved-goal-assessment",
                    "POST",
                    "/api/v1/decisions/assess",
                    {
                        "idempotency_key": "403-real-policy-bound-allocation",
                        "intent": {"kind": "allocate_goal", "goal_id": str(goal.id)},
                    },
                ).text
            ),
        )
        require(
            saved.trace is not None
            and saved.trace.phase == "EVALUATION"
            and saved.trace.action_id is None
            and saved.trace.parent_run_id is None
            and saved.actions == []
            and saved.children == [],
            "Assessment must not create or claim an executed action or receipt",
        )
        trace = saved.trace
        version = by_id(after_goal["policy_versions"])[str(confirmed.current_version_id)]
        policy = by_id(after_goal["policies"])[str(confirmed.policy_id)]
        selected = [row for row in trace.policies if str(row.id) == version["id"]]
        require(len(selected) == 1 and len(trace.policies) >= 1, "Trace lacks actual policy layer")
        captured = selected[0]
        require(
            captured.user_id == DEMO_USER_ID
            and str(captured.policy_id) == policy["id"]
            and captured.version_number == version["version_number"]
            and captured.configuration == version["configuration"]
            and captured.configuration_hash == version["content_hash"]
            and captured.captured_configuration_hash == version["content_hash"]
            and captured.configuration_integrity == "VERIFIED"
            and captured.status_at_decision == policy["status"]
            and captured.confirmed_at == BASE_NOW,
            "TracePolicy must match the real current version and permission clock",
        )
        authority = trace.inputs["autonomy_facts"]["authority"]
        require(
            authority["status"] == "AUTHORIZED"
            and version["id"] in authority["policy_version_ids"],
            "Readiness does not replace actual confirmed policy authority",
        )
        evidence = by_id(after_goal["evidence_items"])
        confirmation_sources = []
        for identity in version["evidence_ids"]:
            item = evidence[identity]
            if item["source_type"] != "POLICY_CONFIRMATION":
                continue
            source = next((row for row in trace.sources if str(row.id) == identity), None)
            require(
                source is not None
                and item["user_id"] == str(DEMO_USER_ID)
                and item["evidence_level"] == "USER_CONFIRMED_POLICY"
                and item["source_ref"] == version["id"]
                and item["content"] == version["confirmation"]
                and item["content"]["accepted"] is True
                and item["content"]["reviewed_hash"] == version["content_hash"]
                and item["content"]["version_id"] == version["id"]
                and item["content_hash"] == configuration_hash(item["content"])
                and source.content == item["content"]
                and source.content_hash == item["content_hash"]
                and source.captured_content_hash == item["content_hash"]
                and source.content_integrity == "VERIFIED"
                and identity in authority["evidence_ids"],
                "Actual policy permission must retain its reviewed confirmation evidence",
            )
            confirmation_sources.append(identity)
        require(confirmation_sources, "No actual Policy confirmation source was captured")
        after_assessment, assessment_meta = capture("fixture-after-saved-policy-assessment")
        unchanged_tables = [
            table
            for table in FINANCIAL_TABLES
            if table not in {"decision_runs", "decision_constraints"}
        ] + [
            "evidence_items",
            "policies",
            "policy_versions",
            "policy_proposals",
            "goals",
            "simulated_bank_postings",
        ]
        for table in unchanged_tables:
            require(
                after_goal[table] == after_assessment[table],
                "Saved assessment mutated an original or financial fact: " + table,
            )
        require(
            len(after_assessment["decision_runs"]) == len(after_goal["decision_runs"]) + 1,
            "Save must record exactly one original evaluation",
        )
        # Future native GETs occur after all actual initialization clocks, not before
        # the confirmation or the complete income-proof epoch.
        clock["now"] = READ_NOW
        readback = phase(
            "readonly-native-get-policy-decision-at-read-now",
            lambda: DecisionTraceResponse.model_validate_json(
                request(
                    "native-read-policy-decision", "GET", f"/api/v1/decisions/{saved.run_id}"
                ).text
            ),
        )
        require(
            readback.trace == trace
            and readback.audit_chain_status == "VALID"
            and readback.actions == [],
            "Actual native GET must preserve the historical trace with current audit status",
        )
        after_read, read_meta = capture("fixture-after-readonly-policy-trace")
        require(after_read == after_assessment, "Initialization GET wrote a physical table")

    with Session(readonly_engine) as session:
        missing_id = uuid4()
        require(session.get(DecisionRun, missing_id) is None, "Missing-path ID unexpectedly exists")
    raw("initialization-http-requests", requests)
    raw("zero-goal-financial-oracle", zero_goal_oracle)
    return {
        "classification": "ACTUAL_INITIALIZATION_NOT_BROWSER_ACCEPTANCE_OR_PRODUCT_SLA",
        "initialization_clock": BASE_NOW.isoformat(),
        "native_read_now": READ_NOW.isoformat(),
        "saved_assessment_run_id": str(saved.run_id),
        "parent_run_id": None,
        "action_id": None,
        "receipt_id": None,
        "bank_operation_id": None,
        "phases": [{"run_id": str(saved.run_id), "phase": "EVALUATION", "parent_run_id": None}],
        "policy_id": str(confirmed.policy_id),
        "policy_version_id": version["id"],
        "policy_version_number": version["version_number"],
        "policy_configuration": version["configuration"],
        "policy_configuration_hash": version["content_hash"],
        "policy_status_at_decision": captured.status_at_decision,
        "policy_confirmation_evidence_ids": confirmation_sources,
        "authority": authority,
        "goal_id": str(goal.id),
        "goal_allocated_cents": goal.allocated_cents,
        "income_origin_count": len(ledger.origins),
        "new_income_after_confirmation": False,
        "historical_income_eligibility": "All origin occurred/observed clocks precede confirmation",
        "goal_planning": trace.inputs.get("goal_planning"),
        "outcome": trace.outcome,
        "constraint_count": len(trace.constraints),
        "trace_policy_count": len(trace.policies),
        "top_audit_chain_status": readback.audit_chain_status,
        "original_explanation_audit_chain": readback.explanation.audit_chain
        if readback.explanation
        else None,
        "missing_run_id": str(missing_id),
        "data_sources": [
            "app.services.demo_seed.seed_demo native fixed FIFO provenance",
            "POST /api/v1/policies/compile rules engine",
            "POST /api/v1/policy-proposals/{actual proposal ID}/confirm reviewed hash",
            "POST /api/v1/goals actual zero projection and strict income epoch carry",
            "POST /api/v1/decisions/assess allocate_goal",
            "GET /api/v1/decisions/{actual run ID} RR/RO native read clock",
        ],
        "initialization_http_requests": requests,
        "before_policy": before_meta,
        "after_zero_goal": goal_meta,
        "after_assessment": assessment_meta,
        "after_native_read": read_meta,
        "financial_oracle": zero_goal_oracle,
        "raw_dto_directory": str(raw_directory),
        "budget_boundary": (
            "One compiled/confirmed zero Goal and one saved evaluation; "
            "no execute or external income"
        ),
    }
