"""Prepared policy-only403 real Edge fragment: explicit --run, fresh local test DB.

Future launch: .venv/Scripts/python.exe .runtime/drive_mvp403_policy_browser.py --run
Fresh default folder MVP-403-browser-policy and ports18044/15176. Original first403
fixture and artifacts are preserved. Native initialization compiles a Goal policy,
confirms its actual reviewed hash, creates a zero Goal, and saves allocate_goal through
real public routers. No financial action is prepared/executed and no new income is
injected. Existing bank originals and original income economics remain intact, apart
from strictly verified zero Goal memo openings and complete income epoch carry.

All initialization commands share trusted Oct4 01:00Z; the actual plain server exposes
Oct4 01:01Z via only engine/get_now overrides. Browser fragment only issues GETs; every
checkpoint independently compares mapped23 and all physical24 RR/RO snapshots. Terminal
cleanup closes both exclusive PIDs, deletes only the generated bf_test DB and proves
its absence. Production source before/after must match. No profiling, fake traces,
route patches, or future404 controls. Preparation is NOT_EXECUTED; initialization and
HTTP wall timings are diagnostic, NOT_PRODUCT_SLA. UI acceptance requires root review.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 10, 4, 1, 1, tzinfo=UTC)
FINANCIAL_TABLES = (
    "users",
    "accounts",
    "transactions",
    "credit_card_bills",
    "asset_products",
    "asset_positions",
    "bank_operations",
    "simulated_bank_redemptions",
    "external_bank_facts",
    "action_plans",
    "action_receipts",
    "action_resource_reservations",
    "decision_runs",
    "decision_constraints",
    "alembic_version",
)
OWNERSHIP = "SIMULATED_GOAL_OWNERSHIP"
CONTRIBUTION = "SIMULATED_GOAL_MONTH_CONTRIBUTION"
EXPOSURE = "SIMULATED_ASSET_EXPOSURE"


def dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.now(UTC).isoformat()


def actual_api_requests(path):
    """Read the existing production HTTP logger; no handler or response is replaced."""
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("event") == "http_request":
            require(
                row.get("method") == "GET", "Browser stage issued an HTTP command instead of GET"
            )
            records.append(row)
    return records


def require(condition, message):
    if not condition:
        raise ValueError(message)


def source_hashes():
    paths = [p for p in (ROOT / "apps/api/app").rglob("*.py") if "tests" not in p.parts]
    paths += list((ROOT / "apps/api/alembic").rglob("*.py"))
    paths += [p for p in (ROOT / "apps/web/src").rglob("*") if p.suffix in {".ts", ".tsx", ".css"}]
    paths += [
        ROOT / name
        for name in (
            "packages/contracts/openapi.json",
            "packages/contracts/schema.d.ts",
            "apps/api/app/tests/test_demo_seed.py",
            "apps/api/app/tests/test_execution_service.py",
            "apps/web/vite.config.ts",
        )
    ]
    return {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in sorted(paths)}


def by_id(rows):
    result = {row["id"]: row for row in rows}
    require(len(result) == len(rows), "Duplicate physical row identity")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run", action="store_true", help="Explicitly create one disposable DB and servers"
    )
    parser.add_argument("--output", default=".runtime/MVP-403-browser-policy")
    parser.add_argument("--api-port", type=int, default=18044)
    parser.add_argument("--web-port", type=int, default=15176)
    parser.add_argument("--checkpoint-timeout", type=int, default=1800)
    args = parser.parse_args()
    if not args.run:
        parser.error("Preparation only; explicit --run is required")
    require(
        1024 <= args.api_port <= 65535
        and 1024 <= args.web_port <= 65535
        and args.api_port != args.web_port
        and 1 <= args.checkpoint_timeout <= 7200,
        "Invalid ports or synchronization budget",
    )
    destination = (ROOT / args.output).resolve()
    require(
        destination.is_relative_to((ROOT / ".runtime").resolve())
        and destination != (ROOT / ".runtime").resolve()
        and not destination.exists(),
        "Output must be a fresh directory strictly inside this repo .runtime",
    )
    sys.path.insert(0, str(ROOT / "apps/api"))
    from alembic import command
    from alembic.config import Config
    from app.db.base import Base
    from app.db.session import create_database_engine
    from app.db.settings import DatabaseSettings
    from app.db.testing import require_test_database, temporary_database
    from app.tests.test_demo_seed import database_snapshot
    from mvp403_policy_fixture import initialize_fixture
    from sqlalchemy import event, select, text
    from sqlalchemy.engine import make_url

    source = make_url(DatabaseSettings().database_url)
    require(
        source.drivername == "postgresql+psycopg"
        and source.host in {"127.0.0.1", "localhost", "::1"}
        and source.port == 54329,
        "Only local54329 disposable-test administration is allowed",
    )
    node = shutil.which("node")
    require(
        node is not None and (ROOT / "apps/web/node_modules/vite/bin/vite.js").is_file(),
        "Vite runtime missing",
    )
    destination.mkdir()
    checkpoints = destination / "checkpoints"
    checkpoints.mkdir()
    manifest = {
        "status": "STARTING",
        "classification": "REAL_TEST_FIXTURE_NOT_PRODUCT_SLA",
        "started_at": utc(),
        "trusted_now": NOW.isoformat(),
        "checkpoints": [],
        "phases": [],
        "code_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "source_before": source_hashes(),
        "processes": [],
        "temporary_database_exited": False,
        "ui_acceptance": "REQUIRES_ROOT_REVIEW_OF_ACTUAL_EDGE_EVIDENCE",
        "tool_hashes": {
            p.name: sha(p.read_bytes())
            for p in (
                Path(__file__),
                ROOT / ".runtime/mvp403_e2e_server.py",
                ROOT / ".runtime/mvp403_policy_fixture.py",
                ROOT / ".runtime/drive_mvp402_goal_epoch.py",
            )
        },
    }
    processes, logs = [], []

    def save():
        (destination / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def phase(label, function):
        started_at, start = utc(), time.monotonic()
        try:
            return function()
        finally:
            manifest["phases"].append(
                {
                    "phase": label,
                    "started_at": started_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - start,
                }
            )
            save()

    def cleanup():
        for process, item in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
            item.update(exit_code=process.returncode, closed_at=utc())
            save()
        for log in logs:
            log.close()

    def launch(argv, environment, name):
        log = (destination / f"{name}.log").open("x", encoding="utf-8")
        logs.append(log)
        process = subprocess.Popen(
            argv,
            cwd=ROOT,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        item = {"name": name, "argv": argv, "pid": process.pid, "started_at": utc()}
        processes.append((process, item))
        manifest["processes"].append(item)
        save()

    def wait_url(url):
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            require(
                all(process.poll() is None for process, _ in processes),
                "Owned server exited during startup",
            )
            try:
                with urlopen(url, timeout=2) as response:
                    if response.status == 200:
                        return
            except (URLError, TimeoutError, OSError):
                pass
            time.sleep(0.2)
        raise TimeoutError("Server startup synchronization budget elapsed: " + url)

    save()
    try:
        created_at, create_start = utc(), time.monotonic()
        with temporary_database() as url:
            manifest["phases"].append(
                {
                    "phase": "create_database",
                    "started_at": created_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - create_start,
                }
            )
            generated = require_test_database(make_url(url).database)
            manifest["database"] = generated
            manifest["database_url_redacted"] = make_url(url).render_as_string(hide_password=True)
            save()
            engine = create_database_engine(url)
            snapshot_engine = create_database_engine(url).execution_options(
                isolation_level="REPEATABLE READ"
            )

            @event.listens_for(snapshot_engine, "begin")
            def readonly_begin(connection):
                connection.exec_driver_sql("SET TRANSACTION READ ONLY")

            def capture(label):
                started_at, start = utc(), time.monotonic()
                mapped_raw = database_snapshot(snapshot_engine)
                with snapshot_engine.connect() as connection:
                    isolation = connection.exec_driver_sql(
                        "SHOW transaction_isolation"
                    ).scalar_one()
                    readonly = connection.exec_driver_sql("SHOW transaction_read_only").scalar_one()
                    require(
                        isolation == "repeatable read" and readonly == "on", "Snapshot is not RR/RO"
                    )
                    names = set(
                        connection.execute(
                            text(
                                "SELECT table_name FROM information_schema.tables "
                                "WHERE table_schema='public' AND table_type='BASE TABLE'"
                            )
                        ).scalars()
                    )
                    expected = set(Base.metadata.tables) | {"alembic_version"}
                    require(
                        names == expected and len(names) == 24,
                        "Physical table set differs from exact current24",
                    )
                    content = {
                        table.name: [
                            dict(row)
                            for row in connection.execute(
                                select(table).order_by(table.c.id)
                            ).mappings()
                        ]
                        for table in Base.metadata.sorted_tables
                    }
                    require(
                        mapped_raw == dump(content),
                        "Independent mapped23 snapshots differ; UI requests must be quiescent",
                    )
                    content["alembic_version"] = [
                        dict(row)
                        for row in connection.execute(
                            text("SELECT version_num FROM alembic_version ORDER BY version_num")
                        ).mappings()
                    ]
                physical_raw = dump(content)
                records = {}
                for suffix, raw in (("mapped23", mapped_raw), ("physical24", physical_raw)):
                    path = checkpoints / f"{label}.{suffix}.json"
                    path.write_text(raw, encoding="utf-8")
                    records[suffix] = {
                        "path": str(path.relative_to(ROOT)),
                        "sha256": sha(path.read_bytes()),
                        "bytes": path.stat().st_size,
                    }
                record = {
                    "started_at": started_at,
                    "finished_at": utc(),
                    "wall_seconds": time.monotonic() - start,
                    "isolation": isolation,
                    "read_only": readonly,
                    "physical_tables": sorted(names),
                    **records,
                }
                (checkpoints / f"{label}.snapshot-meta.json").write_text(
                    json.dumps(record, indent=2), encoding="utf-8"
                )
                return json.loads(physical_raw), record

            try:
                config = Config(str(ROOT / "alembic.ini"))
                config.set_main_option("sqlalchemy.url", url.replace("%", "%%"))
                phase("migration", lambda: command.upgrade(config, "head"))
                manifest["fixture"] = initialize_fixture(
                    engine, snapshot_engine, destination, phase, capture
                )
                save()
                environment = dict(
                    os.environ,
                    PYTHONUTF8="1",
                    PYTHONPATH=str(ROOT / "apps/api"),
                    DATABASE_URL=url,
                    BF_DECISION_TEST_NOW=NOW.isoformat(),
                    API_PROXY_TARGET=f"http://127.0.0.1:{args.api_port}",
                )
                launch(
                    [
                        sys.executable,
                        "-m",
                        "uvicorn",
                        "--no-access-log",
                        "--app-dir",
                        ".runtime",
                        "mvp403_e2e_server:api",
                        "--host",
                        "127.0.0.1",
                        "--port",
                        str(args.api_port),
                    ],
                    environment,
                    "api",
                )
                launch(
                    [
                        node,
                        str(ROOT / "apps/web/node_modules/vite/bin/vite.js"),
                        str(ROOT / "apps/web"),
                        "--host",
                        "127.0.0.1",
                        "--port",
                        str(args.web_port),
                    ],
                    environment,
                    "web",
                )
                wait_url(f"http://127.0.0.1:{args.api_port}/api/v1/health")
                wait_url(f"http://127.0.0.1:{args.web_port}")
                for sequence in range(1, 21):
                    before, before_record = capture(f"{sequence:04d}-before")
                    nonce = uuid4().hex
                    ready = {
                        "run_id": destination.name,
                        "sequence": sequence,
                        "nonce": nonce,
                        "status": "WAITING_FOR_REAL_UI",
                        "trusted_now": NOW.isoformat(),
                        "browser_url": f"http://127.0.0.1:{args.web_port}",
                        "before": before_record,
                        "command_file": str(
                            (checkpoints / f"{sequence:04d}.command.json").relative_to(ROOT)
                        ),
                        "cash_accounts": [
                            r for r in before["accounts"] if r["account_type"] in {"CASH", "GOAL"}
                        ],
                        "fixture": manifest["fixture"],
                    }
                    ready_path = destination / "ready.json"
                    ready_tmp = destination / "ready.pending.json"
                    ready_tmp.write_text(
                        json.dumps(ready, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                    ready_tmp.replace(ready_path)
                    manifest["status"] = "WAITING_FOR_REAL_UI"
                    save()
                    print("READY " + str(ready_path), flush=True)
                    control = checkpoints / f"{sequence:04d}.command.json"
                    deadline = time.monotonic() + args.checkpoint_timeout
                    while not control.exists():
                        require(
                            all(process.poll() is None for process, _ in processes),
                            "Owned server exited",
                        )
                        if time.monotonic() >= deadline:
                            raise TimeoutError(
                                "UI control synchronization budget elapsed; this is not an SLA"
                            )
                        time.sleep(0.2)
                    raw = control.read_bytes()
                    require(len(raw) <= 65536, "Command exceeds 64KiB")
                    instruction = json.loads(raw)
                    require(
                        isinstance(instruction, dict)
                        and set(instruction)
                        == {
                            "run_id",
                            "sequence",
                            "nonce",
                            "operation",
                            "mode",
                            "label",
                            "artifacts",
                        },
                        "Invalid control fields",
                    )
                    require(
                        instruction["run_id"] == destination.name
                        and type(instruction["sequence"]) is int
                        and instruction["sequence"] == sequence
                        and instruction["nonce"] == nonce,
                        "Stale control identity",
                    )
                    require(
                        instruction["operation"] in {"CHECKPOINT", "FINISH", "STOP"}
                        and instruction["mode"] == "READ_ONLY"
                        and isinstance(instruction["label"], str)
                        and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", instruction["label"]),
                        "Invalid control action",
                    )
                    require(
                        isinstance(instruction["artifacts"], list)
                        and len(instruction["artifacts"]) <= 50,
                        "Invalid evidence references",
                    )
                    artifacts = []
                    for value in instruction["artifacts"]:
                        require(isinstance(value, str), "Evidence reference must be a path")
                        path = (ROOT / value).resolve()
                        require(
                            path.is_relative_to((ROOT / ".runtime").resolve()) and path.is_file(),
                            "Evidence must exist inside repo .runtime",
                        )
                        artifacts.append(
                            {"path": str(path.relative_to(ROOT)), "sha256": sha(path.read_bytes())}
                        )
                    item = {
                        "sequence": sequence,
                        "instruction": instruction,
                        "command_sha256": sha(raw),
                        "command_read_at": utc(),
                        "before": before_record,
                        "artifacts": artifacts,
                    }
                    manifest["checkpoints"].append(item)
                    save()
                    if instruction["operation"] == "STOP":
                        raise RuntimeError("Explicit root stop: run ABORTED, no acceptance claim")
                    after, after_record = capture(f"{sequence:04d}-after")
                    item["after"] = after_record
                    save()
                    item["actual_api_http_requests"] = actual_api_requests(destination / "api.log")
                    require(
                        before == after,
                        "403 browser checkpoint wrote one or more physical24 tables",
                    )
                    item["oracle"] = {
                        "physical24_exact": True,
                        "mapped23_exact": True,
                        "browser_get_only": True,
                    }
                    item["status"] = "PASSED"
                    item["finished_at"] = utc()
                    save()
                    if instruction["operation"] == "FINISH":
                        manifest["status"] = "DB_CHECKPOINTS_COMPLETE"
                        break
                else:
                    raise RuntimeError("Checkpoint count synchronization bound reached")
            finally:
                cleanup()
                snapshot_engine.dispose()
                engine.dispose()
        manifest["temporary_database_exited"] = True
        # Independently prove generated database absence after the context's guarded DROP.
        administration = create_database_engine(
            source.set(database="postgres").render_as_string(False)
        )
        try:
            with administration.connect().execution_options(
                isolation_level="REPEATABLE READ"
            ) as connection:
                connection.exec_driver_sql("SET TRANSACTION READ ONLY")
                manifest["generated_database_absent"] = not connection.execute(
                    text("SELECT EXISTS (SELECT 1 FROM pg_database WHERE datname=:name)"),
                    {"name": generated},
                ).scalar_one()
                require(
                    manifest["generated_database_absent"],
                    "Generated database remains after context exit",
                )
        finally:
            administration.dispose()
    except BaseException as error:
        manifest["status"] = "ABORTED" if str(error).startswith("Explicit root stop") else "FAILED"
        manifest["error"] = repr(error)
        save()
        raise
    finally:
        cleanup()
        manifest["source_after"] = source_hashes()
        manifest["changed_during_run"] = sorted(
            key
            for key in set(manifest["source_before"]) | set(manifest["source_after"])
            if manifest["source_before"].get(key) != manifest["source_after"].get(key)
        )
        manifest["finished_at"] = utc()
        if manifest["changed_during_run"]:
            manifest["status"] = "FAILED_SOURCE_CHANGED"
        save()
    return 0 if manifest["status"] == "DB_CHECKPOINTS_COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
