async (page) => {
  const before = page.url();
  await page.getByRole('button', {name: '定位 constraints[0].required_cents', exact: true}).click();
  const constraint = page.locator('#trace-constraint-0');
  await constraint.getByText('查看该约束计算点', {exact: true}).click();
  await constraint.screenshot({path: '.runtime/MVP-403-browser-cli/actual-constraint.png'});
  const candidates = page.getByRole('region', {name: '4 候选动作'});
  const blocked = candidates.locator('article').nth(1);
  await blocked.getByText('查看候选输入', {exact: true}).click();
  await blocked.getByText('查看候选计算结果', {exact: true}).click();
  await blocked.screenshot({path: '.runtime/MVP-403-browser-cli/actual-blocked-candidate.png'});
  return {route_before: before, route_after: page.url(), reason_target: await constraint.getAttribute('id'), constraint_text: await constraint.innerText(),
    blocked_text: await blocked.innerText(), buttons: await blocked.getByRole('button').allTextContents()};
}
