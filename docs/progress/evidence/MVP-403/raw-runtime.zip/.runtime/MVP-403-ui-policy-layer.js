async (page) => {
  const id = '44b3a3cc-f68e-5c9a-a7e9-e47d4ba9685f';
  await page.setViewportSize({width:1280,height:900});
  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith('/decisions/' + id) && r.request().method() === 'GET'),
    page.goto('http://127.0.0.1:15176/#decisions/' + id),
  ]);
  const audit = page.getByRole('region', {name:'8 审计哈希状态'});
  await audit.waitFor({state:'visible'});
  const policy = page.getByRole('region', {name:'2 当时用户策略'});
  await policy.getByText('查看当时配置声明',{exact:true}).click();
  await policy.getByText('monthly_contribution · 3 项',{exact:true}).click();
  await policy.screenshot({path:'.runtime/MVP-403-browser-cli/actual-confirmed-policy.png'});
  const sources = page.getByRole('region',{name:'1 银行事实与证据'});
  const facts = sources.locator('article').filter({has:page.getByRole('heading',{name:/USER_CONFIRMED_POLICY.*POLICY_CONFIRMATION/})});
  await facts.getByText('查看证据声明原文',{exact:true}).click();
  await facts.screenshot({path:'.runtime/MVP-403-browser-cli/actual-policy-confirmation-proof.png'});
  return {url:page.url(), method:response.request().method(), status:response.status(), policy_text:await policy.innerText(),
    confirmation_proof:await facts.innerText(), outcome:await page.getByRole('region',{name:'6 当时自主等级'}).innerText(),
    actions:await page.getByRole('region',{name:'7 当前关联动作与回执'}).innerText(), audit:await audit.innerText(),
    reason_continue:await page.getByRole('region',{name:'5 拒绝与限制原因'}).getByRole('button',{name:'继续显示原因',exact:true}).count(),
    overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)};
}
